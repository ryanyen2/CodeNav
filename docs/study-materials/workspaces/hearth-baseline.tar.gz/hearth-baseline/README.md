# hearth

A small static site generator for markdown. It reads a directory of `.md`
files, renders them with a tiny template engine, and writes a browsable site
with tag pages, a year archive, an RSS feed and a sitemap. Python 3.11 or
later, standard library only, no dependencies.

Builds are incremental: a page is re-rendered when its own bytes change, and
the generated listings are re-rendered when the values they are assembled from
change.

## Quickstart

```sh
python3 -m hearth build          # render the site into _site/
python3 -m hearth build --force  # ignore the cache and rebuild everything
python3 -m hearth serve          # build, serve on :8000, rebuild on change
python3 -m hearth clean          # delete _site/ and .hearth/
```

Every command takes `--root PATH` if the site is not the working directory.

## Layout

```
hearth.toml          site configuration
content/
  posts/*.md         posts: dated, tagged, listed on the home page
  *.md               standalone pages
  assets/            css, images, anything copied as-is
templates/           base.html, index.html, post.html, page.html,
                     tag.html, tags.html, archive.html, partials/
_site/               build output (generated)
.hearth/cache.json   build cache (generated)
```

Markdown files carry a `---` fenced metadata block: `title`, `date`
(`YYYY-MM-DD`), `tags` (`[one, two]`), an optional `slug`, and any other keys
you want, which are passed through to the template untouched.

## Configuration

`hearth.toml`, all keys optional except a sensible `title` and `base_url`:

| key | default | meaning |
| --- | --- | --- |
| `title` | `A hearth site` | site name, used in titles and the feed |
| `base_url` | `http://localhost:8000` | absolute root for feed and sitemap urls |
| `content_dir` | `content` | where the markdown lives |
| `output_dir` | `_site` | where the built site goes |
| `template_dir` | `templates` | where the templates live |
| `assets_dir` | `assets` | asset directory inside `content_dir` |
| `posts_per_page` | `4` | posts on each page of the home listing |

## Tests

```sh
python3 -m pytest tests/
```
