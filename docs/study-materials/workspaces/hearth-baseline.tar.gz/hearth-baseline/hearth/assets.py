"""Copying static files out of the content directory into the site."""

from __future__ import annotations

import hashlib
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from .discovery import asset_sources, discover

FINGERPRINT_SUFFIXES = frozenset({".css"})
HASH_LENGTH = 8


@dataclass(frozen=True)
class AssetResult:
    """What a copy pass produced.

    ``outputs`` maps each asset's content-relative path to the file written
    for it; ``manifest`` maps a short name to that file's url, which is how a
    template refers to a stylesheet whose name carries a hash.
    """

    outputs: dict[str, str] = field(default_factory=dict)
    manifest: dict[str, str] = field(default_factory=dict)

    @property
    def copied(self) -> list[str]:
        return sorted(self.outputs.values())


def fingerprint_name(path: Path | str) -> str:
    """Return the on-disk name for *path* with a content hash in it.

    ``style.css`` becomes ``style.a1b2c3d4.css``, so a changed stylesheet
    gets a url no browser has cached. Other file types keep their own name.
    """
    path = Path(path)
    if path.suffix.lower() not in FINGERPRINT_SUFFIXES:
        return path.name
    digest = hashlib.sha256(path.read_bytes()).hexdigest()[:HASH_LENGTH]
    return f"{path.stem}.{digest}{path.suffix}"


def copy_assets(config, root: Path | str, sources: list | None = None) -> AssetResult:
    """Mirror every non-markdown content file into the output directory.

    A file whose destination already holds the same bytes is left alone, so
    a build that changed nothing writes nothing. Pass *sources* to reuse an
    existing discovery pass.
    """
    root = Path(root)
    output_root = config.output_path(root)
    if sources is None:
        sources = discover(config, root)

    outputs: dict[str, str] = {}
    manifest: dict[str, str] = {}
    for source in asset_sources(sources):
        relative = Path(source.rel)
        target = output_root / relative.parent / fingerprint_name(source.path)
        _copy(source.path, target)
        output_rel = target.relative_to(output_root).as_posix()
        outputs[source.rel] = output_rel
        manifest[_key(config, source.rel)] = "/" + output_rel
    return AssetResult(outputs=outputs, manifest=manifest)


def _copy(source: Path, target: Path) -> None:
    if target.is_file() and target.read_bytes() == source.read_bytes():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


def _key(config, rel: str) -> str:
    prefix = config.assets_dir.strip("/") + "/"
    if rel.startswith(prefix):
        rel = rel[len(prefix) :]
    return rel.rsplit(".", 1)[0]
