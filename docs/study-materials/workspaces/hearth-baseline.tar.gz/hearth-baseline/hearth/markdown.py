"""A small markdown renderer.

Supports the subset a prose site actually uses: ATX headings, paragraphs,
``**strong**``, ``*emphasis*``, inline code, fenced code blocks, links,
images, unordered and ordered lists with one level of nesting, blockquotes
and horizontal rules. Emphasis is asterisk-only so that snake_case words in
running text survive untouched. Anything that is not markup is escaped.
"""

from __future__ import annotations

import html
import re

_HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")
_FENCE = re.compile(r"^(?P<indent>\s*)(?P<ticks>`{3,})\s*(?P<lang>[\w+-]*)\s*$")
_RULE = re.compile(r"^ {0,3}(?:-{3,}|\*{3,}|_{3,})\s*$")
_QUOTE = re.compile(r"^ {0,3}>\s?(.*)$")
_BULLET = re.compile(r"^(?P<indent> *)[-*+]\s+(?P<text>.*)$")
_NUMBER = re.compile(r"^(?P<indent> *)\d+[.)]\s+(?P<text>.*)$")

_CODE_SPAN = re.compile(r"`([^`]+)`")
_IMAGE = re.compile(r"!\[([^\]]*)\]\(\s*([^)\s]+)(?:\s+\"([^\"]*)\")?\s*\)")
_LINK = re.compile(r"\[([^\]]*)\]\(\s*([^)\s]+)(?:\s+\"([^\"]*)\")?\s*\)")
_STRONG = re.compile(r"\*\*(\S(?:.*?\S)?)\*\*", re.DOTALL)
_EM = re.compile(r"\*(?!\s)([^*]+?)(?<!\s)\*")

_MARKER = "\x00%d\x00"
_MARKER_REF = re.compile(r"\x00(\d+)\x00")


def render_markdown(text: str) -> str:
    """Render *text* to an HTML fragment."""
    lines = _normalise(text)
    blocks: list[str] = []
    index = 0
    while index < len(lines):
        line = lines[index]
        if not line.strip():
            index += 1
            continue
        fence = _FENCE.match(line)
        if fence:
            block, index = _read_code(lines, index, fence)
            blocks.append(block)
            continue
        if _RULE.match(line):
            blocks.append("<hr />")
            index += 1
            continue
        heading = _HEADING.match(line)
        if heading:
            level = len(heading.group(1))
            blocks.append(f"<h{level}>{render_inline(heading.group(2))}</h{level}>")
            index += 1
            continue
        if _QUOTE.match(line):
            block, index = _read_quote(lines, index)
            blocks.append(block)
            continue
        if _BULLET.match(line) or _NUMBER.match(line):
            block, index = _read_list(lines, index)
            blocks.append(block)
            continue
        block, index = _read_paragraph(lines, index)
        blocks.append(block)
    return "\n".join(blocks)


def first_paragraph(text: str) -> str:
    """Return the text of the first paragraph, or an empty string.

    Headings, code blocks, lists and quotes are skipped over; inline markup
    is reduced to the words it decorates. Like every other value hearth hands
    to a template, the result is plain text and is not escaped.
    """
    lines = _normalise(text)
    index = 0
    while index < len(lines):
        line = lines[index]
        if not line.strip():
            index += 1
            continue
        fence = _FENCE.match(line)
        if fence:
            _, index = _read_code(lines, index, fence)
            continue
        if _RULE.match(line) or _HEADING.match(line):
            index += 1
            continue
        if _QUOTE.match(line) or _BULLET.match(line) or _NUMBER.match(line):
            index = _skip_block(lines, index)
            continue
        chunk, _ = _gather_paragraph(lines, index)
        return _strip_inline(" ".join(chunk))
    return ""


def render_inline(text: str) -> str:
    """Render inline markup inside a single run of text."""
    spans: list[str] = []

    def stash(match: re.Match) -> str:
        code = html.escape(match.group(1).strip(), quote=False)
        spans.append(f"<code>{code}</code>")
        return _MARKER % (len(spans) - 1)

    text = _CODE_SPAN.sub(stash, text)
    text = html.escape(text, quote=False)
    text = _IMAGE.sub(_image, text)
    text = _LINK.sub(_link, text)
    text = _STRONG.sub(r"<strong>\1</strong>", text)
    text = _EM.sub(r"<em>\1</em>", text)
    return _MARKER_REF.sub(lambda m: spans[int(m.group(1))], text)


def _normalise(text: str) -> list[str]:
    return text.replace("\r\n", "\n").replace("\r", "\n").expandtabs(4).split("\n")


def _attr(value: str) -> str:
    return value.replace('"', "&quot;")


def _image(match: re.Match) -> str:
    alt, src, title = match.group(1), match.group(2), match.group(3)
    extra = f' title="{_attr(title)}"' if title else ""
    return f'<img src="{_attr(src)}" alt="{_attr(alt)}"{extra} />'


def _link(match: re.Match) -> str:
    label, href, title = match.group(1), match.group(2), match.group(3)
    extra = f' title="{_attr(title)}"' if title else ""
    return f'<a href="{_attr(href)}"{extra}>{label}</a>'


def _read_code(lines: list[str], index: int, fence: re.Match) -> tuple[str, int]:
    ticks = fence.group("ticks")
    lang = fence.group("lang")
    body: list[str] = []
    index += 1
    while index < len(lines):
        closing = _FENCE.match(lines[index])
        if closing and closing.group("ticks").startswith(ticks) and not closing.group("lang"):
            index += 1
            break
        body.append(lines[index])
        index += 1
    code = html.escape("\n".join(body), quote=False)
    attr = f' class="language-{lang}"' if lang else ""
    return f"<pre><code{attr}>{code}\n</code></pre>", index


def _read_quote(lines: list[str], index: int) -> tuple[str, int]:
    inner: list[str] = []
    while index < len(lines):
        match = _QUOTE.match(lines[index])
        if match:
            inner.append(match.group(1))
        elif lines[index].strip() and inner:
            inner.append(lines[index])
        else:
            break
        index += 1
    body = render_markdown("\n".join(inner))
    return f"<blockquote>\n{body}\n</blockquote>", index


def _read_paragraph(lines: list[str], index: int) -> tuple[str, int]:
    chunk, index = _gather_paragraph(lines, index)
    return f"<p>{render_inline(' '.join(chunk))}</p>", index


def _gather_paragraph(lines: list[str], index: int) -> tuple[list[str], int]:
    chunk: list[str] = []
    while index < len(lines) and lines[index].strip() and not _starts_block(lines[index]):
        chunk.append(lines[index].strip())
        index += 1
    return chunk, index


def _starts_block(line: str) -> bool:
    return bool(
        _HEADING.match(line)
        or _FENCE.match(line)
        or _RULE.match(line)
        or _QUOTE.match(line)
        or _BULLET.match(line)
        or _NUMBER.match(line)
    )


def _skip_block(lines: list[str], index: int) -> int:
    while index < len(lines) and lines[index].strip():
        index += 1
    return index


def _read_list(lines: list[str], index: int) -> tuple[str, int]:
    pattern = _BULLET if _BULLET.match(lines[index]) else _NUMBER
    tag = "ul" if pattern is _BULLET else "ol"
    base = len(pattern.match(lines[index]).group("indent"))
    items: list[tuple[list[str], list[str]]] = []
    while index < len(lines) and lines[index].strip():
        match = _BULLET.match(lines[index]) or _NUMBER.match(lines[index])
        if match:
            indent = len(match.group("indent"))
            text = match.group("text").strip()
            if indent > base and items:
                items[-1][1].append(text)
            else:
                items.append(([text], []))
        elif items:
            items[-1][0].append(lines[index].strip())
        else:
            break
        index += 1
    return _render_items(tag, items), index


def _render_items(tag: str, items: list[tuple[list[str], list[str]]]) -> str:
    parts = [f"<{tag}>"]
    for text, nested in items:
        body = render_inline(" ".join(text))
        if nested:
            children = "".join(f"<li>{render_inline(child)}</li>" for child in nested)
            body = f"{body}\n<ul>{children}</ul>\n"
        parts.append(f"<li>{body}</li>")
    parts.append(f"</{tag}>")
    return "\n".join(parts)


def _strip_inline(text: str) -> str:
    text = _CODE_SPAN.sub(r"\1", text)
    text = re.sub(r"!\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", text)
    text = text.replace("**", "").replace("*", "")
    return " ".join(text.split())
