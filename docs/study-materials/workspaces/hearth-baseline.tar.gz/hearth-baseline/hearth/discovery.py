"""Walking the content directory and classifying what is in it."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

MARKDOWN_SUFFIXES = frozenset({".md", ".markdown"})
POSTS_DIR = "posts"
KINDS = ("post", "page", "asset")


class DiscoveryError(Exception):
    """Raised when the content directory is missing."""


@dataclass(frozen=True)
class Source:
    """One file found under the content directory.

    ``rel`` is the path relative to the content directory, using forward
    slashes, and is the key everything downstream uses to refer to the file.
    """

    path: Path
    rel: str
    kind: str  # "post", "page" or "asset"

    @property
    def stem(self) -> str:
        return Path(self.rel).stem

    @property
    def is_markdown(self) -> bool:
        return self.kind in ("post", "page")


def discover(config, root: Path | str) -> list[Source]:
    """Return every usable file under ``content/``, in a stable order.

    Markdown under ``content/posts/`` is a post, other markdown is a page,
    and everything else is an asset. Dotfiles and names starting with an
    underscore are skipped, directories included.
    """
    root = Path(root)
    content = config.content_path(root)
    if not content.is_dir():
        raise DiscoveryError(f"content directory {content} does not exist")

    sources = [_classify(path, content) for path in _walk(content)]
    sources.sort(key=lambda source: (source.kind, source.rel))
    return sources


def _walk(content: Path):
    for path in sorted(content.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(content)
        if any(_is_skipped(part) for part in relative.parts):
            continue
        yield path


def _is_skipped(name: str) -> bool:
    return name.startswith(".") or name.startswith("_")


def _classify(path: Path, content: Path) -> Source:
    relative = path.relative_to(content)
    rel = relative.as_posix()
    if path.suffix.lower() not in MARKDOWN_SUFFIXES:
        kind = "asset"
    elif relative.parts[0] == POSTS_DIR and len(relative.parts) > 1:
        kind = "post"
    else:
        kind = "page"
    return Source(path=path, rel=rel, kind=kind)


def markdown_sources(sources: list[Source]) -> list[Source]:
    """Filter *sources* down to the ones that become pages."""
    return [source for source in sources if source.is_markdown]


def asset_sources(sources: list[Source]) -> list[Source]:
    """Filter *sources* down to the ones that are copied verbatim."""
    return [source for source in sources if source.kind == "asset"]


def count_kinds(sources: list[Source]) -> dict[str, int]:
    """How many of each kind *sources* holds, including the kinds with none.

    Every kind is present in the result so that a caller reporting the
    numbers does not have to decide what an absent key means.
    """
    counts = dict.fromkeys(KINDS, 0)
    for source in sources:
        counts[source.kind] += 1
    return counts
