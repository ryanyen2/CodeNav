"""The build itself: read the site, decide what is out of date, write it."""

from __future__ import annotations

import shutil
import time
from dataclasses import dataclass
from pathlib import Path

from .assets import copy_assets
from .cache import BuildCache, cache_path, config_key, template_key
from .config import CONFIG_NAME, load_config
from .discovery import discover
from .feeds import build_feed, build_sitemap
from .indexes import Doc, build_indexes
from .pages import assemble
from .templates import Environment, render_page

AGGREGATE_KEY = "@aggregates"


@dataclass(frozen=True)
class BuildResult:
    """What one build did."""

    pages_total: int
    rebuilt: int
    aggregates_rebuilt: bool
    duration: float

    def summary(self) -> str:
        aggregates = ", aggregates rebuilt" if self.aggregates_rebuilt else ""
        return (
            f"{self.pages_total} pages, {self.rebuilt} rebuilt{aggregates}, "
            f"took {self.duration:.2f}s"
        )


def build(root: Path | str, force: bool = False) -> BuildResult:
    """Build the site rooted at *root* and return what changed."""
    started = time.perf_counter()
    root = Path(root)
    config = load_config(root)
    output_root = config.output_path(root)
    sources = discover(config, root)

    cache = BuildCache.load(root)
    keys = (config_key(root / CONFIG_NAME), template_key(config.template_path(root)))
    if force or (cache.config_key, cache.template_key) != keys:
        cache = _reset(output_root, cache_path(root))
    output_root.mkdir(parents=True, exist_ok=True)

    assets = copy_assets(config, root, sources)
    for source in sources:
        if source.kind == "asset":
            _record(output_root, cache, source.rel, source.path, [assets.outputs[source.rel]])

    env = Environment(
        config.template_path(root), globals={"site": config, "assets": assets.manifest}
    )
    collection = assemble(sources, config)

    rebuilt = 0
    for page in collection.all():
        if not cache.changed(page.rel, page.source.path) and _exists(output_root, page.output_path):
            continue
        html = render_page(_template_for(page), {"page": page}, env)
        _write(output_root, page.output_path, html)
        _record(output_root, cache, page.rel, page.source.path, [page.output_path])
        rebuilt += 1

    signature = cache.aggregate_signature(collection)
    # aggregates consume the collection; skip them when nothing they consume changed.
    aggregates_rebuilt = signature != cache.aggregate_sig
    if aggregates_rebuilt:
        docs = build_indexes(collection, config, env)
        docs.append(build_feed(collection, config))
        docs.append(build_sitemap(collection, config))
        _replace_aggregates(output_root, cache, docs)
        cache.aggregate_sig = signature

    _drop_deleted(output_root, cache, {source.rel for source in sources})
    cache.config_key, cache.template_key = keys
    cache.save()

    return BuildResult(
        pages_total=len(collection.all()),
        rebuilt=rebuilt,
        aggregates_rebuilt=aggregates_rebuilt,
        duration=time.perf_counter() - started,
    )


def clean(root: Path | str) -> list[str]:
    """Delete the output directory and the build cache."""
    root = Path(root)
    config = load_config(root)
    removed: list[str] = []
    for path in (config.output_path(root), cache_path(root).parent):
        if path.exists():
            shutil.rmtree(path)
            removed.append(path.name)
    return removed


def _template_for(page) -> str:
    """Pick a page's template, letting the file name one of its own."""
    override = page.meta.get("template")
    if isinstance(override, str) and override.strip():
        return override.strip()
    return "post.html" if page.kind == "post" else "page.html"


def _reset(output_root: Path, cache_file: Path) -> BuildCache:
    if output_root.exists():
        shutil.rmtree(output_root)
    return BuildCache(path=cache_file)


def _record(output_root: Path, cache: BuildCache, rel: str, path: Path, fresh: list[str]) -> None:
    """Record what *rel* produced, deleting whatever it produced before.

    A renamed page or a re-fingerprinted stylesheet writes under a new name,
    and the name it used last time has to go with it.
    """
    for stale in set(cache.outputs_for(rel)) - set(fresh):
        _remove(output_root, stale)
    cache.record(rel, path, fresh)


def _exists(output_root: Path, rel: str) -> bool:
    return (output_root / rel).is_file()


def _write(output_root: Path, rel: str, text: str) -> None:
    target = output_root / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")


def _replace_aggregates(output_root: Path, cache: BuildCache, docs: list[Doc]) -> None:
    fresh = [doc.output_rel for doc in docs]
    for stale in set(cache.outputs_for(AGGREGATE_KEY)) - set(fresh):
        _remove(output_root, stale)
    for doc in docs:
        _write(output_root, doc.output_rel, doc.html)
    cache.outputs[AGGREGATE_KEY] = fresh


def _drop_deleted(output_root: Path, cache: BuildCache, live: set[str]) -> None:
    for rel in sorted(cache.known() - live - {AGGREGATE_KEY}):
        for output_rel in cache.forget(rel):
            _remove(output_root, output_rel)


def _remove(output_root: Path, rel: str) -> None:
    target = output_root / rel
    if target.is_file():
        target.unlink()
    _prune(output_root, target.parent)


def _prune(output_root: Path, directory: Path) -> None:
    while directory != output_root and directory.is_relative_to(output_root):
        if any(directory.iterdir()):
            return
        directory.rmdir()
        directory = directory.parent
