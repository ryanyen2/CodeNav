"""Command line interface for hearth."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .build import build, clean
from .config import ConfigError, load_config
from .discovery import DiscoveryError, count_kinds, discover
from .frontmatter import FrontmatterError
from .pages import PageError
from .server import serve
from .templates import TemplateError

EXIT_OK = 0
EXIT_ERROR = 1

# Anything a bad site can raise. A stack trace helps nobody fix their markdown.
SITE_ERRORS = (ConfigError, DiscoveryError, FrontmatterError, PageError, TemplateError, OSError)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hearth", description="Build a markdown site.")
    parser.add_argument("--version", action="version", version=f"hearth {__version__}")
    commands = parser.add_subparsers(dest="command", required=True, metavar="command")

    builder = commands.add_parser("build", help="render the site into the output directory")
    _add_root(builder)
    builder.add_argument(
        "--force", action="store_true", help="rebuild everything, ignoring the cache"
    )
    builder.add_argument(
        "--verbose", action="store_true", help="say what the site is made of before building"
    )
    builder.set_defaults(handler=_build)

    server = commands.add_parser("serve", help="build, then serve and rebuild on change")
    _add_root(server)
    server.add_argument("--port", type=int, default=8000, help="port to listen on (default 8000)")
    server.add_argument(
        "--host", default="127.0.0.1", help="address to bind (default 127.0.0.1)"
    )
    server.set_defaults(handler=_serve)

    cleaner = commands.add_parser("clean", help="delete the output directory and the cache")
    _add_root(cleaner)
    cleaner.set_defaults(handler=_clean)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Run one command. Returns the process exit code."""
    args = build_parser().parse_args(argv)
    try:
        return args.handler(args)
    except SITE_ERRORS as exc:
        print(f"hearth: {exc}", file=sys.stderr)
        return EXIT_ERROR
    except KeyboardInterrupt:
        return EXIT_OK


def _add_root(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--root",
        type=Path,
        default=Path.cwd(),
        metavar="PATH",
        help="site directory holding hearth.toml (default: the working directory)",
    )


def _build(args) -> int:
    if args.verbose:
        _report_sources(args.root)
    result = build(args.root, force=args.force)
    print(result.summary())
    return EXIT_OK


def _report_sources(root: Path) -> None:
    """Print what the site is made of, before any of it is rendered."""
    config = load_config(root)
    counts = count_kinds(discover(config, root))
    print(f"root: {root}")
    print(f"content: {counts['post']} posts, {counts['page']} pages, {counts['asset']} assets")
    print(f"output: {config.output_path(root)}")


def _serve(args) -> int:
    if not 1 <= args.port <= 65535:
        print(f"hearth: {args.port} is not a usable port", file=sys.stderr)
        return EXIT_ERROR
    serve(args.root, port=args.port, host=args.host)
    return EXIT_OK


def _clean(args) -> int:
    removed = clean(args.root)
    print(f"removed {', '.join(removed)}" if removed else "nothing to remove")
    return EXIT_OK
