"""hearth: a small static site generator.

Turns a directory of markdown files into a browsable HTML site with tag
pages, an archive, an RSS feed and a sitemap. Everything it needs is in
the standard library.
"""

__version__ = "0.6.0"

__all__ = ["__version__"]
