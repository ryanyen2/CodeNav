"""The two machine-readable views of the site: an RSS feed and a sitemap."""

from __future__ import annotations

from datetime import date
from xml.sax.saxutils import escape

from .indexes import Doc

FEED_PATH = "feed.xml"
SITEMAP_PATH = "sitemap.xml"

_DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
_MONTHS = (
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
)


def build_feed(collection, config) -> Doc:
    """Render an RSS 2.0 document listing every post, newest first."""
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<rss version="2.0">',
        "  <channel>",
        f"    <title>{escape(config.title)}</title>",
        f"    <link>{escape(config.absolute('/'))}</link>",
        f"    <description>{escape(config.title)}</description>",
        f"    <docs>{escape(config.absolute('/' + FEED_PATH))}</docs>",
        "    <language>en</language>",
    ]
    newest = next((post.date for post in collection.posts if post.date), None)
    if newest:
        lines.append(f"    <lastBuildDate>{rfc822(newest)}</lastBuildDate>")
    for post in collection.posts:
        lines.extend(_item(post, config))
    lines.extend(["  </channel>", "</rss>", ""])
    return Doc(FEED_PATH, "\n".join(lines))


def build_sitemap(collection, config) -> Doc:
    """Render a sitemap listing every post and standalone page."""
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    ]
    for page in [*collection.posts, *collection.pages]:
        lines.append("  <url>")
        lines.append(f"    <loc>{escape(config.absolute(page.url))}</loc>")
        if page.date:
            lines.append(f"    <lastmod>{page.date.isoformat()}</lastmod>")
        lines.append("  </url>")
    lines.extend(["</urlset>", ""])
    return Doc(SITEMAP_PATH, "\n".join(lines))


def _item(post, config) -> list[str]:
    link = config.absolute(post.url)
    lines = [
        "    <item>",
        f"      <title>{escape(post.title)}</title>",
        f"      <link>{escape(link)}</link>",
        f"      <guid isPermaLink=\"true\">{escape(link)}</guid>",
    ]
    if post.date:
        lines.append(f"      <pubDate>{rfc822(post.date)}</pubDate>")
    if post.summary:
        lines.append(f"      <description>{escape(post.summary)}</description>")
    for tag in post.tags:
        lines.append(f"      <category>{escape(tag)}</category>")
    lines.append("    </item>")
    return lines


def rfc822(value: date) -> str:
    """Format a calendar date the way RSS wants it, at midnight UTC."""
    return "{day}, {d:02d} {month} {y:04d} 00:00:00 +0000".format(
        day=_DAYS[value.weekday()],
        d=value.day,
        month=_MONTHS[value.month - 1],
        y=value.year,
    )
