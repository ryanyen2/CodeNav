"""Reading and validating ``hearth.toml``."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

CONFIG_NAME = "hearth.toml"


class ConfigError(Exception):
    """Raised when hearth.toml is missing, unparseable, or has bad values."""


@dataclass(frozen=True)
class SiteConfig:
    """Everything the build needs to know about a site.

    Directory fields are names relative to the site root. Dates are handled
    as naive calendar dates throughout; the generator has no timezone
    concept and never attaches one.
    """

    title: str = "A hearth site"
    base_url: str = "http://localhost:8000"
    content_dir: str = "content"
    output_dir: str = "_site"
    template_dir: str = "templates"
    assets_dir: str = "assets"
    posts_per_page: int = 4

    def content_path(self, root: Path) -> Path:
        return Path(root) / self.content_dir

    def output_path(self, root: Path) -> Path:
        return Path(root) / self.output_dir

    def template_path(self, root: Path) -> Path:
        return Path(root) / self.template_dir

    def assets_path(self, root: Path) -> Path:
        return Path(root) / self.content_dir / self.assets_dir

    def absolute(self, url: str) -> str:
        """Join a site-root-relative url onto base_url."""
        return self.base_url.rstrip("/") + "/" + url.lstrip("/")


# field name -> (expected type, human name)
_SCHEMA: dict[str, tuple[type, str]] = {
    "title": (str, "a string"),
    "base_url": (str, "a string"),
    "content_dir": (str, "a string"),
    "output_dir": (str, "a string"),
    "template_dir": (str, "a string"),
    "assets_dir": (str, "a string"),
    "posts_per_page": (int, "an integer"),
}


def load_config(root: Path | str) -> SiteConfig:
    """Load ``hearth.toml`` from *root*.

    Raises ConfigError if the file is absent, is not valid TOML, contains a
    key hearth does not know, or gives a key the wrong type.
    """
    root = Path(root)
    path = root / CONFIG_NAME
    if not path.is_file():
        raise ConfigError(f"no {CONFIG_NAME} found in {root}")

    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"{CONFIG_NAME} is not valid TOML: {exc}") from exc
    except UnicodeDecodeError as exc:
        raise ConfigError(f"{CONFIG_NAME} is not valid UTF-8: {exc}") from exc

    site = raw.get("site", raw)
    if not isinstance(site, dict):
        raise ConfigError(f"{CONFIG_NAME}: [site] must be a table")

    return _build(site)


def _build(values: dict) -> SiteConfig:
    unknown = sorted(set(values) - set(_SCHEMA))
    if unknown:
        known = ", ".join(sorted(_SCHEMA))
        raise ConfigError(
            f"{CONFIG_NAME}: unknown key(s) {', '.join(unknown)}; known keys are {known}"
        )

    kwargs: dict[str, object] = {}
    for key, value in values.items():
        expected, described = _SCHEMA[key]
        # bool is a subclass of int, so an integer key must reject `true`.
        if not isinstance(value, expected) or (expected is int and isinstance(value, bool)):
            raise ConfigError(f"{CONFIG_NAME}: {key} must be {described}, got {value!r}")
        kwargs[key] = value

    config = SiteConfig(**kwargs)  # type: ignore[arg-type]
    _validate(config)
    return config


def _validate(config: SiteConfig) -> None:
    if not config.title.strip():
        raise ConfigError(f"{CONFIG_NAME}: title must not be empty")
    if not config.base_url.startswith(("http://", "https://")):
        raise ConfigError(
            f"{CONFIG_NAME}: base_url must start with http:// or https://, got {config.base_url!r}"
        )
    if config.posts_per_page < 1:
        raise ConfigError(
            f"{CONFIG_NAME}: posts_per_page must be at least 1, got {config.posts_per_page}"
        )
    for key in ("content_dir", "output_dir", "template_dir", "assets_dir"):
        value = getattr(config, key)
        if not value.strip():
            raise ConfigError(f"{CONFIG_NAME}: {key} must not be empty")
        if Path(value).is_absolute() or ".." in Path(value).parts:
            raise ConfigError(
                f"{CONFIG_NAME}: {key} must be a relative path inside the site, got {value!r}"
            )
