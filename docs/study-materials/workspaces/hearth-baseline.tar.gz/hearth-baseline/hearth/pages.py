"""Turning discovered markdown files into rendered pages."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date

from .discovery import Source, markdown_sources
from .frontmatter import FrontmatterError, parse_frontmatter
from .markdown import first_paragraph, render_markdown

_H1 = re.compile(r"^#\s+(.+?)\s*#*\s*$", re.MULTILINE)
_NON_SLUG = re.compile(r"[^a-z0-9]+")


class PageError(Exception):
    """Raised when a markdown file cannot be turned into a page."""


@dataclass(frozen=True)
class Page:
    """One rendered document, with the metadata aggregates read off it."""

    source: Source
    meta: dict
    title: str
    date: date | None
    tags: list[str]
    summary: str
    html: str
    url: str
    output_path: str
    kind: str

    @property
    def rel(self) -> str:
        return self.source.rel

    @property
    def slug(self) -> str:
        return self.url.strip("/").rsplit("/", 1)[-1]

    @property
    def year(self) -> int | None:
        return self.date.year if self.date else None

    @property
    def tag_links(self) -> list[dict[str, str]]:
        """The page's tags paired with the url of each tag's listing."""
        return [{"name": tag, "url": tag_url(tag)} for tag in self.tags]


@dataclass
class Collection:
    """Every page in the site, grouped the way the templates want it."""

    pages: list[Page] = field(default_factory=list)
    posts: list[Page] = field(default_factory=list)

    def all(self) -> list[Page]:
        return [*self.posts, *self.pages]

    def by_tag(self) -> dict[str, list[Page]]:
        """Map each tag to its posts, tags in alphabetical order."""
        grouped: dict[str, list[Page]] = {}
        for post in self.posts:
            for tag in post.tags:
                grouped.setdefault(tag, []).append(post)
        return {tag: grouped[tag] for tag in sorted(grouped, key=str.lower)}

    def by_year(self) -> list[tuple[int, list[Page]]]:
        """Group posts by year, newest year first."""
        grouped: dict[int, list[Page]] = {}
        for post in self.posts:
            grouped.setdefault(post.year or 0, []).append(post)
        return [(year, grouped[year]) for year in sorted(grouped, reverse=True)]


def tag_url(tag: str) -> str:
    """Site-relative url of a tag's listing."""
    return f"/tags/{slugify(tag)}/"


def slugify(value: str) -> str:
    """Reduce *value* to a lowercase, hyphen-separated url segment."""
    folded = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    slug = _NON_SLUG.sub("-", folded.lower()).strip("-")
    return slug or "untitled"


def build_page(source: Source, config) -> Page:
    """Parse and render one markdown source into a Page."""
    try:
        text = source.path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise PageError(f"{source.rel}: file is not valid UTF-8") from exc
    try:
        meta, body = parse_frontmatter(text)
    except FrontmatterError as exc:
        raise PageError(f"{source.rel}: {exc}") from exc

    slug = _slug_for(source, meta)
    title = _title_for(source, meta, body, slug)
    url = _url_for(source.kind, slug)
    return Page(
        source=source,
        meta=meta,
        title=title,
        date=_date_for(source, meta),
        tags=_tags_for(source, meta),
        summary=first_paragraph(body),
        html=render_markdown(body),
        url=url,
        output_path=url.strip("/") + "/index.html" if url != "/" else "index.html",
        kind=source.kind,
    )


def assemble(sources: list[Source], config) -> Collection:
    """Build every markdown source and sort the result into a Collection."""
    collection = Collection()
    for source in markdown_sources(sources):
        page = build_page(source, config)
        if page.kind == "post":
            collection.posts.append(page)
        else:
            collection.pages.append(page)
    collection.posts.sort(key=_post_order)
    collection.pages.sort(key=lambda page: (page.title.lower(), page.url))
    _reject_collisions(collection)
    return collection


def _post_order(page: Page) -> tuple:
    stamp = page.date or date.min
    return (-stamp.toordinal(), page.title.lower())


def _slug_for(source: Source, meta: dict) -> str:
    raw = meta.get("slug", source.stem)
    if not isinstance(raw, str):
        raise PageError(f"{source.rel}: slug must be a string, got {raw!r}")
    return slugify(raw)


def _title_for(source: Source, meta: dict, body: str, slug: str) -> str:
    raw = meta.get("title")
    if raw is None:
        heading = _H1.search(body)
        return heading.group(1).strip() if heading else slug.replace("-", " ").title()
    if not isinstance(raw, str) or not raw.strip():
        raise PageError(f"{source.rel}: title must be a non-empty string, got {raw!r}")
    return raw.strip()


def _date_for(source: Source, meta: dict) -> date | None:
    raw = meta.get("date")
    if raw is None:
        return None
    if not isinstance(raw, date):
        raise PageError(f"{source.rel}: date must be written as YYYY-MM-DD, got {raw!r}")
    return raw


def _tags_for(source: Source, meta: dict) -> list[str]:
    raw = meta.get("tags", [])
    if isinstance(raw, str):
        raw = [item.strip() for item in raw.split(",")]
    if not isinstance(raw, list):
        raise PageError(f"{source.rel}: tags must be a list, got {raw!r}")
    tags: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise PageError(f"{source.rel}: tag {item!r} is not a string")
        tag = item.strip()
        if tag and tag not in tags:
            tags.append(tag)
    return tags


def _url_for(kind: str, slug: str) -> str:
    return f"/posts/{slug}/" if kind == "post" else f"/{slug}/"


def _reject_collisions(collection: Collection) -> None:
    seen: dict[str, str] = {}
    for page in collection.all():
        if page.url in seen:
            raise PageError(
                f"{page.rel}: url {page.url} is already taken by {seen[page.url]}"
            )
        seen[page.url] = page.rel
