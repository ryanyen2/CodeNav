"""A very small template engine.

Templates are HTML with three constructs: ``{{ expression }}`` substitution,
``{% for x in xs %}``/``{% endfor %}`` loops and ``{% if x %}``/``{% else %}``/
``{% endif %}`` conditionals, plus ``{% include "partial.html" %}``. Expressions
are dotted lookups or literals, optionally piped through a filter.

Values are written out verbatim; escaping is the caller's job, which is what
lets a template drop a rendered markdown body straight into the page.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

_TOKEN = re.compile(r"\{\{(?P<var>.*?)\}\}|\{%(?P<tag>.*?)%\}", re.DOTALL)
_FOR = re.compile(r"^for\s+([A-Za-z_]\w*)\s+in\s+(.+)$")
_IF = re.compile(r"^if\s+(.+)$")
_INCLUDE = re.compile(r'^include\s+"([^"]+)"$')
_FILTER_CALL = re.compile(r"^(\w+)\((.*)\)$")
_TRAILING_INDENT = re.compile(r"\n[ \t]+$")

_UNDEFINED = object()


class TemplateError(Exception):
    """Raised for a syntax or lookup failure, tagged with template and line."""

    def __init__(self, message: str, template: str, line: int):
        super().__init__(f"{template}:{line}: {message}")
        self.template = template
        self.line = line


@dataclass
class _Text:
    text: str


@dataclass
class _Var:
    expr: str
    line: int


@dataclass
class _For:
    name: str
    iterable: str
    body: list = field(default_factory=list)
    line: int = 0


@dataclass
class _If:
    cond: str
    body: list = field(default_factory=list)
    alt: list = field(default_factory=list)
    line: int = 0


@dataclass
class _Include:
    name: str
    line: int


class Environment:
    """Loads and caches the templates in a directory.

    Names in *globals* are visible to every template and are overridden by
    anything of the same name in a render context.
    """

    def __init__(self, directory: Path | str, globals: dict | None = None):
        self.directory = Path(directory)
        self.globals: dict = dict(globals or {})
        self._cache: dict[str, list] = {}

    def source(self, name: str) -> str:
        path = self.directory / name
        if not path.is_file():
            raise TemplateError(f"no such template {name!r}", name, 0)
        return path.read_text(encoding="utf-8")

    def tree(self, name: str) -> list:
        if name not in self._cache:
            self._cache[name] = _parse(self.source(name), name)
        return self._cache[name]

    def render(self, name: str, ctx: dict) -> str:
        return _render(self.tree(name), {**self.globals, **ctx}, self, name)


def render(name: str, ctx: dict, env: Environment) -> str:
    """Render the template *name* from *env* with the mapping *ctx*."""
    return env.render(name, ctx)


def render_page(name: str, ctx: dict, env: Environment, base: str = "base.html") -> str:
    """Render *name* and wrap the result in *base* as its ``content``."""
    inner = env.render(name, ctx)
    return env.render(base, {**ctx, "content": inner})


def _parse(source: str, template: str) -> list:
    tokens = _tokenize(source, template)
    nodes, index = _parse_nodes(tokens, 0, template, stop=())
    if index != len(tokens):
        kind, body, line = tokens[index]
        raise TemplateError(f"unexpected {{% {body} %}}", template, line)
    return nodes


def _tokenize(source: str, template: str) -> list[tuple[str, str, int]]:
    tokens: list[tuple[str, str, int]] = []
    position = 0
    line = 1
    for match in _TOKEN.finditer(source):
        text = source[position : match.start()]
        is_tag = match.group("tag") is not None
        if is_tag:
            text = _TRAILING_INDENT.sub("\n", text)
        if text:
            tokens.append(("text", text, line))
        line += source.count("\n", position, match.start())
        body = (match.group("var") if not is_tag else match.group("tag")).strip()
        if not body:
            raise TemplateError("empty tag", template, line)
        tokens.append(("tag" if is_tag else "var", body, line))
        line += match.group(0).count("\n")
        position = match.end()
        if is_tag and source[position : position + 1] == "\n":
            position += 1
            line += 1
    tail = source[position:]
    if tail:
        tokens.append(("text", tail, line))
    return tokens


def _parse_nodes(tokens, index: int, template: str, stop: tuple[str, ...]):
    nodes: list = []
    while index < len(tokens):
        kind, body, line = tokens[index]
        if kind == "text":
            nodes.append(_Text(body))
            index += 1
            continue
        if kind == "var":
            nodes.append(_Var(body, line))
            index += 1
            continue
        word = body.split()[0]
        if word in stop:
            return nodes, index
        index += 1
        if match := _FOR.match(body):
            node = _For(match.group(1), match.group(2).strip(), line=line)
            node.body, index = _parse_nodes(tokens, index, template, ("endfor",))
            index = _expect(tokens, index, "endfor", template, line)
            nodes.append(node)
        elif match := _IF.match(body):
            node = _If(match.group(1).strip(), line=line)
            node.body, index = _parse_nodes(tokens, index, template, ("else", "endif"))
            if index < len(tokens) and tokens[index][1].strip() == "else":
                index += 1
                node.alt, index = _parse_nodes(tokens, index, template, ("endif",))
            index = _expect(tokens, index, "endif", template, line)
            nodes.append(node)
        elif match := _INCLUDE.match(body):
            nodes.append(_Include(match.group(1), line))
        else:
            raise TemplateError(f"unknown tag {{% {body} %}}", template, line)
    # Running out of tokens inside a block is reported by the caller's
    # _expect, which knows the line the block was opened on.
    return nodes, index


def _expect(tokens, index: int, word: str, template: str, line: int) -> int:
    if index >= len(tokens) or tokens[index][1].strip() != word:
        raise TemplateError(f"missing {{% {word} %}}", template, line)
    return index + 1


def _render(nodes: list, ctx: dict, env: Environment, template: str) -> str:
    out: list[str] = []
    for node in nodes:
        if isinstance(node, _Text):
            out.append(node.text)
        elif isinstance(node, _Var):
            value = _evaluate(node.expr, ctx, env, template, node.line)
            if value is _UNDEFINED:
                raise TemplateError(f"{node.expr!r} is not defined", template, node.line)
            out.append(_to_text(value))
        elif isinstance(node, _For):
            out.append(_render_for(node, ctx, env, template))
        elif isinstance(node, _If):
            value = _evaluate(node.cond, ctx, env, template, node.line)
            chosen = node.body if _truthy(value) else node.alt
            out.append(_render(chosen, ctx, env, template))
        elif isinstance(node, _Include):
            out.append(env.render(node.name, ctx))
    return "".join(out)


def _render_for(node: _For, ctx: dict, env: Environment, template: str) -> str:
    values = _evaluate(node.iterable, ctx, env, template, node.line)
    if values is _UNDEFINED or values is None:
        values = []
    if isinstance(values, (str, bytes)) or not hasattr(values, "__iter__"):
        raise TemplateError(f"{node.iterable!r} is not a list", template, node.line)
    out: list[str] = []
    scope = dict(ctx)
    for item in values:
        scope[node.name] = item
        out.append(_render(node.body, scope, env, template))
    return "".join(out)


def _evaluate(expr: str, ctx: dict, env: Environment, template: str, line: int):
    parts = _split_pipes(expr, template, line)
    value = _resolve(parts[0], ctx, template, line)
    for step in parts[1:]:
        value = _apply_filter(step, value, template, line)
    return value


def _split_pipes(expr: str, template: str, line: int) -> list[str]:
    parts: list[str] = []
    current: list[str] = []
    quote = ""
    depth = 0
    for char in expr:
        if quote:
            if char == quote:
                quote = ""
        elif char in "\"'":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif char == "|" and depth == 0:
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(char)
    if quote or depth:
        raise TemplateError(f"unbalanced expression {expr!r}", template, line)
    parts.append("".join(current).strip())
    if any(not part for part in parts):
        raise TemplateError(f"empty step in expression {expr!r}", template, line)
    return parts


def _resolve(expr: str, ctx: dict, template: str, line: int):
    if expr.startswith("not "):
        return not _truthy(_resolve(expr[4:].strip(), ctx, template, line))
    literal = _literal(expr)
    if literal is not _UNDEFINED:
        return literal
    if not re.fullmatch(r"[A-Za-z_]\w*(\.[A-Za-z_]\w*)*", expr):
        raise TemplateError(f"cannot read {expr!r}", template, line)
    head, *rest = expr.split(".")
    if head not in ctx:
        return _UNDEFINED
    value = ctx[head]
    for part in rest:
        if isinstance(value, dict):
            if part not in value:
                return _UNDEFINED
            value = value[part]
        elif hasattr(value, part):
            value = getattr(value, part)
        else:
            return _UNDEFINED
    return value


def _literal(expr: str):
    if len(expr) >= 2 and expr[0] == expr[-1] and expr[0] in "\"'":
        return expr[1:-1]
    if re.fullmatch(r"[+-]?\d+", expr):
        return int(expr)
    if expr == "true":
        return True
    if expr == "false":
        return False
    if expr == "none":
        return None
    return _UNDEFINED


def _apply_filter(step: str, value, template: str, line: int):
    match = _FILTER_CALL.match(step)
    name = match.group(1) if match else step
    args = _filter_args(match.group(2), template, line) if match else []
    if name not in _FILTERS:
        raise TemplateError(f"unknown filter {name!r}", template, line)
    try:
        return _FILTERS[name](value, *args)
    except TypeError as exc:
        raise TemplateError(f"filter {name!r} rejected its input: {exc}", template, line) from exc


def _filter_args(raw: str, template: str, line: int) -> list:
    raw = raw.strip()
    if not raw:
        return []
    args = []
    for piece in _split_args(raw):
        literal = _literal(piece.strip())
        if literal is _UNDEFINED:
            raise TemplateError(f"filter argument {piece.strip()!r} is not a literal", template, line)
        args.append(literal)
    return args


def _split_args(raw: str) -> list[str]:
    args: list[str] = []
    current: list[str] = []
    quote = ""
    for char in raw:
        if quote:
            if char == quote:
                quote = ""
        elif char in "\"'":
            quote = char
        elif char == ",":
            args.append("".join(current))
            current = []
            continue
        current.append(char)
    args.append("".join(current))
    return args


def _filter_date(value, fmt: str = "%Y-%m-%d") -> str:
    if value is None or value is _UNDEFINED:
        return ""
    if not isinstance(value, (date, datetime)):
        raise TypeError(f"{value!r} is not a date")
    return value.strftime(fmt)


def _filter_length(value) -> int:
    if value is None or value is _UNDEFINED:
        return 0
    return len(value)


def _filter_upper(value) -> str:
    return _to_text(value).upper()


_FILTERS = {"date": _filter_date, "length": _filter_length, "upper": _filter_upper}


def _truthy(value) -> bool:
    if value is _UNDEFINED or value is None or value is False:
        return False
    if hasattr(value, "__len__"):
        return len(value) > 0
    if isinstance(value, int):
        return value != 0
    return True


def _to_text(value) -> str:
    if value is None:
        return ""
    if value is True:
        return "true"
    if value is False:
        return "false"
    return str(value)
