"""Parsing the ``---`` fenced metadata block at the top of a markdown file.

The syntax is a deliberately small subset of YAML: one ``key: value`` pair per
line, values being strings, integers, booleans, ISO dates, or flow lists. Keys
are not interpreted in any way -- whatever a file declares is handed back to the
caller as-is.
"""

from __future__ import annotations

import re
from datetime import date

FENCE = "---"

_KEY_LINE = re.compile(r"^(?P<key>[A-Za-z_][A-Za-z0-9_.-]*)\s*:(?P<value>.*)$")
_ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_INT = re.compile(r"^[+-]?\d+$")


class FrontmatterError(Exception):
    """Raised when the metadata block is malformed.

    The message carries the 1-based line number of the offending line.
    """


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Split *text* into its metadata mapping and its markdown body.

    A file with no leading ``---`` fence has no metadata; it is returned
    unchanged alongside an empty mapping.
    """
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if lines[0].strip() != FENCE:
        return {}, text

    end = _find_close(lines)
    meta = _parse_block(lines[1:end], offset=2)
    body = "\n".join(lines[end + 1 :])
    return meta, body.lstrip("\n")


def _find_close(lines: list[str]) -> int:
    for index in range(1, len(lines)):
        if lines[index].strip() == FENCE:
            return index
    raise FrontmatterError("line 1: metadata block opened but never closed")


def _parse_block(block: list[str], offset: int) -> dict:
    meta: dict = {}
    for number, line in enumerate(block, start=offset):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if line[:1].isspace():
            raise FrontmatterError(
                f"line {number}: indented lines are not supported ({line.strip()!r})"
            )
        match = _KEY_LINE.match(line)
        if not match:
            raise FrontmatterError(f"line {number}: expected 'key: value', got {line.strip()!r}")
        key = match.group("key")
        if key in meta:
            raise FrontmatterError(f"line {number}: duplicate key {key!r}")
        meta[key] = _parse_value(match.group("value").strip(), number)
    return meta


def _parse_value(raw: str, line: int):
    if raw == "":
        return ""
    if raw.startswith("["):
        return _parse_list(raw, line)
    return _parse_scalar(raw, line)


def _parse_list(raw: str, line: int) -> list:
    if not raw.endswith("]"):
        raise FrontmatterError(f"line {line}: list is missing its closing ']'")
    inner = raw[1:-1].strip()
    if not inner:
        return []
    return [_parse_scalar(item.strip(), line) for item in _split_items(inner, line)]


def _split_items(inner: str, line: int) -> list[str]:
    """Split a flow list body on commas that are not inside quotes."""
    items: list[str] = []
    current: list[str] = []
    quote = ""
    for char in inner:
        if quote:
            if char == quote:
                quote = ""
            current.append(char)
        elif char in "\"'":
            quote = char
            current.append(char)
        elif char == ",":
            items.append("".join(current))
            current = []
        else:
            current.append(char)
    if quote:
        raise FrontmatterError(f"line {line}: unterminated {quote} string in list")
    items.append("".join(current))
    if any(not item.strip() for item in items):
        raise FrontmatterError(f"line {line}: list has an empty item")
    return items


def _parse_scalar(raw: str, line: int):
    if raw[:1] in "\"'":
        return _parse_quoted(raw, line)
    lowered = raw.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if _INT.match(raw):
        return int(raw)
    if _ISO_DATE.match(raw):
        return _parse_date(raw, line)
    return raw


def _parse_quoted(raw: str, line: int) -> str:
    quote = raw[0]
    if len(raw) < 2 or raw[-1] != quote:
        raise FrontmatterError(f"line {line}: unterminated {quote} string")
    inner = raw[1:-1]
    if quote in inner:
        raise FrontmatterError(f"line {line}: unescaped {quote} inside a quoted string")
    return inner


def _parse_date(raw: str, line: int) -> date:
    try:
        return date.fromisoformat(raw)
    except ValueError as exc:
        raise FrontmatterError(f"line {line}: {raw!r} is not a real date") from exc
