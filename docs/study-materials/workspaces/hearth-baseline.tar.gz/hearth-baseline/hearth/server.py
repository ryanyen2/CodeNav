"""A development server: serve the output directory, rebuild when it drifts.

Changes are noticed by polling modification times rather than by hooking into
the filesystem, which keeps the whole thing to the standard library and makes
a single poll cycle something a test can call directly.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable

from .build import build
from .config import CONFIG_NAME, load_config

POLL_SECONDS = 0.5
WATCHED_SUFFIXES = frozenset({".md", ".markdown", ".html", ".css", ".svg", ".png", ".jpg"})


@dataclass
class WatchState:
    """Everything a poll cycle needs: where the site is and what it looked like."""

    root: Path
    stamps: dict[str, tuple[int, int]] = field(default_factory=dict)
    log: Callable[[str], None] = print


def map_url(path: str) -> str:
    """Map a request path onto the file that backs it.

    ``/notes/`` and ``/notes`` both resolve to ``/notes/index.html``; a path
    that already names a file is left alone.
    """
    path = path.split("?", 1)[0].split("#", 1)[0]
    if not path:
        return "/index.html"
    if path.endswith("/"):
        return path + "index.html"
    if not Path(path).suffix:
        return path + "/index.html"
    return path


class SiteHandler(SimpleHTTPRequestHandler):
    """Static file handler that understands hearth's clean urls."""

    def translate_path(self, path: str) -> str:
        return super().translate_path(map_url(path))

    def end_headers(self) -> None:
        # A page rebuilt a second ago must not lose to a cached copy.
        self.send_header("Cache-Control", "no-store, must-revalidate")
        super().end_headers()

    def log_message(self, format: str, *args) -> None:
        status = args[1] if len(args) > 1 else "-"
        print(f"{self.command} {self.path} {status}")


def make_state(root: Path | str, log: Callable[[str], None] = print) -> WatchState:
    """Take the initial snapshot of everything worth watching."""
    root = Path(root)
    state = WatchState(root=root, log=log)
    state.stamps = snapshot(root)
    return state


def snapshot(root: Path | str) -> dict[str, tuple[int, int]]:
    """Map every watched file to its modification time and size."""
    root = Path(root)
    config = load_config(root)
    stamps: dict[str, tuple[int, int]] = {}
    config_file = root / CONFIG_NAME
    if config_file.is_file():
        stamps[config_file.as_posix()] = _stamp(config_file)
    for directory in (config.content_path(root), config.template_path(root)):
        if not directory.is_dir():
            continue
        for path in directory.rglob("*"):
            if _watched(path, path.relative_to(directory)):
                stamps[path.as_posix()] = _stamp(path)
    return stamps


def _stamp(path: Path) -> tuple[int, int]:
    info = path.stat()
    return info.st_mtime_ns, info.st_size


def watch_once(state: WatchState) -> bool:
    """Run one poll cycle, rebuilding if anything changed. True if it did."""
    stamps = snapshot(state.root)
    if stamps == state.stamps:
        return False
    state.stamps = stamps
    try:
        result = build(state.root)
    except Exception as exc:  # a bad edit should not take the server down
        state.log(f"build failed: {exc}")
        return False
    state.log(f"rebuilt: {result.summary()}")
    return True


def serve(root: Path | str, port: int = 8000, host: str = "127.0.0.1") -> None:
    """Build the site, serve it, and keep it in step with the sources."""
    root = Path(root)
    config = load_config(root)
    result = build(root)
    print(result.summary())

    output = config.output_path(root)
    output.mkdir(parents=True, exist_ok=True)
    handler = partial(SiteHandler, directory=str(output))
    httpd = ThreadingHTTPServer((host, port), handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    print(f"serving {output} at http://{host}:{port}/ (ctrl-c to stop)")

    state = make_state(root)
    try:
        while True:
            time.sleep(POLL_SECONDS)
            watch_once(state)
    except KeyboardInterrupt:
        print("stopping")
    finally:
        httpd.shutdown()
        httpd.server_close()


def _watched(path: Path, relative: Path) -> bool:
    if not path.is_file():
        return False
    if any(part.startswith(".") for part in relative.parts):
        return False
    return path.suffix.lower() in WATCHED_SUFFIXES
