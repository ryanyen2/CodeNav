"""The pages hearth generates rather than reads: home, tags and archive."""

from __future__ import annotations

from dataclasses import dataclass

from .pages import Page, slugify, tag_url
from .templates import Environment, render_page


@dataclass(frozen=True)
class Doc:
    """A generated file: where it goes, and what goes in it."""

    output_rel: str
    html: str


def build_indexes(collection, config, env: Environment) -> list[Doc]:
    """Render the home pagination, the tag pages and the archive."""
    docs = list(build_home(collection, config, env))
    docs.extend(build_tag_pages(collection, config, env))
    docs.append(build_tag_index(collection, config, env))
    docs.append(build_archive(collection, config, env))
    docs.extend(build_year_archives(collection, config, env))
    return docs


def build_home(collection, config, env: Environment) -> list[Doc]:
    """Render the post list, split into pages of ``posts_per_page``."""
    chunks = paginate(collection.posts, config.posts_per_page)
    docs: list[Doc] = []
    for number, chunk in enumerate(chunks, start=1):
        ctx = {
            "posts": chunk,
            "page_number": number,
            "total_pages": len(chunks),
            "prev": _link(number - 1, len(chunks)),
            "next": _link(number + 1, len(chunks)),
            "pager": pager(number, len(chunks)),
        }
        docs.append(Doc(_home_output(number), render_page("index.html", ctx, env)))
    return docs


def build_tag_pages(collection, config, env: Environment) -> list[Doc]:
    """Render one listing per tag used by at least one post."""
    docs: list[Doc] = []
    for tag, posts in collection.by_tag().items():
        ctx = {"tag": tag, "tag_url": tag_url(tag), "posts": posts}
        docs.append(Doc(f"tags/{slugify(tag)}/index.html", render_page("tag.html", ctx, env)))
    return docs


def build_tag_index(collection, config, env: Environment) -> Doc:
    """Render the list of every tag in use, with how many posts each has."""
    tags = [
        {"name": tag, "url": tag_url(tag), "count": len(posts)}
        for tag, posts in collection.by_tag().items()
    ]
    ctx = {"tags": tags, "total": len(tags)}
    return Doc("tags/index.html", render_page("tags.html", ctx, env))


def build_archive(collection, config, env: Environment) -> Doc:
    """Render every post, grouped by year, newest first."""
    years = [
        {"year": year, "url": year_url(year), "posts": posts}
        for year, posts in collection.by_year()
    ]
    ctx = {"years": years, "total": len(collection.posts)}
    return Doc("archive/index.html", render_page("archive.html", ctx, env))


def build_year_archives(collection, config, env: Environment) -> list[Doc]:
    """Render one archive page per year, so a year has a url of its own."""
    docs: list[Doc] = []
    for year, posts in collection.by_year():
        group = {"year": year, "url": year_url(year), "posts": posts}
        ctx = {"years": [group], "total": len(posts)}
        docs.append(Doc(f"archive/{year}/index.html", render_page("archive.html", ctx, env)))
    return docs


def year_url(year: int) -> str:
    """Site-relative url of a single year's archive."""
    return f"/archive/{year}/"


def paginate(posts: list[Page], per_page: int) -> list[list[Page]]:
    """Split *posts* into chunks of *per_page*, always at least one chunk."""
    if per_page < 1:
        raise ValueError("per_page must be at least 1")
    if not posts:
        return [[]]
    return [posts[start : start + per_page] for start in range(0, len(posts), per_page)]


def page_url(number: int) -> str:
    """Site-relative url of the *number*-th page of the post list."""
    return "/" if number <= 1 else f"/page/{number}/"


def pager(current: int, total: int) -> list[dict]:
    """Numbered links to every page of the post list.

    Each entry carries its number, its url, and whether it is the page being
    rendered, which is all a template needs to mark the current one.
    """
    return [
        {"number": number, "url": page_url(number), "current": number == current}
        for number in range(1, total + 1)
    ]


def _home_output(number: int) -> str:
    return "index.html" if number <= 1 else f"page/{number}/index.html"


def _link(number: int, total: int) -> dict | None:
    if number < 1 or number > total:
        return None
    return {"number": number, "url": page_url(number)}
