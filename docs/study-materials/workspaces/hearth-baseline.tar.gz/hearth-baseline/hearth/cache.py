"""The record of the previous build, kept in ``.hearth/cache.json``.

The cache answers two questions: which source files changed since last time,
and whether the values the generated listings are built out of changed. The
first is a per-file hash; the second is one signature over the whole
collection.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

CACHE_DIR = ".hearth"
CACHE_NAME = "cache.json"
CACHE_VERSION = 3


@dataclass
class BuildCache:
    """What the last build wrote, and what it wrote it from."""

    path: Path
    version: int = CACHE_VERSION
    config_key: str = ""
    template_key: str = ""
    content_keys: dict[str, str] = field(default_factory=dict)
    outputs: dict[str, list[str]] = field(default_factory=dict)
    aggregate_sig: str = ""

    @classmethod
    def load(cls, root: Path | str) -> "BuildCache":
        """Read the cache for *root*, or return an empty one.

        A cache written by a different version of hearth, or one that has
        been damaged, is discarded rather than repaired.
        """
        path = cache_path(root)
        cache = cls(path=path)
        if not path.is_file():
            return cache
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, OSError):
            return cache
        if not isinstance(data, dict) or data.get("version") != CACHE_VERSION:
            return cache
        cache.config_key = str(data.get("config_key", ""))
        cache.template_key = str(data.get("template_key", ""))
        cache.aggregate_sig = str(data.get("aggregate_sig", ""))
        cache.content_keys = _string_map(data.get("content_keys"))
        cache.outputs = _output_map(data.get("outputs"))
        return cache

    def save(self) -> None:
        """Write the cache back out, creating ``.hearth`` if needed."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": self.version,
            "config_key": self.config_key,
            "template_key": self.template_key,
            "aggregate_sig": self.aggregate_sig,
            "content_keys": self.content_keys,
            "outputs": {rel: sorted(rels) for rel, rels in sorted(self.outputs.items())},
        }
        text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
        self.path.write_text(text, encoding="utf-8")

    def changed(self, rel: str, path: Path) -> bool:
        """True when *path* differs from what the cache recorded for *rel*."""
        return self.content_keys.get(rel) != content_key(path)

    def record(self, rel: str, path: Path, outputs: list[str]) -> None:
        """Note that *rel* was built, and what it produced."""
        self.content_keys[rel] = content_key(path)
        self.outputs[rel] = list(outputs)

    def forget(self, rel: str) -> list[str]:
        """Drop *rel* from the cache and return the outputs it owned."""
        self.content_keys.pop(rel, None)
        return self.outputs.pop(rel, [])

    def known(self) -> set[str]:
        """Every source rel the cache has a record of."""
        return set(self.content_keys) | set(self.outputs)

    def outputs_for(self, rel: str) -> list[str]:
        return list(self.outputs.get(rel, []))

    def aggregate_signature(self, collection) -> str:
        """Hash the url, title, date, tags and summary of everything in *collection*."""
        posts = [
            [
                post.url,
                post.title,
                post.date.isoformat() if post.date else "",
                sorted(post.tags),
                post.summary,
            ]
            for post in collection.posts
        ]
        pages = [[page.url, page.title] for page in collection.pages]
        canonical = json.dumps(posts + pages, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def cache_path(root: Path | str) -> Path:
    return Path(root) / CACHE_DIR / CACHE_NAME


def content_key(path: Path) -> str:
    """sha256 of a file's bytes."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def config_key(path: Path) -> str:
    """sha256 of hearth.toml, so a config change forces a full rebuild."""
    path = Path(path)
    if not path.is_file():
        return ""
    return content_key(path)


def template_key(directory: Path) -> str:
    """sha256 over every template's path and bytes, in a stable order.

    Templates are shared by every output, so they are hashed as one unit.
    """
    directory = Path(directory)
    digest = hashlib.sha256()
    if not directory.is_dir():
        return digest.hexdigest()
    for path in sorted(directory.rglob("*")):
        relative = path.relative_to(directory)
        if not path.is_file() or any(part.startswith(".") for part in relative.parts):
            continue
        digest.update(relative.as_posix().encode("utf-8"))
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    return digest.hexdigest()


def _string_map(value) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(key): str(item) for key, item in value.items() if isinstance(item, str)}


def _output_map(value) -> dict[str, list[str]]:
    if not isinstance(value, dict):
        return {}
    mapping: dict[str, list[str]] = {}
    for key, item in value.items():
        if isinstance(item, list) and all(isinstance(entry, str) for entry in item):
            mapping[str(key)] = list(item)
    return mapping
