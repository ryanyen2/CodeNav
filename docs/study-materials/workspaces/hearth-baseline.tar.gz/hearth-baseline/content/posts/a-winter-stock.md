---
title: A Winter Stock
date: 2026-01-06
tags: [cooking, winter]
---

Every January I make a stock that is really just a way of using up the week
between the holidays and normal life. It is not a recipe so much as a standing
arrangement with the vegetable drawer.

What goes in:

- whatever bones are in the freezer, roasted hard until they are properly brown
- onion skins, which do more for the colour than anything else
- the green tops of leeks, the outer sticks of celery, carrot ends
- a dried mushroom or two, and one bay leaf, and nothing else

What does not go in: anything from the brassica family, anything starchy, and
salt. Salt goes in later, once you know what the stock is going to be used for
and how far it has reduced.

The only technique that matters is temperature. It should never boil. A pot
that boils gives you a cloudy, slightly grey liquid that tastes flat; a pot
held just under, so a bubble breaks every second or so, gives you something
clear that sets to a soft jelly in the fridge. Six hours at that heat, skimmed
twice in the first twenty minutes and then left alone.

It fills eight jars. By the middle of February they are gone, mostly into
weeknight soups that were decided on at half past six, which is exactly the
kind of cooking the stock exists to make possible.
