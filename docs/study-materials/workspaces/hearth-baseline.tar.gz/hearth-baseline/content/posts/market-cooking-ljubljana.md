---
title: Market Cooking in Ljubljana
date: 2025-09-13
tags: [cooking, travel]
---

The central market runs along the river under a colonnade, and the rule we
worked out on the second morning was simple: buy only what two or more stalls
were selling in quantity, cook it that evening, and do not plan further ahead
than that.

In the second week of September that meant peppers. Enormous ones, pale green
and thin-walled, sold in five kilo crates because nobody buys three peppers in
a country where everybody is putting up jars for winter. We bought the smallest
crate available and ate peppers for six days.

Roasted whole over a gas flame until the skins blister and lift, then peeled,
torn, salted, and left in oil with too much garlic. That was most nights. Once
with eggs, once folded into a stew that did not need them, once cold at eleven
in the morning straight from the bowl, standing up, which was the best of the
six.

The other thing worth carrying home was the buckwheat. Not the roasted kind
that tastes like a campfire, but the pale groats, boiled soft and finished with
butter and a spoon of the pepper oil. It is peasant food in the exact sense
that it is cheap, filling, and better than it has any need to be.

Nothing about this required a recipe, and that is the point I keep relearning.
