---
title: Samphire and Brown Butter
date: 2026-06-30
tags: [coast, cooking]
---

Marsh samphire is ready from the end of June and finished by early September,
after which it goes woody and there is a stringy core you have to draw through
your teeth. For those ten weeks it is the best thing growing within five miles
of here and it costs nothing if you are prepared to get muddy.

Pick from the creek edges where it is submerged at every high tide, not from
the top of the marsh where it grows tall and tough. Cut it rather than pulling
it up, and take a third of what is in front of you at most.

It needs almost nothing done to it. Ninety seconds in unsalted water, no more,
then straight into a pan where butter has been going quietly brown. Lemon at
the end, off the heat. No salt at any point, which people always want to add
and always regret.

I ate it three nights running last week: once on its own, once under a piece of
brill, once cold the next day with a boiled egg, which sounds like an
afterthought and was in fact the one I would repeat.

The marsh is full of people picking it badly at this time of year, tearing up
whole plants by the root. The stuff grows back from cut stems within a
fortnight. From a root it does not grow back at all.
