---
title: Sleeper Train to Bergen
date: 2026-04-19
tags: [travel, walking]
---

You leave Oslo at eleven at night and wake somewhere on the Hardangervidda with
the blind up and nothing outside but snow and telegraph poles, and it is light
at four in the morning in April, so you do not go back to sleep.

The line climbs to twelve hundred metres and stays there for an hour. There are
no trees. There are wind fences along the track for miles, wooden ones,
maintained by somebody, and occasional red huts that appear to serve no purpose
other than to be a red hut in the snow. At Finse the platform is cut through a
drift and the station sign is at chest height on a wall of white.

I got off there for a day rather than going straight through, which I recommend
if you have the time. There is no road to Finse. You arrive by train, you leave
by train, and in between you can walk out onto the glacier road for a couple of
hours in complete silence.

Coming down the west side the change is abrupt. Within forty minutes you go
from snowfields to birch scrub to full green valley with waterfalls coming off
both walls, and by the time you reach Voss it is spring and has been for weeks.

The whole trip is seven hours. It is the best seven hours of railway I know.
