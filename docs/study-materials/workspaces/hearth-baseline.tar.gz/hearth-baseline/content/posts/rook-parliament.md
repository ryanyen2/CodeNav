---
title: Notes on the Rook Parliament
date: 2025-03-09
tags: [birds, walking]
---

There is a rookery in the beeches along the lane, and for about three weeks
every March it is the loudest thing in the parish. The birds arrive in the
first week, argue for a fortnight, and then settle into the business of
raising the year's brood as though the argument had never happened.

What I did not expect, before I started paying attention, is how much of the
noise is structural. They are not calling at random. Standing underneath for
half an hour you can pick out at least three separate things going on:

- a low, continuous muttering from birds sitting on nests, which never stops
- sharp single calls from birds arriving with sticks, answered by the sitting bird
- an occasional collective uproar when something passes over, usually a buzzard

The third one is the impressive one. The whole colony goes up at once, maybe
sixty birds, circles twice, and comes back down in something close to the same
arrangement it left. Nobody appears to be in charge of this.

Rooks steal from each other constantly. A bird will leave its half-built nest
for ninety seconds and come back to find two sticks gone. The thefts are
tolerated in a way that suggests everybody is doing it, and the nests get built
regardless, which is a decent model for a lot of collaborative work.

By the end of the month the volume drops off and you stop noticing them.
