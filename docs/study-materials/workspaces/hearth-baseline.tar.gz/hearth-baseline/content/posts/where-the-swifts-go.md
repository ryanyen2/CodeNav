---
title: Where the Swifts Go
date: 2025-11-02
tags: [birds, travel]
---

The swifts left the village on the fourth of August, all of them, inside about
six hours. One evening the sky over the green was full of screaming parties
going round the chimneys, and the next evening there was nothing at all, and
the silence was genuinely startling.

They are now somewhere over the Congo basin. A bird ringed two streets away was
recovered in Mozambique some years ago, which means the pair that nested under
our neighbour's eaves have probably covered fourteen thousand miles since
Saturday week, sleeping on the wing the whole way.

That is the fact everyone repeats, and it deserves the repetition. A young
swift leaves the nest and does not land again for two or three years. It eats,
drinks, sleeps, and moults in the air. The first solid thing it touches after
fledging is the nest hole where it will breed.

I find I think about them more now they are gone than I did in July, when they
were overhead every evening and I mostly took them for weather. There is
something instructive in that, though I have not worked out what.

The nest holes stay empty until May. Every year somebody in the village blocks
one up during roof repairs, and every year the pair that used it circles the
house for a week in spring, looking for a door that is no longer there.
