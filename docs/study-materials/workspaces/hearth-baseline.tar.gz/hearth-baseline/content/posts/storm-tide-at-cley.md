---
title: Storm Tide at Cley
date: 2026-02-27
tags: [coast, winter, birds]
location: North Norfolk
---

The surge came up on a Thursday night with a north wind behind it, and by
Friday morning the shingle bank had been pushed twenty metres inland in
places and the fresh marsh behind it was salt.

I got there at low water and walked the bank as far as the beach car park,
which no longer has a road to it. The damage is not dramatic to look at. The
bank is still a bank; it is simply in a different place, lower and wider, the
way shingle always resolves an argument with the sea.

The birds had rearranged themselves overnight. Wigeon that had been on the
fresh grazing all winter were out on the new lagoon in the middle of the reeds,
several hundred of them, and there were two hundred brent geese standing in a
field of winter wheat a mile inland, which I have not seen before.

The wardens have been saying for fifteen years that the bank cannot be held
indefinitely and that the reserve will have to move backwards into the land it
has been buying for exactly this. Standing there on Friday it did not feel like
a loss so much as an appointment being kept.

By April the marsh will be fresh again in the wet parts and the sea beet will
have found the new strandline. It always does.
