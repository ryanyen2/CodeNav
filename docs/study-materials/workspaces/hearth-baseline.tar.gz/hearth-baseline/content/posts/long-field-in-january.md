---
title: The Long Field in January
date: 2025-01-18
tags: [winter, walking]
location: Norfolk
---

The long field starts behind the church and runs north until it gives up at a
drainage ditch. In January it is the emptiest place within walking distance of
the house, which is most of why I keep going back to it.

Nothing much happens there. The furrows hold water for weeks, so the whole
field reads as a run of thin grey mirrors laid end to end. When the light is
low the mirrors turn copper and the field looks considerably warmer than it is.

I walked it twice this week. On Tuesday the ground was frozen hard enough to
take my weight and I crossed the middle without thinking about it. By Friday it
had thawed and the same route cost twice the effort, every step gathering clay
until my boots were a size larger. That difference is most of what winter
walking is here: the same distance, priced differently depending on the
morning.

A hare got up about thirty yards ahead of me on the second walk and ran the
length of the headland without seeming to hurry. Hares always look like they
are running from something you cannot see.

> The field is not beautiful. It is available, every day, in whatever state the
> weather has left it, and that turns out to be the more useful quality.

I came back with wet boots and no photographs worth keeping, which is the usual
result and not a complaint.
