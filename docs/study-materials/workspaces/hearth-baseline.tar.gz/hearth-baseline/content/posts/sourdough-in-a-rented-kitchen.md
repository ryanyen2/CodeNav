---
title: Sourdough in a Rented Kitchen
date: 2025-05-22
tags: [cooking, travel]
---

I took a jar of starter to Galicia in a screw-top jar wrapped in two tea
towels, which is either dedication or a small illness. It survived the flight
and sulked for a day, and then it woke up faster than it ever does at home,
because the kitchen was eight degrees warmer than mine and the flour was
softer.

Everything I knew about the timing was wrong. At home the bulk rise takes five
hours; there it took two and a half, and the first loaf went into the oven
badly over-proved and came out flat and sour enough to make your jaw ache.

The second one I ran by feel instead of by clock:

1. Mix, rest forty minutes, then fold every half hour for two hours.
2. Stop when the dough holds a dome after a fold rather than spreading.
3. Shape cold, bake hot, and accept whatever the unfamiliar oven does.

That loaf was the best bread I made all year. Not because the method was
better, but because I had no schedule to defend and had to look at the dough
instead.

The starter came home in the same jar. It has been slow and sullen ever since,
which I choose to read as homesickness rather than as evidence that I killed
most of it somewhere over the Bay of Biscay.
