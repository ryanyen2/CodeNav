---
title: Four Days on the Cinque Terre Path
date: 2025-07-04
tags: [coast, travel, walking]
location: Liguria
---

The coastal path between the villages is not a wilderness trail. It is a
working set of terrace tracks that people have used to get to their vines for
several centuries, and the vines are still there, held up by dry stone walls
that would be a national monument anywhere else.

We walked it north to south over four days in the first week of July, which
everyone will tell you is the wrong month. They are right about the heat and
wrong about the crowds: after ten in the morning the paths above Corniglia were
almost empty, because most people were on the train between the postcard views.

The climbs are short and unreasonable. From sea level to three hundred metres
in twenty minutes of steps, then straight back down, four or five times a day.
By the third afternoon my legs had stopped negotiating.

What stays with me is not the villages but the walls. Someone stacked those
stones by hand on a slope you would not want to stand on, and then someone else
repaired them, and the whole coast is held together by that maintenance. Where
it has stopped, the terraces have slumped into scrub within a decade or two.

We ate the same thing most nights: anchovies, bread, a hard sheep cheese, and
whatever white wine the place had made itself. It was enough.
