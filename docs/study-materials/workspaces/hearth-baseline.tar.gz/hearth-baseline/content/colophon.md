---
title: Colophon
---

This site is built by hearth, a static site generator I wrote for it. Markdown
goes in, HTML comes out, and the whole thing is one command:

```sh
python3 -m hearth build
```

There is no JavaScript on any page. The type is Iowan Old Style where it is
available and Palatino or Georgia where it is not, set at a measure of about
sixty-five characters, which is as much design as I have opinions about.

The stylesheet is served with a content hash in its name so that a change to it
reaches you immediately and an unchanged one stays cached. The feed is RSS 2.0
and lists every post in full-summary form.

Photographs, when there are any, are taken on a twelve year old camera and are
not colour corrected.

Everything here is written by a person, revised by the same person a day later,
and posted with whatever mistakes survived that.
