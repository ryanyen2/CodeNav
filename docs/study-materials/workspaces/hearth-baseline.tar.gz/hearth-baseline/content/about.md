---
title: About
---

Field Notes is a record of walks, birds, coastlines and meals, kept mostly so
that I remember what happened in a given month and partly because writing an
observation down forces me to check it.

It has run since 2025. Posts appear when there is something to say, which
averages out at one or two a month and is sometimes nothing for six weeks.

Most of what is here comes from a small area of north Norfolk, with occasional
trips further out. Nothing is sponsored, nothing is affiliated, and no email
list exists. If you want to follow along there is an [RSS feed](/feed.xml).

Corrections are welcome, especially on bird identification, where I am an
enthusiastic amateur and get things wrong in public with some regularity.
