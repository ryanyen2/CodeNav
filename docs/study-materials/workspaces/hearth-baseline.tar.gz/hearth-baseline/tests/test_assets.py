import re

from hearth.assets import copy_assets, fingerprint_name
from hearth.build import build
from hearth.discovery import discover

from tests.conftest import read_output


def test_css_gets_a_content_hash(site):
    name = fingerprint_name(site / "content" / "assets" / "style.css")
    assert re.fullmatch(r"style\.[0-9a-f]{8}\.css", name)


def test_the_hash_follows_the_bytes(site):
    path = site / "content" / "assets" / "style.css"
    first = fingerprint_name(path)
    assert fingerprint_name(path) == first
    path.write_text(path.read_text(encoding="utf-8") + "\nbody { color: red; }\n", encoding="utf-8")
    assert fingerprint_name(path) != first


def test_other_types_keep_their_name(site):
    assert fingerprint_name(site / "content" / "assets" / "logo.svg") == "logo.svg"


def test_copy_writes_every_asset(site, config):
    result = copy_assets(config, site)
    assert len(result.copied) == 2
    for rel in result.copied:
        assert (site / "_site" / rel).is_file()


def test_copy_preserves_the_bytes(site, config):
    copy_assets(config, site)
    source = (site / "content" / "assets" / "logo.svg").read_bytes()
    assert (site / "_site" / "assets" / "logo.svg").read_bytes() == source


def test_the_manifest_names_the_files(site, config):
    manifest = copy_assets(config, site).manifest
    assert manifest["logo"] == "/assets/logo.svg"
    assert re.fullmatch(r"/assets/style\.[0-9a-f]{8}\.css", manifest["style"])


def test_outputs_are_keyed_by_source(site, config):
    outputs = copy_assets(config, site).outputs
    assert outputs["assets/logo.svg"] == "assets/logo.svg"
    assert outputs["assets/style.css"].startswith("assets/style.")


def test_an_unchanged_asset_is_not_rewritten(site, config):
    copy_assets(config, site)
    target = site / "_site" / "assets" / "logo.svg"
    before = target.stat().st_mtime_ns
    copy_assets(config, site)
    assert target.stat().st_mtime_ns == before


def test_copy_can_reuse_a_discovery_pass(site, config):
    sources = discover(config, site)
    assert copy_assets(config, site, sources).copied == copy_assets(config, site).copied


def test_a_site_without_assets_copies_nothing(bare, bare_config):
    result = copy_assets(bare_config, bare)
    assert result.copied == []
    assert result.manifest == {}


def test_templates_reference_the_fingerprinted_name(site, config):
    build(site)
    manifest = copy_assets(config, site).manifest
    assert f'href="{manifest["style"]}"' in read_output(site, "index.html")


def test_a_changed_stylesheet_replaces_the_old_output(site):
    build(site)
    old = next((site / "_site" / "assets").glob("style.*.css"))
    path = site / "content" / "assets" / "style.css"
    path.write_text(path.read_text(encoding="utf-8") + "\n.new { color: red; }\n", encoding="utf-8")
    build(site)
    remaining = list((site / "_site" / "assets").glob("style.*.css"))
    assert len(remaining) == 1
    assert remaining[0].name != old.name
