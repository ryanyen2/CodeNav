from hearth.markdown import first_paragraph, render_markdown, render_inline


def test_paragraphs_join_wrapped_lines():
    html = render_markdown("One line\nand its wrap.\n\nSecond.")
    assert html == "<p>One line and its wrap.</p>\n<p>Second.</p>"


def test_headings_at_every_level():
    for level in range(1, 7):
        html = render_markdown("#" * level + " Title")
        assert html == f"<h{level}>Title</h{level}>"


def test_seven_hashes_is_not_a_heading():
    assert render_markdown("####### Nope").startswith("<p>")


def test_strong_and_emphasis():
    assert render_inline("a **bold** and *slanted* word") == (
        "a <strong>bold</strong> and <em>slanted</em> word"
    )


def test_underscores_are_left_alone():
    assert render_inline("call build_page now") == "call build_page now"


def test_inline_code_is_escaped_and_not_reformatted():
    assert render_inline("use `a <b> **c**`") == "use <code>a &lt;b&gt; **c**</code>"


def test_links_and_images():
    assert render_inline("[home](/index.html)") == '<a href="/index.html">home</a>'
    assert render_inline("![alt](/x.png)") == '<img src="/x.png" alt="alt" />'
    assert render_inline('[t](/a "Why")') == '<a href="/a" title="Why">t</a>'


def test_image_wins_over_link():
    assert "<img" in render_inline("![a](/b.png)")
    assert "<a href" not in render_inline("![a](/b.png)")


def test_html_in_prose_is_escaped():
    assert render_markdown("<script>x</script>") == "<p>&lt;script&gt;x&lt;/script&gt;</p>"


def test_fenced_code_block_carries_its_language():
    html = render_markdown("```python\nprint(1)\n```")
    assert html == '<pre><code class="language-python">print(1)\n</code></pre>'


def test_fenced_code_block_without_language():
    assert render_markdown("```\nplain\n```") == "<pre><code>plain\n</code></pre>"


def test_code_block_contents_are_not_rendered():
    html = render_markdown("```\n# not a heading\n**not bold**\n```")
    assert "<h1>" not in html
    assert "<strong>" not in html


def test_unordered_list():
    html = render_markdown("- one\n- two")
    assert html == "<ul>\n<li>one</li>\n<li>two</li>\n</ul>"


def test_ordered_list():
    html = render_markdown("1. one\n2. two")
    assert html == "<ol>\n<li>one</li>\n<li>two</li>\n</ol>"


def test_nested_list_item():
    html = render_markdown("- one\n  - deeper\n- two")
    assert "<ul><li>deeper</li></ul>" in html
    assert html.count("<li>one") == 1


def test_blockquote():
    html = render_markdown("> quoted line\n> and more")
    assert html == "<blockquote>\n<p>quoted line and more</p>\n</blockquote>"


def test_horizontal_rules():
    for rule in ("---", "***", "___"):
        assert render_markdown(rule) == "<hr />"


def test_blocks_end_paragraphs():
    html = render_markdown("Text\n# Heading\nMore")
    assert html == "<p>Text</p>\n<h1>Heading</h1>\n<p>More</p>"


def test_empty_input():
    assert render_markdown("") == ""
    assert render_markdown("\n\n  \n") == ""


def test_first_paragraph_skips_leading_blocks():
    text = "# Title\n\n> a quote\n\nThe real opening.\n\nSecond paragraph."
    assert first_paragraph(text) == "The real opening."


def test_first_paragraph_strips_inline_markup():
    text = "A **bold** [link](/x) and `code` here."
    assert first_paragraph(text) == "A bold link and code here."


def test_first_paragraph_of_prose_without_one():
    assert first_paragraph("- only\n- a list") == ""
