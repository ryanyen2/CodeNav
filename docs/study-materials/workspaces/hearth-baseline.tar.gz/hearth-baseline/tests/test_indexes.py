import pytest

from hearth.discovery import discover
from hearth.indexes import (
    build_archive,
    build_home,
    build_indexes,
    build_tag_index,
    build_tag_pages,
    build_year_archives,
    page_url,
    pager,
    paginate,
    year_url,
)
from hearth.pages import assemble
from hearth.templates import Environment

from tests.conftest import write_post


@pytest.fixture
def env(site, config):
    return Environment(
        config.template_path(site),
        globals={"site": config, "assets": {"style": "/assets/style.css", "logo": "/logo.svg"}},
    )


@pytest.fixture
def collection(site, config):
    return assemble(discover(config, site), config)


def outputs(docs):
    return [doc.output_rel for doc in docs]


def test_paginate_splits_evenly_and_unevenly():
    assert paginate(list(range(8)), 4) == [[0, 1, 2, 3], [4, 5, 6, 7]]
    assert paginate(list(range(10)), 4) == [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9]]
    assert paginate(list(range(3)), 4) == [[0, 1, 2]]


def test_paginate_of_nothing_is_one_empty_page():
    assert paginate([], 4) == [[]]


def test_paginate_rejects_a_zero_page_size():
    with pytest.raises(ValueError):
        paginate([1], 0)


def test_page_url_numbering():
    assert page_url(1) == "/"
    assert page_url(2) == "/page/2/"


def test_year_url():
    assert year_url(2026) == "/archive/2026/"


def test_pager_marks_the_current_page():
    steps = pager(2, 3)
    assert [step["number"] for step in steps] == [1, 2, 3]
    assert [step["current"] for step in steps] == [False, True, False]
    assert steps[0]["url"] == "/"
    assert steps[2]["url"] == "/page/3/"


def test_ten_posts_four_per_page_makes_three_pages(collection, config, env):
    docs = build_home(collection, config, env)
    assert outputs(docs) == ["index.html", "page/2/index.html", "page/3/index.html"]


def test_first_page_has_no_previous_link(collection, config, env):
    first = build_home(collection, config, env)[0].html
    assert 'class="prev"' not in first
    assert 'href="/page/2/"' in first
    assert "Page 1 of 3" in first


def test_middle_page_links_both_ways(collection, config, env):
    middle = build_home(collection, config, env)[1].html
    assert 'href="/"' in middle
    assert 'href="/page/3/"' in middle
    assert "Page 2 of 3" in middle


def test_last_page_has_no_next_link(collection, config, env):
    last = build_home(collection, config, env)[2].html
    assert 'class="next"' not in last
    assert 'href="/page/2/"' in last
    assert "Page 3 of 3" in last


def test_pages_hold_the_right_posts(collection, config, env):
    docs = build_home(collection, config, env)
    assert docs[0].html.count('class="summary"') == 4
    assert docs[1].html.count('class="summary"') == 4
    assert docs[2].html.count('class="summary"') == 2


def test_newest_post_leads_the_first_page(collection, config, env):
    first = build_home(collection, config, env)[0].html
    assert "Samphire and Brown Butter" in first
    assert "The Long Field in January" not in first


def test_one_page_when_posts_fit(bare, bare_config):
    write_post(bare, "a", title="A", date="2026-01-01")
    env = Environment(
        bare_config.template_path(bare),
        globals={"site": bare_config, "assets": {"style": "/s.css", "logo": "/l.svg"}},
    )
    collection = assemble(discover(bare_config, bare), bare_config)
    assert outputs(build_home(collection, bare_config, env)) == ["index.html"]


def test_tag_pages_are_written_for_every_tag(collection, config, env):
    docs = build_tag_pages(collection, config, env)
    assert outputs(docs) == [
        "tags/birds/index.html",
        "tags/coast/index.html",
        "tags/cooking/index.html",
        "tags/travel/index.html",
        "tags/walking/index.html",
        "tags/winter/index.html",
    ]


def test_a_tag_page_lists_only_its_posts(collection, config, env):
    docs = {doc.output_rel: doc.html for doc in build_tag_pages(collection, config, env)}
    winter = docs["tags/winter/index.html"]
    assert "Storm Tide at Cley" in winter
    assert "Sleeper Train to Bergen" not in winter
    assert "3 posts" in winter


def test_tag_index_counts_each_tag(collection, config, env):
    html = build_tag_index(collection, config, env).html
    assert '<a href="/tags/cooking/">cooking</a> <span class="count">4</span>' in html
    assert '<a href="/tags/travel/">travel</a> <span class="count">5</span>' in html


def test_archive_groups_by_year_newest_first(collection, config, env):
    html = build_archive(collection, config, env).html
    assert html.index(">2026</a>") < html.index(">2025</a>")
    assert "10 posts" in html


def test_archive_year_headings_link_to_the_year(collection, config, env):
    html = build_archive(collection, config, env).html
    assert '<a href="/archive/2026/">2026</a>' in html


def test_each_year_gets_its_own_archive(collection, config, env):
    docs = build_year_archives(collection, config, env)
    assert outputs(docs) == ["archive/2026/index.html", "archive/2025/index.html"]
    assert "4 posts" in docs[0].html
    assert "The Long Field in January" not in docs[0].html
    assert "6 posts" in docs[1].html


def test_archive_holds_every_post(collection, config, env):
    html = build_archive(collection, config, env).html
    for post in collection.posts:
        assert f'href="{post.url}"' in html


def test_build_indexes_produces_the_whole_set(collection, config, env):
    rels = outputs(build_indexes(collection, config, env))
    assert "index.html" in rels
    assert "page/3/index.html" in rels
    assert "tags/index.html" in rels
    assert "tags/coast/index.html" in rels
    assert "archive/index.html" in rels
    assert "archive/2025/index.html" in rels
    assert len(rels) == 3 + 6 + 1 + 1 + 2
