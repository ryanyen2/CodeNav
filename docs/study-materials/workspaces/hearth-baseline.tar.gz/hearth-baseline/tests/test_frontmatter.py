from datetime import date

import pytest

from hearth.frontmatter import FrontmatterError, parse_frontmatter


def test_no_fence_means_no_metadata():
    meta, body = parse_frontmatter("Just prose.\n")
    assert meta == {}
    assert body == "Just prose.\n"


def test_splits_metadata_from_body():
    meta, body = parse_frontmatter("---\ntitle: Hello\n---\n\nFirst line.\n")
    assert meta == {"title": "Hello"}
    assert body == "First line.\n"


def test_reads_the_scalar_types():
    text = (
        "---\n"
        "title: Bare string\n"
        "quoted: \"a: colon\"\n"
        "single: 'apostrophe free'\n"
        "count: 12\n"
        "negative: -3\n"
        "flag: true\n"
        "other: False\n"
        "date: 2026-02-27\n"
        "---\n"
        "body\n"
    )
    meta, _ = parse_frontmatter(text)
    assert meta["title"] == "Bare string"
    assert meta["quoted"] == "a: colon"
    assert meta["single"] == "apostrophe free"
    assert meta["count"] == 12
    assert meta["negative"] == -3
    assert meta["flag"] is True
    assert meta["other"] is False
    assert meta["date"] == date(2026, 2, 27)


def test_reads_flow_lists():
    meta, _ = parse_frontmatter("---\ntags: [coast, winter, birds]\nempty: []\n---\n")
    assert meta["tags"] == ["coast", "winter", "birds"]
    assert meta["empty"] == []


def test_list_items_may_be_quoted_and_hold_commas():
    meta, _ = parse_frontmatter('---\ntags: ["one, two", three]\n---\n')
    assert meta["tags"] == ["one, two", "three"]


def test_unknown_keys_survive_untouched():
    text = "---\ntitle: T\nlocation: Norfolk\nlens: 35\nrevisit: true\n---\n"
    meta, _ = parse_frontmatter(text)
    assert meta["location"] == "Norfolk"
    assert meta["lens"] == 35
    assert meta["revisit"] is True


def test_empty_value_is_an_empty_string():
    meta, _ = parse_frontmatter("---\nnote:\n---\n")
    assert meta["note"] == ""


def test_comments_and_blank_lines_are_skipped():
    meta, _ = parse_frontmatter("---\n# a comment\n\ntitle: T\n---\n")
    assert meta == {"title": "T"}


def test_body_keeps_its_own_blank_lines():
    meta, body = parse_frontmatter("---\ntitle: T\n---\n\nOne.\n\nTwo.\n")
    assert body == "One.\n\nTwo.\n"


def test_unclosed_block_reports_line_one():
    with pytest.raises(FrontmatterError, match="line 1"):
        parse_frontmatter("---\ntitle: T\nstill going\n")


def test_missing_colon_reports_its_line():
    with pytest.raises(FrontmatterError, match="line 3"):
        parse_frontmatter("---\ntitle: T\nnonsense\n---\n")


def test_duplicate_key_reports_its_line():
    with pytest.raises(FrontmatterError, match="line 3"):
        parse_frontmatter("---\ntitle: One\ntitle: Two\n---\n")


def test_indented_line_is_rejected():
    with pytest.raises(FrontmatterError, match="line 3"):
        parse_frontmatter("---\ntitle: T\n  nested: no\n---\n")


def test_unterminated_quote_is_rejected():
    with pytest.raises(FrontmatterError, match="unterminated"):
        parse_frontmatter('---\ntitle: "open\n---\n')


def test_unclosed_list_is_rejected():
    with pytest.raises(FrontmatterError, match="closing"):
        parse_frontmatter("---\ntags: [a, b\n---\n")


def test_impossible_date_is_rejected():
    with pytest.raises(FrontmatterError, match="not a real date"):
        parse_frontmatter("---\ndate: 2026-02-31\n---\n")
