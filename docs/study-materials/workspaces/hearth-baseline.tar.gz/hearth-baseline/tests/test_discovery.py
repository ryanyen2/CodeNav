import pytest

from hearth.discovery import (
    DiscoveryError,
    asset_sources,
    count_kinds,
    discover,
    markdown_sources,
)

from tests.conftest import write_page, write_post


def kinds(sources):
    return {source.rel: source.kind for source in sources}


def test_finds_the_sample_site(site, config):
    found = kinds(discover(config, site))
    assert found["posts/a-winter-stock.md"] == "post"
    assert found["about.md"] == "page"
    assert found["colophon.md"] == "page"
    assert found["assets/style.css"] == "asset"
    assert found["assets/logo.svg"] == "asset"


def test_counts_of_each_kind(site, config):
    sources = discover(config, site)
    assert len(markdown_sources(sources)) == 12
    assert len(asset_sources(sources)) == 2


def test_count_kinds(site, config):
    assert count_kinds(discover(config, site)) == {"post": 10, "page": 2, "asset": 2}


def test_count_kinds_names_every_kind_even_at_zero(bare, bare_config):
    assert count_kinds(discover(bare_config, bare)) == {"post": 0, "page": 0, "asset": 0}


def test_markdown_outside_posts_is_a_page(bare, bare_config):
    write_page(bare, "notes", title="Notes")
    (bare / "content" / "guides").mkdir()
    (bare / "content" / "guides" / "one.md").write_text("---\ntitle: One\n---\n", encoding="utf-8")
    found = kinds(discover(bare_config, bare))
    assert found["notes.md"] == "page"
    assert found["guides/one.md"] == "page"


def test_markdown_directly_under_posts_is_a_post(bare, bare_config):
    write_post(bare, "one", title="One", date="2026-01-01")
    assert kinds(discover(bare_config, bare))["posts/one.md"] == "post"


def test_markdown_suffix_variants(bare, bare_config):
    (bare / "content" / "long.markdown").write_text("---\ntitle: L\n---\n", encoding="utf-8")
    assert kinds(discover(bare_config, bare))["long.markdown"] == "page"


def test_dotfiles_and_underscored_names_are_skipped(bare, bare_config):
    content = bare / "content"
    (content / ".dotfile.md").write_text("x", encoding="utf-8")
    (content / "_partial.md").write_text("x", encoding="utf-8")
    (content / "_scratch").mkdir()
    (content / "_scratch" / "note.md").write_text("x", encoding="utf-8")
    write_page(bare, "kept", title="Kept")
    assert list(kinds(discover(bare_config, bare))) == ["kept.md"]


def test_order_is_deterministic_and_groups_by_kind(site, config):
    rels = [source.rel for source in discover(config, site)]
    assert rels == [source.rel for source in discover(config, site)]
    assert rels[:2] == ["assets/logo.svg", "assets/style.css"]
    pages = [rel for rel in rels if rel in ("about.md", "colophon.md")]
    assert pages == ["about.md", "colophon.md"]


def test_source_helpers(site, config):
    source = next(s for s in discover(config, site) if s.rel == "posts/a-winter-stock.md")
    assert source.stem == "a-winter-stock"
    assert source.is_markdown is True
    assert source.path.is_file()


def test_missing_content_directory_is_an_error(tmp_path, config):
    with pytest.raises(DiscoveryError, match="does not exist"):
        discover(config, tmp_path)
