from pathlib import Path

import pytest

from hearth.build import build
from hearth.server import SiteHandler, make_state, map_url, snapshot, watch_once

from tests.conftest import write_post


class Recorder:
    """Collects the lines a watch cycle would have printed."""

    def __init__(self):
        self.lines = []

    def __call__(self, line):
        self.lines.append(line)


@pytest.fixture
def state(site):
    build(site)
    recorder = Recorder()
    return make_state(site, log=recorder), recorder


@pytest.mark.parametrize(
    "request_path, expected",
    [
        ("/", "/index.html"),
        ("/about/", "/about/index.html"),
        ("/about", "/about/index.html"),
        ("/posts/storm-tide-at-cley/", "/posts/storm-tide-at-cley/index.html"),
        ("/feed.xml", "/feed.xml"),
        ("/assets/style.a1b2c3d4.css", "/assets/style.a1b2c3d4.css"),
        ("/tags/?x=1", "/tags/index.html"),
        ("/archive/#top", "/archive/index.html"),
        ("", "/index.html"),
    ],
)
def test_map_url(request_path, expected):
    assert map_url(request_path) == expected


def resolve(root, request_path):
    """Ask a handler where a request path lands, without opening a socket."""
    handler = SiteHandler.__new__(SiteHandler)
    handler.directory = str(root / "_site")
    return Path(handler.translate_path(request_path))


def test_handler_resolves_a_clean_url_to_its_file(site):
    build(site)
    assert resolve(site, "/about/") == site / "_site" / "about" / "index.html"
    assert resolve(site, "/posts/a-winter-stock") == (
        site / "_site" / "posts" / "a-winter-stock" / "index.html"
    )


def test_handler_leaves_real_filenames_alone(site):
    build(site)
    assert resolve(site, "/feed.xml") == site / "_site" / "feed.xml"


def test_handler_stays_inside_the_output_directory(site):
    build(site)
    assert resolve(site, "/../../etc/passwd").is_relative_to(site / "_site")


def test_responses_are_not_cached(monkeypatch):
    monkeypatch.setattr(SiteHandler.__mro__[1], "end_headers", lambda self: None)
    handler = SiteHandler.__new__(SiteHandler)
    sent = []
    handler.send_header = lambda name, value: sent.append((name, value))
    handler.end_headers()
    assert ("Cache-Control", "no-store, must-revalidate") in sent


def test_snapshot_covers_content_templates_and_config(site, config):
    stamps = snapshot(site)
    assert (site / "hearth.toml").as_posix() in stamps
    assert (site / "content" / "about.md").as_posix() in stamps
    assert (config.template_path(site) / "base.html").as_posix() in stamps


def test_snapshot_leaves_out_the_output(site):
    build(site)
    stamps = snapshot(site)
    assert not any("_site" in path for path in stamps)


def test_a_quiet_cycle_does_nothing(state):
    watcher, recorder = state
    assert watch_once(watcher) is False
    assert recorder.lines == []


def test_an_edited_post_triggers_one_rebuild(state, site):
    watcher, recorder = state
    path = site / "content" / "posts" / "a-winter-stock.md"
    path.write_text(path.read_text(encoding="utf-8") + "\nA further thought.\n", encoding="utf-8")

    assert watch_once(watcher) is True
    assert len(recorder.lines) == 1
    assert recorder.lines[0].startswith("rebuilt: ")
    assert "1 rebuilt" in recorder.lines[0]
    assert "A further thought" in (site / "_site" / "posts" / "a-winter-stock" / "index.html").read_text()


def test_the_cycle_settles_again(state, site):
    watcher, _ = state
    write_post(site, "fresh", title="Fresh", date="2026-08-05")
    assert watch_once(watcher) is True
    assert watch_once(watcher) is False


def test_a_new_template_triggers_a_rebuild(state, site, config):
    watcher, _ = state
    base = config.template_path(site) / "base.html"
    base.write_text(base.read_text(encoding="utf-8").replace("</body>", "<i>x</i></body>"), "utf-8")
    assert watch_once(watcher) is True


def test_a_broken_edit_is_reported_and_survived(state, site):
    watcher, recorder = state
    path = site / "content" / "posts" / "a-winter-stock.md"
    path.write_text("---\ntitle: Broken\ndate: not-a-date\n---\n\nX.\n", encoding="utf-8")

    assert watch_once(watcher) is False
    assert recorder.lines[0].startswith("build failed: ")
    assert (site / "_site" / "index.html").is_file()
