import pytest

from hearth.config import ConfigError, SiteConfig, load_config


def write_config(root, body):
    (root / "hearth.toml").write_text(body, encoding="utf-8")
    return root


def test_reads_the_sample_config(site):
    config = load_config(site)
    assert config.title == "Field Notes"
    assert config.base_url == "https://example.com"
    assert config.posts_per_page == 4
    assert config.content_dir == "content"
    assert config.output_dir == "_site"


def test_defaults_fill_in_what_is_absent(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nbase_url = "https://t.example"\n')
    config = load_config(tmp_path)
    assert config.content_dir == "content"
    assert config.template_dir == "templates"
    assert config.assets_dir == "assets"
    assert config.posts_per_page == 4


def test_keys_may_sit_at_the_top_level(tmp_path):
    write_config(tmp_path, 'title = "T"\nbase_url = "https://t.example"\nposts_per_page = 2\n')
    assert load_config(tmp_path).posts_per_page == 2


def test_paths_are_resolved_against_the_root(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nbase_url = "https://t.example"\n')
    config = load_config(tmp_path)
    assert config.content_path(tmp_path) == tmp_path / "content"
    assert config.output_path(tmp_path) == tmp_path / "_site"
    assert config.template_path(tmp_path) == tmp_path / "templates"
    assert config.assets_path(tmp_path) == tmp_path / "content" / "assets"


def test_absolute_joins_onto_base_url():
    config = SiteConfig(base_url="https://example.com/")
    assert config.absolute("/posts/a/") == "https://example.com/posts/a/"
    assert config.absolute("feed.xml") == "https://example.com/feed.xml"


def test_a_missing_file_is_reported(tmp_path):
    with pytest.raises(ConfigError, match="no hearth.toml found"):
        load_config(tmp_path)


def test_broken_toml_is_reported(tmp_path):
    write_config(tmp_path, "[site\ntitle = ")
    with pytest.raises(ConfigError, match="not valid TOML"):
        load_config(tmp_path)


def test_an_unknown_key_is_reported(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nbase_url = "https://t.example"\nauthor = "me"\n')
    with pytest.raises(ConfigError, match="unknown key"):
        load_config(tmp_path)


def test_a_wrongly_typed_string_is_reported(tmp_path):
    write_config(tmp_path, "[site]\ntitle = 4\n")
    with pytest.raises(ConfigError, match="title must be a string"):
        load_config(tmp_path)


def test_a_wrongly_typed_integer_is_reported(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nposts_per_page = "four"\n')
    with pytest.raises(ConfigError, match="posts_per_page must be an integer"):
        load_config(tmp_path)


def test_a_boolean_is_not_an_integer(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nposts_per_page = true\n')
    with pytest.raises(ConfigError, match="posts_per_page must be an integer"):
        load_config(tmp_path)


def test_an_empty_title_is_rejected(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "   "\n')
    with pytest.raises(ConfigError, match="title must not be empty"):
        load_config(tmp_path)


def test_a_base_url_without_a_scheme_is_rejected(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nbase_url = "example.com"\n')
    with pytest.raises(ConfigError, match="must start with http"):
        load_config(tmp_path)


def test_zero_posts_per_page_is_rejected(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\nposts_per_page = 0\n')
    with pytest.raises(ConfigError, match="at least 1"):
        load_config(tmp_path)


def test_an_escaping_directory_is_rejected(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\noutput_dir = "../elsewhere"\n')
    with pytest.raises(ConfigError, match="relative path inside the site"):
        load_config(tmp_path)


def test_an_absolute_directory_is_rejected(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\ncontent_dir = "/etc"\n')
    with pytest.raises(ConfigError, match="relative path inside the site"):
        load_config(tmp_path)


def test_an_empty_directory_name_is_rejected(tmp_path):
    write_config(tmp_path, '[site]\ntitle = "T"\ntemplate_dir = ""\n')
    with pytest.raises(ConfigError, match="template_dir must not be empty"):
        load_config(tmp_path)
