import pytest

from hearth import __version__
from hearth.cli import main

from tests.conftest import write_post


def run(capsys, *argv):
    code = main(list(argv))
    captured = capsys.readouterr()
    return code, captured.out, captured.err


def test_build_reports_what_it_did(site, capsys):
    code, out, _ = run(capsys, "build", "--root", str(site))
    assert code == 0
    assert out.startswith("12 pages, 12 rebuilt, aggregates rebuilt, took ")
    assert out.rstrip().endswith("s")
    assert (site / "_site" / "index.html").is_file()


def test_a_second_build_reports_no_work(site, capsys):
    run(capsys, "build", "--root", str(site))
    code, out, _ = run(capsys, "build", "--root", str(site))
    assert code == 0
    assert "0 rebuilt" in out
    assert "aggregates" not in out


def test_force_rebuilds(site, capsys):
    run(capsys, "build", "--root", str(site))
    code, out, _ = run(capsys, "build", "--root", str(site), "--force")
    assert code == 0
    assert "12 rebuilt" in out


def test_verbose_describes_the_site_first(site, capsys):
    code, out, _ = run(capsys, "build", "--root", str(site), "--verbose")
    assert code == 0
    lines = out.splitlines()
    assert lines[0] == f"root: {site}"
    assert lines[1] == "content: 10 posts, 2 pages, 2 assets"
    assert lines[2] == f"output: {site / '_site'}"
    assert lines[3].startswith("12 pages")


def test_build_from_the_working_directory(site, capsys, monkeypatch):
    monkeypatch.chdir(site)
    code, out, _ = run(capsys, "build")
    assert code == 0
    assert "12 pages" in out


def test_clean_removes_the_output(site, capsys):
    run(capsys, "build", "--root", str(site))
    code, out, _ = run(capsys, "clean", "--root", str(site))
    assert code == 0
    assert "removed _site, .hearth" in out
    assert not (site / "_site").exists()


def test_clean_with_nothing_to_do(site, capsys):
    code, out, _ = run(capsys, "clean", "--root", str(site))
    assert code == 0
    assert "nothing to remove" in out


def test_build_then_clean_then_build(site, capsys):
    run(capsys, "build", "--root", str(site))
    run(capsys, "clean", "--root", str(site))
    write_post(site, "after", title="After", date="2026-08-09")
    code, out, _ = run(capsys, "build", "--root", str(site))
    assert code == 0
    assert "13 pages, 13 rebuilt" in out


def test_a_missing_config_exits_with_an_error(tmp_path, capsys):
    code, _, err = run(capsys, "build", "--root", str(tmp_path))
    assert code == 1
    assert "hearth: no hearth.toml found" in err


def test_a_broken_post_exits_with_an_error(site, capsys):
    path = site / "content" / "posts" / "a-winter-stock.md"
    path.write_text("---\ntitle: T\ndate: soon\n---\n\nX.\n", encoding="utf-8")
    code, _, err = run(capsys, "build", "--root", str(site))
    assert code == 1
    assert "posts/a-winter-stock.md" in err


def test_an_impossible_port_is_refused(site, capsys):
    code, _, err = run(capsys, "serve", "--root", str(site), "--port", "0")
    assert code == 1
    assert "not a usable port" in err


def test_version_is_reported(capsys):
    with pytest.raises(SystemExit) as exit_info:
        main(["--version"])
    assert exit_info.value.code == 0
    assert __version__ in capsys.readouterr().out


def test_no_command_is_a_usage_error(capsys):
    with pytest.raises(SystemExit) as exit_info:
        main([])
    assert exit_info.value.code == 2


def test_an_unknown_command_is_a_usage_error(capsys):
    with pytest.raises(SystemExit) as exit_info:
        main(["render-everything"])
    assert exit_info.value.code == 2
