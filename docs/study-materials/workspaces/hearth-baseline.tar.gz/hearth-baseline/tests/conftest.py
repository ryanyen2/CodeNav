"""Shared fixtures: a throwaway copy of the sample site for each test."""

from __future__ import annotations

import shutil
from pathlib import Path

import pytest

from hearth.config import load_config

SAMPLE_ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def site(tmp_path: Path) -> Path:
    """A writable copy of the bundled sample site."""
    root = tmp_path / "site"
    root.mkdir()
    shutil.copy(SAMPLE_ROOT / "hearth.toml", root / "hearth.toml")
    shutil.copytree(SAMPLE_ROOT / "content", root / "content")
    shutil.copytree(SAMPLE_ROOT / "templates", root / "templates")
    return root


@pytest.fixture
def config(site: Path):
    return load_config(site)


@pytest.fixture
def bare(tmp_path: Path) -> Path:
    """An empty site: config and directories, no content."""
    root = tmp_path / "bare"
    (root / "content").mkdir(parents=True)
    shutil.copytree(SAMPLE_ROOT / "templates", root / "templates")
    (root / "hearth.toml").write_text(
        '[site]\ntitle = "Bare"\nbase_url = "https://bare.example"\nposts_per_page = 2\n',
        encoding="utf-8",
    )
    return root


@pytest.fixture
def bare_config(bare: Path):
    return load_config(bare)


def write_post(root: Path, slug: str, *, title: str, date: str, tags=(), body: str = "") -> Path:
    """Write a post into a site and return its path."""
    tag_line = f"tags: [{', '.join(tags)}]\n" if tags else ""
    text = (
        f"---\ntitle: {title}\ndate: {date}\n{tag_line}---\n\n"
        f"{body or 'The opening paragraph of ' + title + '.'}\n"
    )
    path = root / "content" / "posts" / f"{slug}.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def write_page(root: Path, slug: str, *, title: str, body: str = "Text.") -> Path:
    """Write a standalone page into a site and return its path."""
    path = root / "content" / f"{slug}.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(f"---\ntitle: {title}\n---\n\n{body}\n", encoding="utf-8")
    return path


def read_output(root: Path, rel: str) -> str:
    return (root / "_site" / rel).read_text(encoding="utf-8")
