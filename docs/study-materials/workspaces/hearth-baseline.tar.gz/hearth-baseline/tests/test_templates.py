from datetime import date

import pytest

from hearth.templates import Environment, TemplateError, render, render_page


@pytest.fixture
def env(tmp_path):
    directory = tmp_path / "templates"
    directory.mkdir()
    return Environment(directory)


def put(env, name, text):
    path = env.directory / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def test_substitutes_a_plain_name(env):
    put(env, "t.html", "Hello {{ who }}.")
    assert render("t.html", {"who": "world"}, env) == "Hello world."


def test_dot_access_reaches_dicts_and_attributes(env):
    put(env, "t.html", "{{ a.b.c }} {{ d.year }}")
    ctx = {"a": {"b": {"c": "deep"}}, "d": date(2026, 5, 1)}
    assert render("t.html", ctx, env) == "deep 2026"


def test_missing_name_in_substitution_is_an_error(env):
    put(env, "t.html", "{{ nope }}")
    with pytest.raises(TemplateError, match="t.html:1"):
        render("t.html", {}, env)


def test_missing_name_in_a_condition_is_simply_false(env):
    put(env, "t.html", "{% if nope %}yes{% else %}no{% endif %}")
    assert render("t.html", {}, env) == "no"


def test_for_loop(env):
    put(env, "t.html", "{% for x in xs %}[{{ x }}]{% endfor %}")
    assert render("t.html", {"xs": [1, 2, 3]}, env) == "[1][2][3]"


def test_for_loop_over_nothing(env):
    put(env, "t.html", "{% for x in xs %}[{{ x }}]{% endfor %}done")
    assert render("t.html", {"xs": []}, env) == "done"


def test_loop_variable_does_not_leak(env):
    put(env, "t.html", "{% for x in xs %}{{ x }}{% endfor %}{% if x %}leak{% endif %}")
    assert render("t.html", {"xs": [1]}, env) == "1"


def test_nested_loops(env):
    put(env, "t.html", "{% for g in gs %}{% for n in g.ns %}{{ n }}{% endfor %};{% endfor %}")
    ctx = {"gs": [{"ns": [1, 2]}, {"ns": [3]}]}
    assert render("t.html", ctx, env) == "12;3;"


def test_if_without_else(env):
    put(env, "t.html", "{% if flag %}on{% endif %}.")
    assert render("t.html", {"flag": True}, env) == "on."
    assert render("t.html", {"flag": False}, env) == "."


def test_empty_collections_are_falsy(env):
    put(env, "t.html", "{% if xs %}some{% else %}none{% endif %}")
    assert render("t.html", {"xs": []}, env) == "none"
    assert render("t.html", {"xs": [0]}, env) == "some"


def test_not_negates(env):
    put(env, "t.html", "{% if not xs %}empty{% endif %}")
    assert render("t.html", {"xs": []}, env) == "empty"


def test_include_shares_the_context(env):
    put(env, "partials/p.html", "<b>{{ who }}</b>")
    put(env, "t.html", 'A {% include "partials/p.html" %} B')
    assert render("t.html", {"who": "x"}, env) == "A <b>x</b> B"


def test_date_filter(env):
    put(env, "t.html", '{{ d | date("%B %d, %Y") }}')
    assert render("t.html", {"d": date(2026, 2, 27)}, env) == "February 27, 2026"


def test_date_filter_default_format(env):
    put(env, "t.html", "{{ d | date }}")
    assert render("t.html", {"d": date(2026, 2, 27)}, env) == "2026-02-27"


def test_date_filter_tolerates_no_date(env):
    put(env, "t.html", '[{{ d | date("%Y") }}]')
    assert render("t.html", {"d": None}, env) == "[]"


def test_length_and_upper_filters(env):
    put(env, "t.html", "{{ xs | length }} {{ s | upper }}")
    assert render("t.html", {"xs": [1, 2], "s": "coast"}, env) == "2 COAST"


def test_filters_chain(env):
    put(env, "t.html", "{{ s | upper | length }}")
    assert render("t.html", {"s": "abc"}, env) == "3"


def test_unknown_filter_is_an_error(env):
    put(env, "t.html", "{{ s | reverse }}")
    with pytest.raises(TemplateError, match="unknown filter"):
        render("t.html", {"s": "a"}, env)


def test_globals_are_visible_and_overridable(env):
    env.globals = {"site": "global", "extra": "yes"}
    put(env, "t.html", "{{ site }} {{ extra }}")
    assert render("t.html", {"site": "local"}, env) == "local yes"


def test_render_page_wraps_in_the_base(env):
    put(env, "base.html", "<html>{{ content }}</html>")
    put(env, "inner.html", "<p>{{ x }}</p>")
    assert render_page("inner.html", {"x": "hi"}, env) == "<html><p>hi</p></html>"


def test_missing_template_reports_its_name(env):
    with pytest.raises(TemplateError, match="no such template"):
        render("absent.html", {}, env)


def test_unclosed_block_reports_template_and_line(env):
    put(env, "t.html", "line one\n{% for x in xs %}\nbody\n")
    with pytest.raises(TemplateError, match="t.html:2"):
        render("t.html", {"xs": []}, env)


def test_unknown_tag_reports_its_line(env):
    put(env, "t.html", "a\nb\n{% while x %}\n")
    with pytest.raises(TemplateError, match="t.html:3"):
        render("t.html", {}, env)


def test_block_tags_do_not_leave_blank_lines(env):
    put(env, "t.html", "start\n{% for x in xs %}\n{{ x }}\n{% endfor %}\nend\n")
    assert render("t.html", {"xs": ["a", "b"]}, env) == "start\na\nb\nend\n"


def test_templates_are_parsed_once(env):
    put(env, "t.html", "{{ x }}")
    assert render("t.html", {"x": 1}, env) == "1"
    (env.directory / "t.html").write_text("changed", encoding="utf-8")
    assert render("t.html", {"x": 1}, env) == "1"
