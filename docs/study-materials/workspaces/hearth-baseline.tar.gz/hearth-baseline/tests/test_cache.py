import json

import pytest

from hearth.cache import BuildCache, cache_path, config_key, content_key, template_key
from hearth.discovery import discover
from hearth.pages import assemble

from tests.conftest import write_post


@pytest.fixture
def cache(site):
    return BuildCache.load(site)


def collect(root, config):
    return assemble(discover(config, root), config)


def signature(root, config):
    return BuildCache.load(root).aggregate_signature(collect(root, config))


def edit(path, old, new):
    path.write_text(path.read_text(encoding="utf-8").replace(old, new), encoding="utf-8")


def test_a_missing_cache_loads_empty(site):
    cache = BuildCache.load(site)
    assert cache.content_keys == {}
    assert cache.aggregate_sig == ""
    assert cache.path == cache_path(site)


def test_save_then_load_round_trips(site):
    cache = BuildCache.load(site)
    cache.config_key = "abc"
    cache.aggregate_sig = "def"
    cache.record("posts/a.md", site / "hearth.toml", ["posts/a/index.html"])
    cache.save()

    again = BuildCache.load(site)
    assert again.config_key == "abc"
    assert again.aggregate_sig == "def"
    assert again.outputs["posts/a.md"] == ["posts/a/index.html"]


def test_a_cache_from_another_version_is_discarded(site):
    path = cache_path(site)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"version": 0, "config_key": "stale"}), encoding="utf-8")
    assert BuildCache.load(site).config_key == ""


def test_a_damaged_cache_is_discarded(site):
    path = cache_path(site)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("{not json", encoding="utf-8")
    assert BuildCache.load(site).content_keys == {}


def test_content_key_is_stable_for_unchanged_bytes(site):
    path = site / "content" / "about.md"
    first = content_key(path)
    assert first == content_key(path)
    path.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    assert content_key(path) == first


def test_content_key_moves_when_bytes_move(site):
    path = site / "content" / "about.md"
    first = content_key(path)
    path.write_text("different", encoding="utf-8")
    assert content_key(path) != first


def test_changed_reports_against_what_was_recorded(site, cache):
    path = site / "content" / "about.md"
    assert cache.changed("about.md", path) is True
    cache.record("about.md", path, ["about/index.html"])
    assert cache.changed("about.md", path) is False
    path.write_text("new text", encoding="utf-8")
    assert cache.changed("about.md", path) is True


def test_forget_returns_the_outputs_it_owned(site, cache):
    cache.record("about.md", site / "content" / "about.md", ["about/index.html"])
    assert cache.forget("about.md") == ["about/index.html"]
    assert "about.md" not in cache.known()


def test_config_key_follows_the_file(site):
    first = config_key(site / "hearth.toml")
    assert first == config_key(site / "hearth.toml")
    (site / "hearth.toml").write_text('[site]\ntitle = "Other"\n', encoding="utf-8")
    assert config_key(site / "hearth.toml") != first


def test_config_key_of_a_missing_file_is_empty(tmp_path):
    assert config_key(tmp_path / "nope.toml") == ""


def test_template_key_covers_every_template(site, config):
    directory = config.template_path(site)
    first = template_key(directory)
    assert first == template_key(directory)
    partial = directory / "partials" / "nav.html"
    partial.write_text(partial.read_text(encoding="utf-8") + "<!-- x -->", encoding="utf-8")
    assert template_key(directory) != first


def test_template_key_notices_a_new_template(site, config):
    directory = config.template_path(site)
    first = template_key(directory)
    (directory / "extra.html").write_text("<p></p>", encoding="utf-8")
    assert template_key(directory) != first


def test_aggregate_signature_is_stable(site, config):
    assert signature(site, config) == signature(site, config)


def test_aggregate_signature_moves_when_a_title_changes(site, config):
    before = signature(site, config)
    edit(site / "content" / "posts" / "a-winter-stock.md", "title: A Winter Stock", "title: Stock")
    assert signature(site, config) != before


def test_aggregate_signature_moves_when_a_date_changes(site, config):
    before = signature(site, config)
    edit(site / "content" / "posts" / "a-winter-stock.md", "2026-01-06", "2026-01-07")
    assert signature(site, config) != before


def test_aggregate_signature_moves_when_tags_change(site, config):
    before = signature(site, config)
    edit(site / "content" / "posts" / "a-winter-stock.md", "[cooking, winter]", "[cooking]")
    assert signature(site, config) != before


def test_aggregate_signature_moves_when_the_summary_changes(site, config):
    before = signature(site, config)
    edit(site / "content" / "posts" / "a-winter-stock.md", "Every January", "Each January")
    assert signature(site, config) != before


def test_aggregate_signature_moves_when_a_post_is_added(site, config):
    before = signature(site, config)
    write_post(site, "extra", title="Extra", date="2026-07-01", tags=["coast"])
    assert signature(site, config) != before


def test_aggregate_signature_moves_when_a_post_is_removed(site, config):
    before = signature(site, config)
    (site / "content" / "posts" / "a-winter-stock.md").unlink()
    assert signature(site, config) != before


def test_aggregate_signature_moves_when_a_standalone_page_is_renamed(site, config):
    before = signature(site, config)
    edit(site / "content" / "about.md", "title: About", "title: About This")
    assert signature(site, config) != before


def test_aggregate_signature_holds_for_prose_below_the_first_paragraph(site, config):
    before = signature(site, config)
    path = site / "content" / "posts" / "a-winter-stock.md"
    path.write_text(path.read_text(encoding="utf-8") + "\nA new closing thought.\n", "utf-8")
    assert signature(site, config) == before


def test_aggregate_signature_holds_for_a_reworded_later_paragraph(site, config):
    before = signature(site, config)
    edit(site / "content" / "posts" / "a-winter-stock.md", "It fills eight jars", "It fills nine jars")
    assert signature(site, config) == before
