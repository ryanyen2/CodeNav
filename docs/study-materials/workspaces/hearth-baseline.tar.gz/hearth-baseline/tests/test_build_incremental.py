from hearth.build import build, clean
from hearth.cache import BuildCache

from tests.conftest import read_output, write_post


def edit(path, old, new):
    path.write_text(path.read_text(encoding="utf-8").replace(old, new), encoding="utf-8")


def post(site, name):
    return site / "content" / "posts" / f"{name}.md"


def test_first_build_writes_everything(site):
    result = build(site)
    assert result.pages_total == 12
    assert result.rebuilt == 12
    assert result.aggregates_rebuilt is True
    assert (site / "_site" / "index.html").is_file()
    assert (site / "_site" / "posts" / "a-winter-stock" / "index.html").is_file()
    assert (site / "_site" / "feed.xml").is_file()
    assert (site / "_site" / "sitemap.xml").is_file()


def test_second_build_does_nothing(site):
    build(site)
    result = build(site)
    assert result.rebuilt == 0
    assert result.aggregates_rebuilt is False


def test_prose_edit_below_the_first_paragraph_rebuilds_one_page(site):
    build(site)
    edit(post(site, "a-winter-stock"), "It fills eight jars", "It fills nine jars")
    result = build(site)
    assert result.rebuilt == 1
    assert result.aggregates_rebuilt is False
    assert "nine jars" in read_output(site, "posts/a-winter-stock/index.html")


def test_a_title_edit_also_rebuilds_the_aggregates(site):
    build(site)
    edit(post(site, "a-winter-stock"), "title: A Winter Stock", "title: A Winter Broth")
    result = build(site)
    assert result.rebuilt == 1
    assert result.aggregates_rebuilt is True
    assert "A Winter Broth" in read_output(site, "index.html")
    assert "A Winter Broth" in read_output(site, "archive/index.html")
    assert "A Winter Broth" in read_output(site, "feed.xml")


def test_a_tag_edit_rebuilds_the_tag_pages(site):
    build(site)
    edit(post(site, "a-winter-stock"), "[cooking, winter]", "[cooking, winter, coast]")
    result = build(site)
    assert result.aggregates_rebuilt is True
    assert "A Winter Stock" in read_output(site, "tags/coast/index.html")


def test_a_new_post_appears_everywhere(site):
    build(site)
    write_post(site, "new-one", title="New One", date="2026-08-01", tags=["coast"])
    result = build(site)
    assert result.pages_total == 13
    assert result.rebuilt == 1
    assert result.aggregates_rebuilt is True
    assert "New One" in read_output(site, "index.html")
    assert "New One" in read_output(site, "tags/coast/index.html")
    assert read_output(site, "page/3/index.html").count('class="summary"') == 3


def test_deleting_a_post_removes_its_output_and_rebuilds_aggregates(site):
    build(site)
    post(site, "a-winter-stock").unlink()
    result = build(site)
    assert result.pages_total == 11
    assert result.aggregates_rebuilt is True
    assert not (site / "_site" / "posts" / "a-winter-stock").exists()
    assert "A Winter Stock" not in read_output(site, "archive/index.html")


def test_shrinking_the_post_list_drops_the_spare_page(site):
    build(site)
    assert (site / "_site" / "page" / "3" / "index.html").is_file()
    for name in ("a-winter-stock", "storm-tide-at-cley"):
        post(site, name).unlink()
    build(site)
    assert not (site / "_site" / "page" / "3").exists()
    assert (site / "_site" / "page" / "2" / "index.html").is_file()


def test_a_renamed_slug_leaves_nothing_behind(site):
    build(site)
    edit(post(site, "a-winter-stock"), "date: 2026-01-06", "date: 2026-01-06\nslug: winter-stock")
    build(site)
    assert (site / "_site" / "posts" / "winter-stock" / "index.html").is_file()
    assert not (site / "_site" / "posts" / "a-winter-stock").exists()


def test_a_missing_output_is_written_again(site):
    build(site)
    (site / "_site" / "posts" / "a-winter-stock" / "index.html").unlink()
    result = build(site)
    assert result.rebuilt == 1
    assert (site / "_site" / "posts" / "a-winter-stock" / "index.html").is_file()


def test_force_rebuilds_everything(site):
    build(site)
    result = build(site, force=True)
    assert result.rebuilt == 12
    assert result.aggregates_rebuilt is True


def test_a_template_change_rebuilds_everything(site, config):
    build(site)
    footer = config.template_path(site) / "base.html"
    edit(footer, "</body>", "<p>new footer</p>\n</body>")
    result = build(site)
    assert result.rebuilt == 12
    assert "new footer" in read_output(site, "posts/a-winter-stock/index.html")


def test_a_config_change_rebuilds_everything(site):
    build(site)
    edit(site / "hearth.toml", 'title = "Field Notes"', 'title = "Notes"')
    result = build(site)
    assert result.rebuilt == 12
    assert "Notes" in read_output(site, "index.html")


def test_changing_posts_per_page_repaginates(site):
    build(site)
    edit(site / "hearth.toml", "posts_per_page = 4", "posts_per_page = 5")
    build(site)
    assert (site / "_site" / "page" / "2" / "index.html").is_file()
    assert not (site / "_site" / "page" / "3").exists()


def test_the_cache_records_what_was_written(site):
    build(site)
    cache = BuildCache.load(site)
    assert cache.outputs["posts/a-winter-stock.md"] == ["posts/a-winter-stock/index.html"]
    assert "about.md" in cache.content_keys
    assert cache.aggregate_sig != ""


def test_clean_removes_the_output_and_the_cache(site):
    build(site)
    removed = clean(site)
    assert not (site / "_site").exists()
    assert not (site / ".hearth").exists()
    assert removed == ["_site", ".hearth"]


def test_a_build_after_clean_starts_over(site):
    build(site)
    clean(site)
    result = build(site)
    assert result.rebuilt == 12
    assert result.aggregates_rebuilt is True
