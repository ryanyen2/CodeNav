from datetime import date
from xml.etree import ElementTree

import pytest

from hearth.discovery import discover
from hearth.feeds import build_feed, build_sitemap, rfc822
from hearth.pages import assemble

from tests.conftest import write_post


@pytest.fixture
def collection(site, config):
    return assemble(discover(config, site), config)


def parse(doc):
    return ElementTree.fromstring(doc.html)


def test_feed_goes_to_feed_xml(collection, config):
    assert build_feed(collection, config).output_rel == "feed.xml"


def test_feed_is_well_formed_rss(collection, config):
    root = parse(build_feed(collection, config))
    assert root.tag == "rss"
    assert root.attrib["version"] == "2.0"
    assert root.find("channel") is not None


def test_channel_carries_the_site_details(collection, config):
    channel = parse(build_feed(collection, config)).find("channel")
    assert channel.findtext("title") == "Field Notes"
    assert channel.findtext("link") == "https://example.com/"
    assert channel.findtext("description") == "Field Notes"


def test_feed_has_one_item_per_post_newest_first(collection, config):
    items = parse(build_feed(collection, config)).find("channel").findall("item")
    assert len(items) == 10
    assert items[0].findtext("title") == "Samphire and Brown Butter"
    assert items[-1].findtext("title") == "The Long Field in January"


def test_items_carry_absolute_links(collection, config):
    item = parse(build_feed(collection, config)).find("channel").find("item")
    assert item.findtext("link") == "https://example.com/posts/samphire-and-brown-butter/"
    assert item.find("guid").attrib["isPermaLink"] == "true"


def test_items_carry_the_summary_and_tags(collection, config):
    item = parse(build_feed(collection, config)).find("channel").find("item")
    assert item.findtext("description").startswith("Marsh samphire is ready")
    assert [c.text for c in item.findall("category")] == ["coast", "cooking"]


def test_pubdate_is_rfc822(collection, config):
    item = parse(build_feed(collection, config)).find("channel").find("item")
    assert item.findtext("pubDate") == "Tue, 30 Jun 2026 00:00:00 +0000"


def test_rfc822_formatting():
    assert rfc822(date(2025, 1, 18)) == "Sat, 18 Jan 2025 00:00:00 +0000"
    assert rfc822(date(2026, 12, 1)) == "Tue, 01 Dec 2026 00:00:00 +0000"


def test_feed_escapes_markup_in_titles(bare, bare_config):
    write_post(bare, "p", title="Bread & Butter", date="2026-01-01", body="A <thing> here.")
    collection = assemble(discover(bare_config, bare), bare_config)
    doc = build_feed(collection, bare_config)
    assert "&amp;" in doc.html
    item = parse(doc).find("channel").find("item")
    assert item.findtext("title") == "Bread & Butter"
    assert item.findtext("description") == "A <thing> here."


def test_empty_site_still_makes_a_feed(bare, bare_config):
    collection = assemble(discover(bare_config, bare), bare_config)
    root = parse(build_feed(collection, bare_config))
    assert root.find("channel").findall("item") == []


def test_sitemap_goes_to_sitemap_xml(collection, config):
    assert build_sitemap(collection, config).output_rel == "sitemap.xml"


def test_sitemap_lists_posts_and_pages(collection, config):
    root = parse(build_sitemap(collection, config))
    locations = [element.text for element in root.iter() if element.tag.endswith("loc")]
    assert len(locations) == 12
    assert "https://example.com/posts/storm-tide-at-cley/" in locations
    assert "https://example.com/about/" in locations
    assert "https://example.com/colophon/" in locations


def test_sitemap_dates_only_where_there_is_one(collection, config):
    root = parse(build_sitemap(collection, config))
    entries = [element for element in root.iter() if element.tag.endswith("url")]
    dated = [e for e in entries if e.find("{*}lastmod") is not None]
    assert len(dated) == 10
