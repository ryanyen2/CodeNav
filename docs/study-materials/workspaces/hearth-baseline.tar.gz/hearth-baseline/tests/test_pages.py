from datetime import date

import pytest

from hearth.discovery import discover
from hearth.pages import PageError, assemble, build_page, slugify, tag_url

from tests.conftest import write_page, write_post


def collect(root, config):
    return assemble(discover(config, root), config)


def find(root, config, rel):
    source = next(s for s in discover(config, root) if s.rel == rel)
    return build_page(source, config)


def test_post_url_and_output_path(bare, bare_config):
    write_post(bare, "storm-tide", title="Storm Tide", date="2026-02-27")
    page = find(bare, bare_config, "posts/storm-tide.md")
    assert page.url == "/posts/storm-tide/"
    assert page.output_path == "posts/storm-tide/index.html"
    assert page.kind == "post"


def test_page_url_and_output_path(bare, bare_config):
    write_page(bare, "about", title="About")
    page = find(bare, bare_config, "about.md")
    assert page.url == "/about/"
    assert page.output_path == "about/index.html"
    assert page.kind == "page"


def test_slug_comes_from_the_filename(bare, bare_config):
    write_post(bare, "A Messy Name", title="T", date="2026-01-01")
    page = find(bare, bare_config, "posts/A Messy Name.md")
    assert page.url == "/posts/a-messy-name/"
    assert page.slug == "a-messy-name"


def test_slug_can_be_overridden(bare, bare_config):
    path = bare / "content" / "posts" / "long-file-name.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("---\ntitle: T\ndate: 2026-01-01\nslug: short\n---\n\nX.\n", encoding="utf-8")
    assert find(bare, bare_config, "posts/long-file-name.md").url == "/posts/short/"


def test_title_falls_back_to_the_first_heading(bare, bare_config):
    path = bare / "content" / "notes.md"
    path.write_text("---\nlocation: X\n---\n\n# Read Me\n\nBody.\n", encoding="utf-8")
    assert find(bare, bare_config, "notes.md").title == "Read Me"


def test_title_falls_back_to_the_slug(bare, bare_config):
    (bare / "content" / "odds-and-ends.md").write_text("Body only.\n", encoding="utf-8")
    assert find(bare, bare_config, "odds-and-ends.md").title == "Odds And Ends"


def test_summary_is_the_first_paragraph(bare, bare_config):
    write_post(
        bare,
        "p",
        title="P",
        date="2026-01-01",
        body="# Heading\n\nThe opening claim.\n\nA later paragraph.",
    )
    page = find(bare, bare_config, "posts/p.md")
    assert page.summary == "The opening claim."


def test_unknown_metadata_reaches_the_page(bare, bare_config):
    path = bare / "content" / "posts" / "p.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "---\ntitle: P\ndate: 2026-01-01\nlocation: Norfolk\nlens: 35\n---\n\nX.\n",
        encoding="utf-8",
    )
    page = find(bare, bare_config, "posts/p.md")
    assert page.meta["location"] == "Norfolk"
    assert page.meta["lens"] == 35


def test_html_is_rendered(bare, bare_config):
    write_post(bare, "p", title="P", date="2026-01-01", body="A **bold** claim.")
    assert "<strong>bold</strong>" in find(bare, bare_config, "posts/p.md").html


def test_tags_are_read_deduplicated_and_ordered(bare, bare_config):
    write_post(bare, "p", title="P", date="2026-01-01", tags=["coast", "winter", "coast"])
    page = find(bare, bare_config, "posts/p.md")
    assert page.tags == ["coast", "winter"]
    assert page.tag_links[0] == {"name": "coast", "url": "/tags/coast/"}


def test_posts_sort_by_date_descending(bare, bare_config):
    write_post(bare, "old", title="Old", date="2025-01-01")
    write_post(bare, "new", title="New", date="2026-01-01")
    write_post(bare, "mid", title="Mid", date="2025-06-01")
    assert [p.title for p in collect(bare, bare_config).posts] == ["New", "Mid", "Old"]


def test_posts_on_the_same_day_sort_by_title(bare, bare_config):
    write_post(bare, "b", title="Bravo", date="2026-01-01")
    write_post(bare, "a", title="Alpha", date="2026-01-01")
    assert [p.title for p in collect(bare, bare_config).posts] == ["Alpha", "Bravo"]


def test_collection_separates_pages_from_posts(site, config):
    collection = collect(site, config)
    assert len(collection.posts) == 10
    assert [p.title for p in collection.pages] == ["About", "Colophon"]
    assert len(collection.all()) == 12


def test_by_tag_groups_and_sorts(site, config):
    grouped = collect(site, config).by_tag()
    assert list(grouped) == ["birds", "coast", "cooking", "travel", "walking", "winter"]
    assert len(grouped["cooking"]) == 4
    assert [p.title for p in grouped["winter"]][0] == "Storm Tide at Cley"


def test_by_year_groups_newest_first(site, config):
    years = collect(site, config).by_year()
    assert [year for year, _ in years] == [2026, 2025]
    assert len(years[0][1]) == 4
    assert len(years[1][1]) == 6


def test_pages_have_no_date(site, config):
    about = next(p for p in collect(site, config).pages if p.title == "About")
    assert about.date is None
    assert about.year is None


def test_dates_are_parsed(site, config):
    post = next(p for p in collect(site, config).posts if p.title == "A Winter Stock")
    assert post.date == date(2026, 1, 6)
    assert post.year == 2026


def test_bad_date_is_rejected(bare, bare_config):
    path = bare / "content" / "posts" / "p.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("---\ntitle: P\ndate: yesterday\n---\n\nX.\n", encoding="utf-8")
    with pytest.raises(PageError, match="YYYY-MM-DD"):
        find(bare, bare_config, "posts/p.md")


def test_bad_tags_are_rejected(bare, bare_config):
    path = bare / "content" / "posts" / "p.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("---\ntitle: P\ntags: 12\n---\n\nX.\n", encoding="utf-8")
    with pytest.raises(PageError, match="tags must be a list"):
        find(bare, bare_config, "posts/p.md")


def test_broken_frontmatter_names_the_file(bare, bare_config):
    path = bare / "content" / "posts" / "p.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("---\ntitle: P\nbroken\n---\n", encoding="utf-8")
    with pytest.raises(PageError, match="posts/p.md"):
        find(bare, bare_config, "posts/p.md")


def test_two_pages_cannot_claim_one_url(bare, bare_config):
    write_post(bare, "same", title="One", date="2026-01-01")
    path = bare / "content" / "posts" / "other.md"
    path.write_text("---\ntitle: Two\ndate: 2026-01-02\nslug: same\n---\n\nX.\n", encoding="utf-8")
    with pytest.raises(PageError, match="already taken"):
        collect(bare, bare_config)


def test_slugify():
    assert slugify("Storm Tide at Cley") == "storm-tide-at-cley"
    assert slugify("  Spaces  &  Symbols! ") == "spaces-symbols"
    assert slugify("Café Crème") == "cafe-creme"
    assert slugify("???") == "untitled"


def test_tag_url():
    assert tag_url("Sea Birds") == "/tags/sea-birds/"
