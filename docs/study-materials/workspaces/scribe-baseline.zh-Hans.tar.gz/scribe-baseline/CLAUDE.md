# CLAUDE.md

此文件在本仓库中工作时，为 Claude Code（claude.ai/code）提供指导。

## Commands

该仓库不自带 `.venv`；README 中的 `.venv/bin/...` 调用默认你已经创建了一个：

```bash
python3 -m venv .venv
.venv/bin/pip install -e ".[dev]"     # installs pytest and the `scribe` console script
```

日常使用（从仓库根目录运行——`scribe/` 可从当前目录导入，所以只有 console script 需要可编辑安装）：

```bash
python -m pytest tests/ -q                                  # full suite, ~0.3s
python -m pytest tests/test_rules.py -q                      # one file
python -m pytest tests/test_rules.py::test_a_decimal_is_not_a_footnote_marker -q   # one test
python -m pytest -k furniture -q                             # one policy area

python -m scribe.cli convert fixtures/report.txt             # writes report.md beside it
python -m scribe.cli convert fixtures/report.txt -           # writes to stdout
python -m scribe.cli check fixtures/                         # converts every .txt, writes nothing
```

`check` 是快速查看某个 rule change 在整个语料库中的影响范围的方式：它会为每个文档打印一行摘要（`report.txt: 3 pages, 8 headings, 12 paragraphs, ...`），且不会触碰任何文件。这里没有配置 linter 或 formatter，也没有 runtime dependencies。

## Architecture

输入是 `pdftotext` 或类似工具的输出：一个字符串，页与页之间用 form feeds 分隔。输出是
Markdown。所有事情都在进程内完成；`convert.convert(raw) -> Converted` 是纯的，而 `cli.py` 是
围绕它做文件 I/O 的薄封装。

### One structural module, six policy modules

`lines.py` 是唯一描述文档“原样是什么”的模块。它把由 form-feed 分隔的字符串解析为 `Document -> Page -> Line`，并去除行尾空白；除此之外不做任何判断。每个 `Line` 都带有 `page`、`index`、`total_on_page` 以及派生出的 `from_top` / `from_bottom` —— 这些是 furniture 和 footnote rules 所依赖的位置元数据，之后无法再恢复。

其他每个模块都是一种 *policy*：仅凭文本本身，对文本含义的一种猜测。每个模块都拥有自己的猜测，并在模块 docstring 中说明拒绝了什么替代方案以及代价是什么。`furniture.py`（running headers、page numbers），`paragraphs.py`（dehyphenation、paragraph breaks、reflow），`blocks.py`（headings、bullets、blank space），`notes.py`（footnotes），`text.py`（ligatures、smart punctuation）。

### The pipeline order is load-bearing

`convert.convert` 按固定顺序运行这些 rules，而这最容易让你感到意外：

1. `lines.read` — string into `Document`.
2. `furniture.strip` — **before** anything looks for headings. A running header is usually the
   section title, so it looks exactly like a heading; stripping first means the heading rule never
   sees it. `tests/test_rules.py::test_furniture_runs_before_headings_and_that_is_load_bearing`
   pins this. Note `strip` mutates the `Document` in place; `convert` measures the drop by
   comparing `len(doc.lines)` before and after.
3. `_collect_notes` — **before** reflow, or a note at the foot of a page gets glued to the last
   sentence above it. This is also the last step that can see positional data: it consumes the
   `Document` and returns `list[str]`. Anything needing `from_bottom` must run at or before this
   point. It appends a blank line at each page boundary so reflow gets the chance to decide whether
   the sentence runs on.
4. `blocks.collapse_blanks` — runs of blanks to one.
5. The main loop — headings and bullets are decided line by line (both are properties of a single
   line); everything between them accumulates into a prose `run` that is flushed through
   `paragraphs.reflow` whenever a heading or bullet interrupts, so a paragraph broken across a
   heading is never silently joined.
6. Footnote definitions appended, `_join` inserts blank lines between blocks (skipping between
   consecutive bullets, which would make a loose list).
7. `text.normalise` — **last**, so every rule above sees the text as it came out of the PDF rather
   than a partly rewritten version.

Two non-obvious control-flow details: `blocks.heading_level` takes the *following* line as a lookahead
(a heading has space under it; a wrapped numbered list item runs straight on), and
`paragraphs.reflow` rebuilds its own `lines` list mid-loop to push the remainder of a dehyphenated
line back onto the queue so the rest of it still passes through every rule.

### Tuning constants

The behaviour of this program is mostly these numbers. Each is commented at its definition with the
failure that motivated it:

- `furniture.EDGE` (2), `MIN_PAGE` (6), `REPEAT_SHARE` (0.6), plus a hard floor of 3 pages before
  furniture detection runs at all.
- `blocks.MAX_HEADING_WORDS` (12) — the only thing separating "3. Findings" from a wrapped list item.
- `paragraphs.KEEP_HYPHEN` — prefixes whose hyphen survives a line break; and the 60-character
  threshold in `is_break`.
- `notes.looks_like_note`'s `from_bottom <= 6`.
- `notes.MARKER` deliberately excludes a preceding digit, so decimals and years are not footnote
  references.

## Tests

Two files, two jobs. `tests/test_rules.py` is one test per policy, with a final section for the
places two policies meet — that section is where a change to one rule shows up as a break in another.
`tests/test_documents.py` runs the three fixtures end to end.

The fixtures are the spec, and each covers something the others cannot: `report.txt` has furniture,
footnotes and numbered headings; `memo.txt` has none of those and is what makes "keep the running
header" a live alternative; `handbook.txt` has deep numbering plus a numbered list that must not
become headings. A new rule generally needs a fixture change or a new fixture, not just a unit test.

## Conventions

这里的 docstrings 承载的是论证，而不是机制——规则做什么、被否决的替代方案是什么、以及当前选择付出的代价。在添加或修改 policy 时请保持这一点；没有说明代价的 rule 看起来就像没有缺点。tests 中的 comments 记录的是该 test 编写时所针对的 bug。
