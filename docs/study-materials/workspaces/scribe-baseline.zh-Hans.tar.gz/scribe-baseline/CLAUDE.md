# Codebase feature guide

## 提取文本准备

从 PDF 中抽出的文本会作为一个长字符串到达，页面之间用换页符分隔，而页眉页脚也一起带了进来：每页顶部重复的运行页眉，页脚的页码。这些功能先把这个字符串变成页面和行，再把版面元素去掉，这样后续规则读到的是文档本身，而不是它印在纸上的样子。

### 提取页模型

在每个换页符处分割原始字符串得到页面，再把每一页分成行。

一行知道三件事：它的文本、它来自哪一页，以及它在那一页上的位置。这就是全部模型，而且这是刻意如此——下游的一切都是基于这三件事实做出的猜测。任何需要知道字体、颜色，或者文字在纸面上具体位置的规则，都不能在这里写，除非改变 scribe 的本质。

Code: `scribe/lines.py::Document`, `scribe/lines.py::Document.lines`, `scribe/lines.py::Line`, `scribe/lines.py::Line.from_bottom`, `scribe/lines.py::Line.from_top`, `scribe/lines.py::Line.is_blank`, `scribe/lines.py::PAGE_BREAK`, `scribe/lines.py::Page`, `scribe/lines.py::__module__`, `scribe/lines.py::read`

### 页眉移除

去掉运行页眉、页脚和页码。

当一行位于页面顶部或底部附近，并且相同文本在至少 60% 的页面上重复出现时，它就算版面元素。重复是唯一可用的信号，这带来两个值得知道的后果：单页信件永远不会显示出这一点，所以它的页眉会保留；而恰好重复的真实标题会和版面元素一起被丢掉。这个步骤在查找标题之前运行，所以后面的任何步骤都救不回来。

Code: `scribe/furniture.py::EDGE`, `scribe/furniture.py::MIN_PAGE`, `scribe/furniture.py::PAGE_NUMBER`, `scribe/furniture.py::REPEAT_SHARE`, `scribe/furniture.py::__module__`, `scribe/furniture.py::_near_edge`, `scribe/furniture.py::_normalise`, `scribe/furniture.py::find_repeated`, `scribe/furniture.py::is_page_number`, `scribe/furniture.py::strip`

## 清洁 Markdown

一旦版面元素被去掉，剩下的就是经过排字工处理的散文：段落被拆成多行，单词在边缘处被拆开，脚注被留在页底，引用符号也不是键盘上的那些。这些功能把它重新拼成 Markdown。

### 提取文本流水线

按一个固定顺序运行各个阶段：先去掉版面元素，再找出块，收集脚注，重新拼接段落，最后整理字符。

这个顺序就是设计本身。版面元素先处理，这样运行中的页眉就不会被误认为标题；字符最后整理，这样在它之前的每条规则看到的文本都和 PDF 给出的一模一样。移动某个阶段，规则就会开始看到已经被另一个阶段改过的文本。

Code: `scribe/convert.py::Converted`, `scribe/convert.py::Converted.summary`, `scribe/convert.py::_Collected`, `scribe/convert.py::__module__`, `scribe/convert.py::_collect_notes`, `scribe/convert.py::_join`, `scribe/convert.py::convert`

### 文本块规则

决定哪些行是标题，哪些行是项目符号。

标题是一行编号文本——`3.`、`3.1`、`3.1.4 Findings`——且不超过十二个词。问题在于，编号列表项看起来完全一样，所以要看下一行来判断：标题下面是空行，换行续写的列表项则会直接接下去。这就是为什么 `3. We asked each participant to describe what they had understood.` 不是标题——太长了，而且下面只有散文。

Code: `scribe/blocks.py::BULLET`, `scribe/blocks.py::MAX_HEADING_WORDS`, `scribe/blocks.py::NUMBERED`, `scribe/blocks.py::__module__`, `scribe/blocks.py::bullet`, `scribe/blocks.py::collapse_blanks`, `scribe/blocks.py::heading_level`

### 脚注识别

找出脚注并把它们转换成 Markdown 引用。

脚注是位于页面底部附近的编号行；页面中部同样的形状则是列表项，所以位置决定了它们的区别。正文中的标记是连在单词末尾的数字——`comparable.1`。数字前面的字符是故意限制的：曾经允许任何句点，结果文档里的每个小数——`0.8`、`3.14`——都变成了脚注引用。

Code: `scribe/notes.py::MARKER`, `scribe/notes.py::NOTE_LINE`, `scribe/notes.py::__module__`, `scribe/notes.py::looks_like_note`, `scribe/notes.py::mark`, `scribe/notes.py::split_note`

### 段落重排

把段落重新拼起来，并修复排字工拆开的单词。

普通换行会被合并；空行或以句号结尾的短行会结束段落。边缘处被拆开的单词会重新拼接，连字符会被去掉，所以 `photogram-` + `metry` 变成 `photogrammetry`。不过有些连字符本来就属于单词，所以一小组前缀会保留它们自己的连字符：`well-` + `being` 仍然是 `well-being`。仅凭文本无法分辨真正的复合词和换行，这就是这个列表存在的原因。

Code: `scribe/paragraphs.py::HYPHEN_END`, `scribe/paragraphs.py::KEEP_HYPHEN`, `scribe/paragraphs.py::SENTENCE_END`, `scribe/paragraphs.py::__module__`, `scribe/paragraphs.py::dehyphenate`, `scribe/paragraphs.py::is_break`, `scribe/paragraphs.py::reflow`

### 排字字符归一

把排字工的字符替换成普通字符：连字、弯引号、短横线和长横线、不换行空格。

所以 `ﬁ` 会变成 `fi`，弯的 `’` 会变成 `'`。这样做是故意牺牲排版保真度——输出是为了被 grep、diff 和粘贴而设计的，而这些操作面对无法输入的字符都不太好用。

Code: `scribe/text.py::SUBSTITUTIONS`, `scribe/text.py::__module__`, `scribe/text.py::normalise`

## 运行转换

实际运行的方式：转换一个文件，将结果打印出来而不是写入文件，或者检查整个文件夹而不触碰任何内容。

### 命令行转换接口

`convert report.txt` 会在旁边写出 `report.md`；`convert report.txt -` 则改为打印到标准输出。

`check fixtures/` 会转换文件夹中的每个文件而不写入任何内容，并为每个文档打印一行。这是在提交规则变更之前，快速查看它对整个语料库造成什么影响的方式。

Code: `scribe/cli.py::__module__`, `scribe/cli.py::_convert_one`, `scribe/cli.py::main`

## 检查转换

测试是规则被固定下来的地方，因为其中大多数都是判断题，在你看到它们试图防止什么之前，看起来都像是武断的。

### 端到端测试

端到端运行三个示例文档。

每个文档覆盖的内容都不同：`report.txt` 有版面元素、脚注和编号标题；`memo.txt` 一个都没有，这正是让保留运行页眉成为一个现实选项而不是假设的原因；`handbook.txt` 有深层编号和一个绝不能变成标题的编号列表。fixtures 就是规范。

Code: `tests/test_documents.py::FIXTURES`, `tests/test_documents.py::__module__`, `tests/test_documents.py::md`, `tests/test_documents.py::test_a_numbered_list_does_not_become_headings`, `tests/test_documents.py::test_a_paragraph_broken_across_a_page_is_rejoined`, `tests/test_documents.py::test_a_two_page_memo_keeps_its_first_line`, `tests/test_documents.py::test_a_word_split_across_a_line_break_is_whole_again`, `tests/test_documents.py::test_a_word_split_across_a_page_is_handled_the_same_way`, `tests/test_documents.py::test_bullets_are_a_tight_list`, `tests/test_documents.py::test_converting_twice_gives_the_same_thing`, `tests/test_documents.py::test_decimals_survive`, `tests/test_documents.py::test_deep_numbering_becomes_deep_headings`, `tests/test_documents.py::test_footnotes_are_collected_at_the_end`, `tests/test_documents.py::test_headings_carry_their_depth`, `tests/test_documents.py::test_ligatures_are_normalised`, `tests/test_documents.py::test_no_document_ends_up_empty`, `tests/test_documents.py::test_no_form_feed_survives`, `tests/test_documents.py::test_no_three_blank_lines_in_a_row`, `tests/test_documents.py::test_the_bullet_character_is_recognised`, `tests/test_documents.py::test_the_memo_has_no_headings`, `tests/test_documents.py::test_the_page_numbers_are_gone`, `tests/test_documents.py::test_the_running_header_is_gone_from_the_report`

### 规则回归测试

每条规则一个测试，再加上一节处理两条规则相遇的地方——而这正是修改其中一条会在另一条上表现为破坏的地方。

这些测试记录边界：版面元素移除发生在标题之前，小数点不是脚注标记，哪些连字符能在换行处保留。规则改了却不更新这些测试，往往会把它本来要移除的版面伪影带回来。

Code: `tests/test_rules.py::__module__`, `tests/test_rules.py::page`, `tests/test_rules.py::test_a_bare_number_at_the_foot_is_a_page_number`, `tests/test_rules.py::test_a_blank_line_always_breaks`, `tests/test_rules.py::test_a_dash_before_a_number_is_not_a_broken_word`, `tests/test_rules.py::test_a_dash_with_no_space_is_prose`, `tests/test_rules.py::test_a_decimal_is_not_a_footnote_marker`, `tests/test_rules.py::test_a_line_on_every_page_near_the_top_is_furniture`, `tests/test_rules.py::test_a_long_numbered_line_is_a_list_item_not_a_heading`, `tests/test_rules.py::test_a_marker_welded_to_a_word_becomes_a_reference`, `tests/test_rules.py::test_a_number_in_the_middle_of_a_page_is_not`, `tests/test_rules.py::test_a_numbered_line_at_the_foot_is_a_note`, `tests/test_rules.py::test_a_real_compound_keeps_its_hyphen`, `tests/test_rules.py::test_a_running_header_with_a_changing_number_still_counts`, `tests/test_rules.py::test_a_short_line_ending_a_sentence_breaks`, `tests/test_rules.py::test_a_single_newline_continues_the_paragraph`, `tests/test_rules.py::test_a_two_page_document_has_no_furniture`, `tests/test_rules.py::test_a_typeset_hyphen_is_dropped`, `tests/test_rules.py::test_a_year_is_not_a_footnote_marker`, `tests/test_rules.py::test_an_unnumbered_line_is_not_a_heading`, `tests/test_rules.py::test_furniture_runs_before_headings_and_that_is_load_bearing`, `tests/test_rules.py::test_leading_and_trailing_blanks_go`, `tests/test_rules.py::test_ligatures_and_quotes_are_normalised`, `tests/test_rules.py::test_numbering_gives_the_depth`, `tests/test_rules.py::test_runs_of_blank_lines_become_one`, `tests/test_rules.py::test_the_same_line_in_the_middle_of_a_page_is_not`, `tests/test_rules.py::test_the_three_bullet_marks`

## 包标识元数据

命名这个包及其版本：scribe 会把从 PDF 中提取出来的文本转换成干净的 Markdown。

Code: `scribe/__init__.py::__module__`
