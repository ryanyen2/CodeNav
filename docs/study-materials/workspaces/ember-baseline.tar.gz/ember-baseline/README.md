# ember

A feed reader that writes a daily digest. It reads RSS and Atom feeds into a
local sqlite store, then generates one HTML page per day of arrivals, a
browsable archive with a search corpus, and a log of what came in. Python 3.11
or later, standard library only, no dependencies.

Work is done twice over, at two levels. Each item is stored once and left alone
on later runs, keyed by an identity taken from the feed's own guid. Each day's
digest page is written again only when the items it selected would come out
different.

Network fetching is stubbed in this build. A feed's url is a local file, so the
bundled sample data under `fixtures/feeds/` runs the whole pipeline offline.

## Quickstart

```sh
python3 -m ember refresh                  # read every feed, store what it holds
python3 -m ember digest                   # write the digests, archive and log
python3 -m ember digest --date 2026-08-10 # write one day
python3 -m ember archive                  # write the archive pages on their own
python3 -m ember status                   # what has been read, and when
```

Every command takes `--root PATH` if the workspace is not the working directory.

## Layout

```
ember.toml            workspace configuration
feeds.toml            the feeds to read, and how much of each to take
fixtures/feeds/*.xml  the sample feed documents
templates/            digest.html, archive.html, feed-archive.html, partials/
_digest/              generated: <date>.html, latest.html, archive/,
                      notifications.log
.ember/               generated: ember.db and the state each layer writes
```

## Configuration

`ember.toml`, all keys optional:

| key | default | meaning |
| --- | --- | --- |
| `title` | `An ember digest` | name shown on every page |
| `data_dir` | `.ember` | where the store and the state live |
| `output_dir` | `_digest` | where the generated pages go |
| `template_dir` | `templates` | where the templates live |
| `digest_items_max` | `20` | most items on one day's page |

`feeds.toml` holds one `[[feed]]` table per feed, with `name` (a slug, and the
identity the feed keeps in the store), `url` (a `file://` url or a path from the
workspace root) and an optional `max_items`, which is how many entries one run
takes from the front of the document.

## Tests

```sh
python3 -m pytest tests/
```
