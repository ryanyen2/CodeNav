# ember — feature guide

## Starting and configuring Ember

This group covers how Ember starts up, finds a workspace, and reads the files that define that workspace. It includes the command entry points, configuration loading, path setup, and the status view that reports what the workspace contains.

### Package metadata export

Provides the package version at import time so other code can identify this release without reaching into internal modules. It also carries the package docstring that explains Ember as a feed reader that builds a daily digest, archive, search corpus, and arrival log.

Code: `ember/__init__.py::__module__`

### Module entry point launcher

Starts the package when someone runs python -m ember, then hands control to the CLI main function and exits with its status code so the process reports success or failure correctly.

Code: `ember/__main__.py::__module__`

### Command line entrypoint

Runs ember from the shell, parses the top-level commands, and turns workspace problems into a clean exit code and error message. It centralizes the user-facing commands so the rest of the application can stay focused on feed, digest, and storage work without worrying about argument parsing or process handling.

Code: `ember/cli.py::EXIT_ERROR`, `ember/cli.py::EXIT_OK`, `ember/cli.py::WORKSPACE_ERRORS`, `ember/cli.py::__module__`, `ember/cli.py::_add_root`, `ember/cli.py::_day`, `ember/cli.py::build_parser`, `ember/cli.py::main`

#### Refresh and digest commands

Implements the commands that update stored content: refresh reads feeds into the store, archive summarizes the current archive state, and digest runs the full update flow and records notifications. These handlers are grouped because they all drive the same workspace update pipeline and print the resulting summaries for the user.

Code: `ember/cli.py::_archive`, `ember/cli.py::_digest`, `ember/cli.py::_refresh`

### Workspace status reporting

Shows what the current workspace contains by reading the config, feed list, and store, then printing counts and per-feed freshness. It keeps the status view in one place so changes to the stored data model or feed metadata only need to be reflected here.

Code: `ember/cli.py::_status`, `ember/cli.py::_when`

### Workspace configuration loading

Reads ember.toml from a workspace, checks that its keys and values make sense, and turns it into a validated config object. It keeps bad files from slipping through by rejecting missing files, invalid TOML, unknown keys, wrong types, empty paths, and directories that would escape the workspace. The config object also carries the workspace paths Ember uses for data, output, and templates.

Config is resolved once at startup and passed down explicitly. We rejected an ambient module-level config: every function that read it became untestable without monkeypatching, and two runs in one process (refresh followed by digest) would fight over it.

Code: `ember/config.py::CONFIG_NAME`, `ember/config.py::ConfigError`, `ember/config.py::EmberConfig`, `ember/config.py::EmberConfig.data_path`, `ember/config.py::EmberConfig.output_path`, `ember/config.py::EmberConfig.template_path`, `ember/config.py::__module__`, `ember/config.py::_build`, `ember/config.py::_validate`, `ember/config.py::load_config`

## Reading feeds and storing items

This group covers the flow from feed sources into Ember’s local store. It includes loading feed lists, resolving and parsing feed documents, normalizing entries, refreshing feeds, deduplicating items, and the SQLite storage layer that keeps the collected data on disk.

### Feed list loader

Reads the workspace feed manifest and turns each table into a validated feed specification. It keeps the file format strict so bad TOML, missing files, duplicate names, malformed entries, unknown keys, or bad item limits fail fast instead of producing a partial feed list.

Code: `ember/feeds.py::DEFAULT_MAX_ITEMS`, `ember/feeds.py::FEEDS_NAME`, `ember/feeds.py::FeedSpec`, `ember/feeds.py::FeedsError`, `ember/feeds.py::__module__`, `ember/feeds.py::_build`, `ember/feeds.py::_reject_repeats`, `ember/feeds.py::load_feeds`

### Feed document parsing

Turns raw RSS or Atom XML into a parsed feed with plain entry records. It accepts both formats, keeps the original text and dates unchanged, and raises a parse error when the document is not well formed or is not a feed, so later code can normalize one consistent shape.

Code: `ember/parse.py::ParseError`, `ember/parse.py::ParsedFeed`, `ember/parse.py::RawEntry`, `ember/parse.py::__module__`, `ember/parse.py::_atom_entry`, `ember/parse.py::_atom_link`, `ember/parse.py::_child`, `ember/parse.py::_children`, `ember/parse.py::_first_text`, `ember/parse.py::_guid_as_link`, `ember/parse.py::_local`, `ember/parse.py::_parse_atom`, `ember/parse.py::_parse_rss`, `ember/parse.py::_rss_entry`, `ember/parse.py::_text`, `ember/parse.py::parse_feed`

### Entry normalization pipeline

Turns parsed feed entries into the items ember stores and shows. It cleans markup and whitespace, trims long summaries, extracts a displayable author, resolves a usable date, and assigns a stable identity so repeated fetches do not create duplicates.

Code: `ember/normalize.py::Item`, `ember/normalize.py::SUMMARY_LIMIT`, `ember/normalize.py::UNTITLED`, `ember/normalize.py::__module__`, `ember/normalize.py::clean_text`, `ember/normalize.py::content_hash`, `ember/normalize.py::item_identity`, `ember/normalize.py::normalize_entries`, `ember/normalize.py::normalize_entry`, `ember/normalize.py::person`, `ember/normalize.py::truncate`, `ember/store.py::_to_item`

#### Feed date parsing helpers

Reads dates from the formats feed generators commonly emit and falls back to the fetch day when nothing usable is present. It keeps dates naive and validates calendar values so a bad timestamp does not leak into stored items.

Code: `ember/normalize.py::_build_date`, `ember/normalize.py::_full_year`, `ember/normalize.py::_iso_date`, `ember/normalize.py::_rfc822_date`, `ember/normalize.py::resolve_date`

### Feed refresh pipeline

Reads every configured feed source, turns the bytes into normalized items, stores them, and reports how much work the pass did. It keeps the whole refresh flow together so the fetch, parse, dedupe, and store steps stay in one place and the summary reflects the same run that wrote the data.

Code: `ember/fetch.py::RefreshResult`, `ember/fetch.py::RefreshResult.summary`, `ember/fetch.py::__module__`, `ember/fetch.py::_refresh_one`, `ember/fetch.py::refresh`

#### Local feed source reader

Resolves a feed URL to a local file path and reads its bytes, while refusing network locations in this build. That keeps refreshes limited to workspace files and makes failures point at the exact source that could not be read.

Code: `ember/fetch.py::FetchError`, `ember/fetch.py::Fetched`, `ember/fetch.py::LOCAL_SCHEMES`, `ember/fetch.py::fetch`, `ember/fetch.py::resolve_source`

### Item upsert deduplication

Decides what to do when a fetched item meets an existing row in the store. It inserts new identities, leaves matching content alone, and overwrites changed content while stamping when the change was seen, so refreshes can safely process repeated feed entries without double-counting them. It also reports the run as a combined count of new, updated, and unchanged items.

Code: `ember/dedupe.py::INSERTED`, `ember/dedupe.py::UNCHANGED`, `ember/dedupe.py::UPDATED`, `ember/dedupe.py::UpsertResult`, `ember/dedupe.py::UpsertResult.__add__`, `ember/dedupe.py::UpsertResult.summary`, `ember/dedupe.py::UpsertResult.total`, `ember/dedupe.py::__module__`, `ember/dedupe.py::upsert_item`, `ember/dedupe.py::upsert_items`

### SQLite store access

Keeps Ember’s feeds and items in a local SQLite database and gives the rest of the app typed ways to read, write, and count that data. It also opens the database safely, creates the schema on first use, and refuses databases from a newer schema version so the store is not guessed at.

Code: `ember/store.py::Counts`, `ember/store.py::DB_NAME`, `ember/store.py::FeedRecord`, `ember/store.py::SCHEMA_VERSION`, `ember/store.py::Store`, `ember/store.py::Store.__enter__`, `ember/store.py::Store.__exit__`, `ember/store.py::Store.__init__`, `ember/store.py::Store.close`, `ember/store.py::Store.counts`, `ember/store.py::Store.dates`, `ember/store.py::Store.feeds`, `ember/store.py::Store.get_item`, `ember/store.py::Store.open`, `ember/store.py::StoreError`, `ember/store.py::__module__`, `ember/store.py::_prepare`, `ember/store.py::_to_datetime`, `ember/store.py::open_store`

#### Item query helpers

Reads stored items back in the shapes the rest of Ember needs, including whole-store listings and filters by day, feed, or first-seen time. These methods share one row-to-item path so the database columns stay mapped consistently.

Code: `ember/store.py::Store._select`, `ember/store.py::Store.all_items`, `ember/store.py::Store.items_for_date`, `ember/store.py::Store.items_for_feed`, `ember/store.py::Store.items_since`

#### Item and feed writes

Stores new items, updates changed items, and records when a feed was fetched. It preserves the first time an item was seen while refreshing the last change time, so later reads can tell new content from old content that was updated.

Code: `ember/store.py::Store.insert_item`, `ember/store.py::Store.record_feed`, `ember/store.py::Store.update_item`, `ember/store.py::_from_datetime`, `ember/store.py::_to_row`

## Writing the digest and the archive

This group covers the generated pages and files Ember writes for readers. It includes archive regeneration, daily digest assembly, notification logging, template rendering, and the output writer that updates files safely.

### Archive regeneration workflow

Builds and refreshes the site archive when the stored collection changes. It gathers all items, checks whether the archive is still current, writes the archive pages and search corpus, and records enough state to skip work when nothing relevant moved.

The archive keeps a signature of its own, over every stored item, rather than sharing the digests'. We rejected one shared signature: the archive has to move whenever the collection as a whole moves, and a digest has to move only when its own day would come out different, so one signature made each of them rebuild for the other's reasons.

Code: `ember/archive.py::ARCHIVE_TEMPLATE`, `ember/archive.py::ArchiveResult`, `ember/archive.py::ArchiveResult.summary`, `ember/archive.py::FEED_TEMPLATE`, `ember/archive.py::INDEX_REL`, `ember/archive.py::SEARCH_REL`, `ember/archive.py::STATE_NAME`, `ember/archive.py::STATE_VERSION`, `ember/archive.py::_State`, `ember/archive.py::_State.__init__`, `ember/archive.py::_State.load`, `ember/archive.py::_State.save`, `ember/archive.py::__module__`, `ember/archive.py::_all_present`, `ember/archive.py::archive_signature`, `ember/archive.py::build_feed_pages`, `ember/archive.py::build_index`, `ember/archive.py::build_search`, `ember/archive.py::days_of`, `ember/archive.py::feed_rel`, `ember/archive.py::feeds_of`, `ember/archive.py::refresh_archive`

### Daily digest assembly and writing

Builds one page per day from the items already stored, renders that page, and writes it only when the selected content has changed. It also keeps the newest page mirrored to latest.html and records signatures so repeated runs can skip unchanged output.

A day's page is rewritten only when its digest signature changes — a sha256 over the id, feed, title, published time and summary of each item the selection holds, computed from the assembled selection. We rejected tracking per-day dependencies instead: we tried it, and it was always subtly wrong once an item's date moved and the day it belonged to changed underneath us. The invariant that keeps this safe: anything that affects which items a digest shows must be visible where the selection is assembled. A filter applied later, inside the renderer, is invisible to the signature — the run reports nothing to write and the day's page keeps serving what it served before.

Code: `ember/digest.py::DIGEST_TEMPLATE`, `ember/digest.py::DigestResult`, `ember/digest.py::DigestResult.summary`, `ember/digest.py::DigestSelection`, `ember/digest.py::DigestSelection.feeds`, `ember/digest.py::DigestSelection.total`, `ember/digest.py::DigestState`, `ember/digest.py::DigestState.__init__`, `ember/digest.py::DigestState.load`, `ember/digest.py::DigestState.record`, `ember/digest.py::DigestState.save`, `ember/digest.py::DigestState.signature_for`, `ember/digest.py::FeedGroup`, `ember/digest.py::FeedGroup.count`, `ember/digest.py::LATEST_REL`, `ember/digest.py::STATE_NAME`, `ember/digest.py::STATE_VERSION`, `ember/digest.py::__module__`, `ember/digest.py::_mirror_latest`, `ember/digest.py::assemble_digest`, `ember/digest.py::day_label`, `ember/digest.py::digest_rel`, `ember/digest.py::digest_signature`, `ember/digest.py::group_by_feed`, `ember/digest.py::render_digest`, `ember/digest.py::run_digest`

### Notification logging workflow

Records newly arrived items in a log and remembers how far it has already announced them. It keeps a small state file so the same item is not logged twice, even when several items share the same timestamp, and it formats both the saved state and the human-readable log line.

Code: `ember/notify.py::LOG_REL`, `ember/notify.py::Notification`, `ember/notify.py::Notification.line`, `ember/notify.py::NotifyResult`, `ember/notify.py::NotifyResult.count`, `ember/notify.py::NotifyResult.summary`, `ember/notify.py::NotifyState`, `ember/notify.py::NotifyState.__init__`, `ember/notify.py::NotifyState.advance`, `ember/notify.py::NotifyState.is_new`, `ember/notify.py::NotifyState.load`, `ember/notify.py::NotifyState.save`, `ember/notify.py::STATE_NAME`, `ember/notify.py::STATE_VERSION`, `ember/notify.py::__module__`, `ember/notify.py::_to_datetime`, `ember/notify.py::pending`, `ember/notify.py::record`

### Generated output writing

Writes generated pages into the output tree and keeps them safe to update. It resolves paths inside the output root, writes through a temporary neighbour file, appends lines when needed, and removes stale files and empty directories so readers never see half-written or leftover pages.

Code: `ember/render.py::Doc`, `ember/render.py::TEMP_SUFFIX`, `ember/render.py::__module__`, `ember/render.py::append_lines`, `ember/render.py::exists`, `ember/render.py::prune`, `ember/render.py::remove`, `ember/render.py::replace_outputs`, `ember/render.py::resolve`, `ember/render.py::write_doc`, `ember/render.py::write_docs`, `ember/render.py::write_text`

### Template rendering engine

Turns template files into escaped HTML by loading source text, parsing tags, and emitting the final string with a shared context. It keeps parsed templates cached and reports syntax or lookup problems with template name and line so failures point back to the exact spot that broke.

The engine is deliberately hand-written rather than a dependency: ember's whole pitch is that you can drop it on a box with nothing but Python and it runs, and the one time we tried a library it pulled in a compiled extension for features we never used. The cost we accepted: no filters, no template inheritance until someone needs them.

Code: `ember/templates.py::Environment`, `ember/templates.py::Environment.__init__`, `ember/templates.py::Environment.nodes`, `ember/templates.py::Environment.render`, `ember/templates.py::Environment.source`, `ember/templates.py::MISSING`, `ember/templates.py::TemplateError`, `ember/templates.py::TemplateError.__init__`, `ember/templates.py::_Branch`, `ember/templates.py::_Branch.emit`, `ember/templates.py::_Include`, `ember/templates.py::_Include.emit`, `ember/templates.py::_Loop`, `ember/templates.py::_Loop.emit`, `ember/templates.py::_Output`, `ember/templates.py::_Output.emit`, `ember/templates.py::_Text`, `ember/templates.py::_Text.emit`, `ember/templates.py::_Token`, `ember/templates.py::__module__`, `ember/templates.py::_argument`, `ember/templates.py::_as_text`, `ember/templates.py::_date`, `ember/templates.py::_emit_all`, `ember/templates.py::_evaluate`, `ember/templates.py::_expect`, `ember/templates.py::_filter`, `ember/templates.py::_length`, `ember/templates.py::_literal`, `ember/templates.py::_parse`, `ember/templates.py::_parse_tag`, `ember/templates.py::_parse_until`, `ember/templates.py::_resolve`, `ember/templates.py::_split`, `ember/templates.py::_tokenize`, `ember/templates.py::_truthy`, `ember/templates.py::_upper`, `ember/templates.py::render`

## Testing the pipeline

This group covers the supporting fixtures and the tests that verify Ember’s main workflows. It includes sample workspace helpers, feed and store builders, and the behavior tests for configuration, CLI handling, feed parsing, refresh, deduplication, digest generation, archive generation, templates, and storage.

Code: `tests/conftest.py::NOW`, `tests/conftest.py::SAMPLE_DAYS`, `tests/conftest.py::SAMPLE_FEEDS`, `tests/conftest.py::SAMPLE_ITEMS`, `tests/conftest.py::SAMPLE_ROOT`, `tests/conftest.py::__module__`, `tests/conftest.py::add_atom_entry`, `tests/conftest.py::add_rss_item`, `tests/conftest.py::bare`, `tests/conftest.py::config`, `tests/conftest.py::edit`, `tests/conftest.py::output_exists`, `tests/conftest.py::read_output`, `tests/conftest.py::rss_document`, `tests/conftest.py::rss_item`, `tests/conftest.py::workspace`, `tests/conftest.py::write_feed`, `tests/test_archive.py::FEED_NAMES`, `tests/test_archive.py::__module__`, `tests/test_archive.py::corpus`, `tests/test_archive.py::test_a_new_item_puts_the_archive_out_of_date`, `tests/test_archive.py::test_a_page_per_feed_holds_everything_that_feed_brought_in`, `tests/test_archive.py::test_a_second_pass_writes_nothing`, `tests/test_archive.py::test_outputs_that_are_no_longer_generated_are_taken_away`, `tests/test_archive.py::test_the_archive_and_the_digest_are_gated_apart`, `tests/test_archive.py::test_the_archive_comes_back_when_its_files_are_taken_away`, `tests/test_archive.py::test_the_corpus_holds_every_item`, `tests/test_archive.py::test_the_index_lists_the_days_and_the_feeds`, `tests/test_archive.py::test_the_signature_follows_the_whole_collection`, `tests/test_cli.py::__module__`, `tests/test_cli.py::run`, `tests/test_cli.py::test_a_command_is_required`, `tests/test_cli.py::test_a_date_that_is_not_a_date_is_rejected`, `tests/test_cli.py::test_a_feed_that_is_not_there_is_a_clean_failure`, `tests/test_cli.py::test_a_second_digest_says_it_had_nothing_to_do`, `tests/test_cli.py::test_a_single_day_can_be_asked_for`, `tests/test_cli.py::test_a_workspace_without_a_config_is_a_clean_failure`, `tests/test_cli.py::test_archive_can_be_written_on_its_own`, `tests/test_cli.py::test_refresh_then_digest_writes_a_readable_workspace`, `tests/test_cli.py::test_status_reports_the_feeds_before_anything_is_read`, `tests/test_cli.py::test_status_reports_what_was_read`, `tests/test_cli.py::test_the_version_is_reported`, `tests/test_config.py::__module__`, `tests/test_config.py::test_a_digest_of_no_items_makes_no_sense`, `tests/test_config.py::test_a_missing_file_is_an_error`, `tests/test_config.py::test_a_wrong_type_is_refused`, `tests/test_config.py::test_an_empty_title_is_refused`, `tests/test_config.py::test_an_unknown_key_names_the_ones_that_are_known`, `tests/test_config.py::test_bad_toml_is_reported_as_such`, `tests/test_config.py::test_defaults_are_the_documented_ones`, `tests/test_config.py::test_directories_stay_inside_the_workspace`, `tests/test_config.py::test_keys_may_sit_at_the_top_level`, `tests/test_config.py::test_the_sample_workspace_loads`, `tests/test_config.py::test_true_is_not_an_integer`, `tests/test_config.py::write_config`, `tests/test_dedupe.py::FIRST`, `tests/test_dedupe.py::LATER`, `tests/test_dedupe.py::__module__`, `tests/test_dedupe.py::store`, `tests/test_dedupe.py::test_a_run_of_items_is_tallied`, `tests/test_dedupe.py::test_an_unknown_identity_is_inserted`, `tests/test_dedupe.py::test_changed_content_updates_the_row_and_stamps_it`, `tests/test_dedupe.py::test_nothing_to_upsert_is_not_an_error`, `tests/test_dedupe.py::test_results_add_up`, `tests/test_dedupe.py::test_the_same_item_again_does_nothing`, `tests/test_digest.py::DAY`, `tests/test_digest.py::MOMENT`, `tests/test_digest.py::__module__`, `tests/test_digest.py::selection_of`, `tests/test_digest.py::stock`, `tests/test_digest.py::store`, `tests/test_digest.py::test_a_day_takes_its_own_items`, `tests/test_digest.py::test_a_day_with_nothing_on_it_is_an_empty_selection`, `tests/test_digest.py::test_a_feed_option_does_not_move_the_signature`, `tests/test_digest.py::test_a_group_keeps_the_order_the_items_arrived_in`, `tests/test_digest.py::test_a_link_or_author_edit_leaves_the_signature_alone`, `tests/test_digest.py::test_items_are_grouped_by_feed`, `tests/test_digest.py::test_the_selection_is_capped_at_the_configured_maximum`, `tests/test_digest.py::test_the_signature_is_the_same_for_the_same_items`, `tests/test_digest.py::test_the_signature_moves_when_a_summary_changes`, `tests/test_digest.py::test_the_signature_moves_when_a_title_changes`, `tests/test_digest.py::test_the_signature_moves_when_an_item_joins_or_leaves`, `tests/test_digest.py::test_the_signature_moves_when_the_order_changes`, `tests/test_digest.py::test_where_a_day_and_its_heading_go`, `tests/test_digest_incremental.py::NEW_DAY`, `tests/test_digest_incremental.py::__module__`, `tests/test_digest_incremental.py::days_written`, `tests/test_digest_incremental.py::digest_pass`, `tests/test_digest_incremental.py::test_a_damaged_state_file_costs_one_pass`, `tests/test_digest_incremental.py::test_a_day_can_be_written_on_its_own`, `tests/test_digest_incremental.py::test_a_feed_option_does_not_rebuild_the_digest`, `tests/test_digest_incremental.py::test_a_new_item_rebuilds_its_day_the_latest_and_one_notification`, `tests/test_digest_incremental.py::test_a_page_that_has_gone_missing_comes_back`, `tests/test_digest_incremental.py::test_a_refresh_that_brings_in_nothing_leaves_the_pass_idle`, `tests/test_digest_incremental.py::test_a_second_pass_writes_nothing`, `tests/test_digest_incremental.py::test_an_edited_entry_rebuilds_only_the_day_it_is_on`, `tests/test_digest_incremental.py::test_an_item_on_the_newest_day_moves_the_latest_page`, `tests/test_digest_incremental.py::test_the_first_pass_writes_every_day_and_the_latest`, `tests/test_digest_incremental.py::test_the_same_item_is_not_announced_twice`, `tests/test_feeds.py::ONE`, `tests/test_feeds.py::__module__`, `tests/test_feeds.py::test_a_file_with_no_feeds_says_so`, `tests/test_feeds.py::test_a_missing_file_is_an_error`, `tests/test_feeds.py::test_a_name_has_to_look_like_a_slug`, `tests/test_feeds.py::test_a_wrong_type_is_refused`, `tests/test_feeds.py::test_an_unknown_key_is_refused`, `tests/test_feeds.py::test_bad_toml_is_reported_as_such`, `tests/test_feeds.py::test_feed_must_be_a_list_of_tables`, `tests/test_feeds.py::test_max_items_has_a_default`, `tests/test_feeds.py::test_max_items_must_take_at_least_one`, `tests/test_feeds.py::test_name_and_url_are_both_required`, `tests/test_feeds.py::test_the_position_of_a_bad_feed_is_reported`, `tests/test_feeds.py::test_the_sample_feeds_load_in_order`, `tests/test_feeds.py::test_two_feeds_cannot_share_a_name`, `tests/test_feeds.py::write_feeds`, `tests/test_fetch.py::__module__`, `tests/test_fetch.py::spec`, `tests/test_fetch.py::test_a_file_url_is_understood`, `tests/test_fetch.py::test_a_file_url_on_another_host_is_refused`, `tests/test_fetch.py::test_a_file_url_with_an_escaped_space`, `tests/test_fetch.py::test_a_relative_path_is_taken_from_the_workspace`, `tests/test_fetch.py::test_a_source_that_is_not_there_says_where_it_looked`, `tests/test_fetch.py::test_an_absolute_path_is_used_as_it_is`, `tests/test_fetch.py::test_another_scheme_is_refused_by_name`, `tests/test_fetch.py::test_fetch_returns_the_bytes_and_when_it_read_them`, `tests/test_fetch.py::test_max_items_limits_what_one_run_takes`, `tests/test_fetch.py::test_refresh_reads_every_feed`, `tests/test_fetch.py::test_refresh_records_when_each_feed_was_read`, `tests/test_fetch.py::test_refresh_stores_nothing_twice`, `tests/test_fetch.py::test_the_network_is_stubbed_in_this_build`, `tests/test_normalize.py::FETCHED`, `tests/test_normalize.py::__module__`, `tests/test_normalize.py::entry`, `tests/test_normalize.py::test_a_long_summary_is_cut_on_a_word_boundary`, `tests/test_normalize.py::test_a_normalized_item_has_no_store_times_yet`, `tests/test_normalize.py::test_a_short_summary_is_left_alone`, `tests/test_normalize.py::test_a_single_long_word_is_cut_anyway`, `tests/test_normalize.py::test_an_author_comes_out_as_a_name`, `tests/test_normalize.py::test_an_entry_with_no_date_is_dated_by_the_fetch`, `tests/test_normalize.py::test_an_entry_with_nothing_to_key_on_is_left_out`, `tests/test_normalize.py::test_an_untitled_entry_gets_a_placeholder`, `tests/test_normalize.py::test_an_unusable_date_falls_back_to_the_day_it_was_read`, `tests/test_normalize.py::test_both_date_formats_are_understood`, `tests/test_normalize.py::test_identity_falls_back_from_guid_to_link_to_title`, `tests/test_normalize.py::test_identity_is_per_feed`, `tests/test_normalize.py::test_identity_is_stable_across_runs`, `tests/test_normalize.py::test_markup_and_entities_come_out_of_the_summary`, `tests/test_normalize.py::test_the_content_hash_moves_with_the_content`, `tests/test_normalize.py::test_the_first_of_a_repeated_guid_wins`, `tests/test_normalize.py::test_the_zone_offset_does_not_move_the_day`, `tests/test_normalize.py::test_whitespace_only_text_collapses_to_nothing`, `tests/test_parse.py::ATOM`, `tests/test_parse.py::__module__`, `tests/test_parse.py::test_an_empty_feed_parses_to_no_entries`, `tests/test_parse.py::test_atom_falls_back_to_content_updated_and_any_link`, `tests/test_parse.py::test_atom_reads_the_fields_of_an_entry`, `tests/test_parse.py::test_atom_tolerates_an_entry_with_only_an_id`, `tests/test_parse.py::test_every_sample_feed_parses`, `tests/test_parse.py::test_rss_falls_back_to_encoded_content_and_dc_creator`, `tests/test_parse.py::test_rss_leaves_a_non_permalink_guid_alone`, `tests/test_parse.py::test_rss_reads_the_fields_of_an_item`, `tests/test_parse.py::test_rss_takes_a_permalink_guid_as_the_link`, `tests/test_parse.py::test_rss_tolerates_an_item_with_almost_nothing`, `tests/test_parse.py::test_rss_without_a_channel_is_reported`, `tests/test_parse.py::test_text_that_is_not_xml_is_reported`, `tests/test_parse.py::test_xml_that_is_not_a_feed_is_reported`, `tests/test_store.py::MOMENT`, `tests/test_store.py::__module__`, `tests/test_store.py::make_item`, `tests/test_store.py::store`, `tests/test_store.py::test_a_database_from_a_later_schema_is_refused`, `tests/test_store.py::test_a_day_holds_its_own_items_in_a_fixed_order`, `tests/test_store.py::test_a_feed_is_recorded_and_then_updated`, `tests/test_store.py::test_an_empty_store_counts_nothing`, `tests/test_store.py::test_an_item_survives_a_round_trip`, `tests/test_store.py::test_an_unknown_id_reads_as_nothing`, `tests/test_store.py::test_an_update_keeps_the_day_it_was_first_seen`, `tests/test_store.py::test_counts_report_the_whole_store`, `tests/test_store.py::test_items_can_be_read_by_feed`, `tests/test_store.py::test_items_come_back_newest_first`, `tests/test_store.py::test_items_since_a_moment_are_the_new_ones`, `tests/test_store.py::test_opening_creates_the_database_and_stamps_the_schema`, `tests/test_store.py::test_the_days_with_items_come_back_newest_first`, `tests/test_templates.py::Thing`, `tests/test_templates.py::__module__`, `tests/test_templates.py::env_with`, `tests/test_templates.py::test_a_conditional_on_a_name_that_is_not_there_is_false`, `tests/test_templates.py::test_a_conditional_takes_one_side`, `tests/test_templates.py::test_a_loop_over_a_string_is_a_mistake`, `tests/test_templates.py::test_a_loop_over_nothing_writes_nothing`, `tests/test_templates.py::test_a_loop_repeats_its_body`, `tests/test_templates.py::test_a_loop_that_is_never_closed_is_an_error`, `tests/test_templates.py::test_a_name_that_is_not_there_is_an_error`, `tests/test_templates.py::test_a_stray_end_tag_is_an_error`, `tests/test_templates.py::test_a_tag_on_its_own_line_does_not_leave_a_blank_one`, `tests/test_templates.py::test_a_value_is_substituted`, `tests/test_templates.py::test_an_error_carries_the_template_and_the_line`, `tests/test_templates.py::test_an_include_brings_in_another_template`, `tests/test_templates.py::test_an_include_that_is_not_there_says_so`, `tests/test_templates.py::test_an_unknown_filter_is_an_error`, `tests/test_templates.py::test_an_unknown_tag_is_an_error`, `tests/test_templates.py::test_filters_chain`, `tests/test_templates.py::test_globals_reach_every_template_and_can_be_overridden`, `tests/test_templates.py::test_lookups_walk_dicts_and_objects`, `tests/test_templates.py::test_not_reverses_a_test`, `tests/test_templates.py::test_the_bundled_templates_all_parse`, `tests/test_templates.py::test_the_date_filter_refuses_something_that_is_not_a_date`, `tests/test_templates.py::test_the_date_filter_takes_a_format`, `tests/test_templates.py::test_the_length_and_upper_filters`, `tests/test_templates.py::test_values_are_escaped_on_the_way_out`
