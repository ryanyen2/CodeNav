import pytest

from ember.parse import ParseError, parse_feed

from tests.conftest import rss_document, rss_item

ATOM = """<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>An Atom Feed</title>
  <id>tag:feed.test,2026:feed</id>
  <entry>
    <title>Full entry</title>
    <link rel="edit" href="https://feed.test/edit/1"/>
    <link rel="alternate" type="text/html" href="https://feed.test/one"/>
    <id>tag:feed.test,2026:one</id>
    <published>2026-08-11T05:40:00Z</published>
    <updated>2026-08-12T06:00:00Z</updated>
    <author><name>Bea Ferrand</name></author>
    <summary type="html">&lt;p&gt;A short one.&lt;/p&gt;</summary>
  </entry>
  <entry>
    <title>Content instead of summary</title>
    <link href="https://feed.test/two"/>
    <id>tag:feed.test,2026:two</id>
    <updated>2026-08-09T16:20:00Z</updated>
    <content type="xhtml"><div xmlns="http://www.w3.org/1999/xhtml"><p>Inline markup.</p></div></content>
  </entry>
  <entry>
    <id>tag:feed.test,2026:three</id>
  </entry>
</feed>
"""


def test_rss_reads_the_fields_of_an_item():
    parsed = parse_feed(rss_document([rss_item("A title", "guid-1", "Mon, 10 Aug 2026")]))
    assert parsed.format == "rss"
    assert parsed.title == "Test Feed"
    entry = parsed.entries[0]
    assert entry.title == "A title"
    assert entry.link == "https://feed.test/guid-1"
    assert entry.guid == "guid-1"
    assert entry.published == "Mon, 10 Aug 2026 09:00:00 +0000"
    assert entry.summary == "Something happened."


def test_rss_takes_a_permalink_guid_as_the_link():
    document = rss_document(
        [
            "    <item>\n"
            "      <title>No link of its own</title>\n"
            '      <guid isPermaLink="true">https://feed.test/permalink</guid>\n'
            "    </item>\n"
        ]
    )
    entry = parse_feed(document).entries[0]
    assert entry.link == "https://feed.test/permalink"


def test_rss_leaves_a_non_permalink_guid_alone():
    document = rss_document(
        [
            "    <item>\n"
            "      <title>Opaque guid</title>\n"
            '      <guid isPermaLink="false">https://feed.test/not-a-page</guid>\n'
            "    </item>\n"
        ]
    )
    entry = parse_feed(document).entries[0]
    assert entry.guid == "https://feed.test/not-a-page"
    assert entry.link == ""


def test_rss_falls_back_to_encoded_content_and_dc_creator(workspace):
    raw = (workspace / "fixtures" / "feeds" / "plane-and-chisel.xml").read_bytes()
    entries = parse_feed(raw, "plane-and-chisel").entries
    shooting = next(entry for entry in entries if "shooting board" in entry.title)
    assert "quartersawn stock" in shooting.summary
    assert shooting.author == "torsten@planeandchisel.example (Torsten Vey)"


def test_rss_tolerates_an_item_with_almost_nothing():
    entry = parse_feed(rss_document(["    <item>\n      <title>Bare</title>\n    </item>\n"])).entries[0]
    assert entry.title == "Bare"
    assert (entry.link, entry.guid, entry.published, entry.summary, entry.author) == ("",) * 5


def test_atom_reads_the_fields_of_an_entry():
    parsed = parse_feed(ATOM)
    assert parsed.format == "atom"
    assert parsed.title == "An Atom Feed"
    entry = parsed.entries[0]
    assert entry.title == "Full entry"
    assert entry.link == "https://feed.test/one"
    assert entry.guid == "tag:feed.test,2026:one"
    assert entry.published == "2026-08-11T05:40:00Z"
    assert entry.author == "Bea Ferrand"
    assert entry.summary == "<p>A short one.</p>"


def test_atom_falls_back_to_content_updated_and_any_link():
    entry = parse_feed(ATOM).entries[1]
    assert entry.link == "https://feed.test/two"
    assert entry.published == "2026-08-09T16:20:00Z"
    assert entry.summary == "Inline markup."
    assert entry.author == ""


def test_atom_tolerates_an_entry_with_only_an_id():
    entry = parse_feed(ATOM).entries[2]
    assert entry.guid == "tag:feed.test,2026:three"
    assert entry.title == ""


def test_an_empty_feed_parses_to_no_entries():
    assert parse_feed(rss_document([])).entries == []


def test_text_that_is_not_xml_is_reported():
    with pytest.raises(ParseError, match="not well-formed XML"):
        parse_feed(b"<html><body>404</body>", "north-light")


def test_xml_that_is_not_a_feed_is_reported():
    with pytest.raises(ParseError, match="neither RSS nor Atom"):
        parse_feed(b"<opml><body/></opml>", "north-light")


def test_rss_without_a_channel_is_reported():
    with pytest.raises(ParseError, match="no <channel>"):
        parse_feed(b'<rss version="2.0"><item/></rss>', "north-light")


def test_every_sample_feed_parses(workspace):
    feeds = sorted((workspace / "fixtures" / "feeds").glob("*.xml"))
    parsed = [parse_feed(path.read_bytes(), path.stem) for path in feeds]
    assert sum(len(feed.entries) for feed in parsed) == 36
    assert {feed.format for feed in parsed} == {"rss", "atom"}
