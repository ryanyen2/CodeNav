import json

from ember.archive import archive_signature, feed_rel, refresh_archive
from ember.digest import run_digest
from ember.fetch import refresh
from ember.render import Doc, replace_outputs
from ember.store import open_store

from tests.conftest import (
    SAMPLE_DAYS,
    SAMPLE_FEEDS,
    SAMPLE_ITEMS,
    add_atom_entry,
    read_output,
)

FEED_NAMES = [
    "north-light",
    "plane-and-chisel",
    "ridgeline-notes",
    "saltbox-kitchen",
    "slow-extraction",
]


def corpus(root) -> list[dict]:
    return json.loads(read_output(root, "archive/search.json"))


def test_the_corpus_holds_every_item(workspace):
    refresh(workspace)
    refresh_archive(workspace)

    entries = corpus(workspace)
    assert len(entries) == SAMPLE_ITEMS
    assert set(entries[0]) == {"title", "feed", "date", "url"}
    assert {entry["feed"] for entry in entries} == set(FEED_NAMES)
    assert all(entry["url"].startswith("https://") for entry in entries)
    assert entries[0]["date"] >= entries[-1]["date"]


def test_a_page_per_feed_holds_everything_that_feed_brought_in(workspace):
    refresh(workspace)
    refresh_archive(workspace)

    with open_store((workspace / ".ember")) as store:
        for name in FEED_NAMES:
            page = read_output(workspace, feed_rel(name))
            items = store.items_for_feed(name)
            assert len(items) > 0
            for item in items:
                assert item.title in page


def test_the_index_lists_the_days_and_the_feeds(workspace):
    refresh(workspace)
    result = refresh_archive(workspace)
    page = read_output(workspace, "archive/index.html")

    assert (result.days, result.feeds, result.items) == (SAMPLE_DAYS, SAMPLE_FEEDS, SAMPLE_ITEMS)
    assert page.count('<a href="../2026-') == SAMPLE_DAYS
    for name in FEED_NAMES:
        assert f'<a href="{name}/index.html">' in page


def test_a_second_pass_writes_nothing(workspace):
    refresh(workspace)
    refresh_archive(workspace)
    again = refresh_archive(workspace)
    assert again.regenerated is False
    assert again.written == []
    assert again.summary() == "archive up to date"


def test_a_new_item_puts_the_archive_out_of_date(workspace):
    refresh(workspace)
    refresh_archive(workspace)
    add_atom_entry(
        workspace,
        "ridgeline-notes",
        title="An extra walk",
        guid="tag:ridgeline.example,2026:extra",
        published="2026-08-08T10:00:00Z",
    )
    refresh(workspace)

    result = refresh_archive(workspace)
    assert result.regenerated is True
    assert result.items == SAMPLE_ITEMS + 1
    assert "An extra walk" in read_output(workspace, feed_rel("ridgeline-notes"))
    assert any(entry["title"] == "An extra walk" for entry in corpus(workspace))


def test_the_archive_comes_back_when_its_files_are_taken_away(workspace):
    refresh(workspace)
    refresh_archive(workspace)
    (workspace / "_digest" / "archive" / "search.json").unlink()
    assert refresh_archive(workspace).regenerated is True


def test_the_signature_follows_the_whole_collection(workspace):
    refresh(workspace)
    with open_store(workspace / ".ember") as store:
        items = store.all_items()
    assert archive_signature(items) == archive_signature(items)
    assert archive_signature(items) != archive_signature(items[1:])


def test_the_archive_and_the_digest_are_gated_apart(workspace):
    """A day's page can be rewritten without the archive being rewritten."""
    refresh(workspace)
    run_digest(workspace)
    refresh_archive(workspace)
    (workspace / "_digest" / "2026-08-05.html").unlink()

    assert len(run_digest(workspace).regenerated) == 1
    assert refresh_archive(workspace).regenerated is False


def test_outputs_that_are_no_longer_generated_are_taken_away(tmp_path):
    output = tmp_path / "_digest"
    replace_outputs(output, [], [Doc("archive/gone/index.html", "old"), Doc("kept.html", "old")])
    assert (output / "archive" / "gone" / "index.html").is_file()

    written = replace_outputs(
        output, ["archive/gone/index.html", "kept.html"], [Doc("kept.html", "new")]
    )
    assert written == ["kept.html"]
    assert (output / "kept.html").read_text(encoding="utf-8") == "new"
    assert not (output / "archive" / "gone").exists()
    assert not (output / "archive").exists()
