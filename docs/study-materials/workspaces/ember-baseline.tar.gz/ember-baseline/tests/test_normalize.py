from datetime import date, datetime

import pytest

from ember.normalize import (
    SUMMARY_LIMIT,
    clean_text,
    item_identity,
    normalize_entries,
    normalize_entry,
    person,
    resolve_date,
    truncate,
)
from ember.parse import RawEntry

FETCHED = datetime(2026, 8, 12, 9, 0, 0)


def entry(**fields) -> RawEntry:
    return RawEntry(**{"title": "A title", "guid": "guid-1", **fields})


def test_identity_is_stable_across_runs():
    first = normalize_entry(entry(), "one", FETCHED)
    later = normalize_entry(entry(), "one", datetime(2027, 1, 1, 0, 0, 0))
    assert first.id == later.id


def test_identity_is_per_feed():
    here = normalize_entry(entry(), "one", FETCHED)
    there = normalize_entry(entry(), "two", FETCHED)
    assert here.id != there.id


def test_identity_falls_back_from_guid_to_link_to_title():
    with_link = normalize_entry(entry(guid="", link="https://feed.test/a"), "one", FETCHED)
    with_title = normalize_entry(entry(guid="", link=""), "one", FETCHED)
    assert with_link.id == item_identity("one", "https://feed.test/a")
    assert with_title.id == item_identity("one", "A title")


def test_an_entry_with_nothing_to_key_on_is_left_out():
    assert normalize_entry(entry(title="", guid="", link=""), "one", FETCHED) is None
    assert normalize_entries([entry(title="", guid="", link="")], "one", FETCHED) == []


def test_the_first_of_a_repeated_guid_wins():
    items = normalize_entries(
        [entry(title="First"), entry(title="Second")], "one", FETCHED
    )
    assert [item.title for item in items] == ["First"]


def test_markup_and_entities_come_out_of_the_summary():
    item = normalize_entry(
        entry(summary="<p>Beans &amp; garlic,\n  very  hot</p>"), "one", FETCHED
    )
    assert item.summary == "Beans & garlic, very hot"


def test_an_untitled_entry_gets_a_placeholder():
    assert normalize_entry(entry(title=""), "one", FETCHED).title == "(untitled)"


def test_a_long_summary_is_cut_on_a_word_boundary():
    text = " ".join(["chopped parsley"] * 40)
    cut = truncate(text)
    assert len(cut) <= SUMMARY_LIMIT
    assert cut.endswith("…")
    assert " ".join(cut[:-1].split()) == cut[:-1].strip()
    assert text.startswith(cut[:-1])


def test_a_short_summary_is_left_alone():
    assert truncate("Short enough.") == "Short enough."


def test_a_single_long_word_is_cut_anyway():
    assert truncate("x" * 400) == "x" * (SUMMARY_LIMIT - 1) + "…"


def test_whitespace_only_text_collapses_to_nothing():
    assert clean_text("  \n\t ") == ""


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("Mon, 10 Aug 2026 09:00:00 +0000", date(2026, 8, 10)),
        ("10 Aug 2026 09:00:00 GMT", date(2026, 8, 10)),
        ("Mon, 10 August 26 09:00:00 +0000", date(2026, 8, 10)),
        ("2026-08-10T05:40:00Z", date(2026, 8, 10)),
        ("2026-08-10 05:40:00", date(2026, 8, 10)),
        ("2026-08-10", date(2026, 8, 10)),
    ],
)
def test_both_date_formats_are_understood(raw, expected):
    assert resolve_date(raw, date(2000, 1, 1)) == expected


@pytest.mark.parametrize("raw", ["", "yesterday", "2026-13-45", "Mon, 32 Foo 2026"])
def test_an_unusable_date_falls_back_to_the_day_it_was_read(raw):
    assert resolve_date(raw, date(2026, 8, 12)) == date(2026, 8, 12)


def test_an_entry_with_no_date_is_dated_by_the_fetch():
    assert normalize_entry(entry(published=""), "one", FETCHED).published == FETCHED.date()


def test_the_zone_offset_does_not_move_the_day():
    assert resolve_date("2026-08-10T23:30:00-04:00", date(2000, 1, 1)) == date(2026, 8, 10)


def test_the_content_hash_moves_with_the_content():
    first = normalize_entry(entry(), "one", FETCHED)
    retitled = normalize_entry(entry(title="Another title"), "one", FETCHED)
    resummarized = normalize_entry(entry(summary="New words"), "one", FETCHED)
    assert first.content_hash != retitled.content_hash
    assert first.content_hash != resummarized.content_hash
    assert first.content_hash == normalize_entry(entry(), "one", FETCHED).content_hash


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("torsten@shop.example (Torsten Vey)", "Torsten Vey"),
        ("nell@kitchen.example", "nell"),
        ("Bea Ferrand", "Bea Ferrand"),
        ("", ""),
    ],
)
def test_an_author_comes_out_as_a_name(raw, expected):
    assert person(raw) == expected


def test_a_normalized_item_has_no_store_times_yet():
    item = normalize_entry(entry(), "one", FETCHED)
    assert item.first_seen is None and item.revised_at is None
