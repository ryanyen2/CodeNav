from datetime import date, datetime

import pytest

from ember.dedupe import INSERTED, UNCHANGED, UPDATED, UpsertResult, upsert_item, upsert_items
from ember.store import open_store

from tests.test_store import make_item

FIRST = datetime(2026, 8, 12, 9, 0, 0)
LATER = datetime(2026, 8, 13, 9, 0, 0)


@pytest.fixture
def store(tmp_path):
    with open_store(tmp_path / ".ember") as opened:
        yield opened


def test_an_unknown_identity_is_inserted(store):
    item = make_item("A title", date(2026, 8, 10))
    assert upsert_item(store, item, FIRST) == INSERTED
    assert store.get_item(item.id).first_seen == FIRST


def test_the_same_item_again_does_nothing(store):
    item = make_item("A title", date(2026, 8, 10))
    upsert_item(store, item, FIRST)
    assert upsert_item(store, item, LATER) == UNCHANGED
    stored = store.get_item(item.id)
    assert stored.first_seen == FIRST
    assert stored.revised_at is None


def test_changed_content_updates_the_row_and_stamps_it(store):
    item = make_item("A title", date(2026, 8, 10))
    upsert_item(store, item, FIRST)
    edited = make_item("A rewritten title", date(2026, 8, 10), key="A title")
    assert upsert_item(store, edited, LATER) == UPDATED
    stored = store.get_item(item.id)
    assert stored.title == "A rewritten title"
    assert stored.first_seen == FIRST
    assert stored.revised_at == LATER


def test_a_run_of_items_is_tallied(store):
    first = make_item("First", date(2026, 8, 10))
    second = make_item("Second", date(2026, 8, 10))
    assert upsert_items(store, [first, second], FIRST) == UpsertResult(inserted=2)

    again = [first, make_item("Second, revised", date(2026, 8, 10), key="Second")]
    assert upsert_items(store, again, LATER) == UpsertResult(updated=1, unchanged=1)


def test_results_add_up():
    total = UpsertResult(inserted=2, unchanged=1) + UpsertResult(updated=3)
    assert total == UpsertResult(inserted=2, updated=3, unchanged=1)
    assert total.total == 6
    assert total.summary() == "2 new, 3 updated, 1 unchanged"


def test_nothing_to_upsert_is_not_an_error(store):
    assert upsert_items(store, [], FIRST) == UpsertResult()
