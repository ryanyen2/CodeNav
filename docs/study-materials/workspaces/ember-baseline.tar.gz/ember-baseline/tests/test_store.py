import sqlite3
from datetime import date, datetime

import pytest

from ember.normalize import Item, content_hash, item_identity
from ember.store import DB_NAME, SCHEMA_VERSION, Store, StoreError, open_store

MOMENT = datetime(2026, 8, 12, 9, 0, 0)


def make_item(title: str, day: date, feed: str = "one", key: str = "") -> Item:
    key = key or title
    return Item(
        id=item_identity(feed, key),
        feed=feed,
        title=title,
        link=f"https://feed.test/{key}",
        published=day,
        summary=f"About {title}.",
        author="A Writer",
        content_hash=content_hash(title, f"https://feed.test/{key}", day, "", ""),
    )


@pytest.fixture
def store(tmp_path):
    with open_store(tmp_path / ".ember") as opened:
        yield opened


def test_opening_creates_the_database_and_stamps_the_schema(tmp_path):
    with open_store(tmp_path / ".ember"):
        pass
    path = tmp_path / ".ember" / DB_NAME
    assert path.is_file()
    connection = sqlite3.connect(path)
    assert connection.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert connection.execute("PRAGMA journal_mode").fetchone()[0] == "wal"
    connection.close()


def test_a_database_from_a_later_schema_is_refused(tmp_path):
    with open_store(tmp_path / ".ember"):
        pass
    connection = sqlite3.connect(tmp_path / ".ember" / DB_NAME)
    connection.execute("PRAGMA user_version=99")
    connection.close()
    with pytest.raises(StoreError, match="schema version 99"):
        Store.open(tmp_path / ".ember")


def test_a_feed_is_recorded_and_then_updated(store):
    store.record_feed("one", "fixtures/one.xml", MOMENT)
    store.record_feed("one", "fixtures/moved.xml", datetime(2026, 8, 13, 9, 0, 0))
    feeds = store.feeds()
    assert len(feeds) == 1
    assert feeds[0].url == "fixtures/moved.xml"
    assert feeds[0].last_fetched == datetime(2026, 8, 13, 9, 0, 0)


def test_an_item_survives_a_round_trip(store):
    item = make_item("A title", date(2026, 8, 10))
    store.insert_item(item, first_seen=MOMENT)
    read = store.get_item(item.id)
    assert read.title == "A title"
    assert read.published == date(2026, 8, 10)
    assert read.first_seen == MOMENT
    assert read.revised_at is None


def test_an_unknown_id_reads_as_nothing(store):
    assert store.get_item("nope") is None


def test_an_update_keeps_the_day_it_was_first_seen(store):
    item = make_item("A title", date(2026, 8, 10))
    store.insert_item(item, first_seen=MOMENT)
    later = datetime(2026, 8, 14, 9, 0, 0)
    store.update_item(make_item("A better title", date(2026, 8, 10), key="A title"), later)
    read = store.get_item(item.id)
    assert read.title == "A better title"
    assert read.first_seen == MOMENT
    assert read.revised_at == later


def test_items_come_back_newest_first(store):
    for title, day in [
        ("Older", date(2026, 8, 9)),
        ("Newest", date(2026, 8, 11)),
        ("Middle", date(2026, 8, 10)),
    ]:
        store.insert_item(make_item(title, day), first_seen=MOMENT)
    assert [item.title for item in store.all_items()] == ["Newest", "Middle", "Older"]


def test_a_day_holds_its_own_items_in_a_fixed_order(store):
    for title in ("Beta", "Alpha"):
        store.insert_item(make_item(title, date(2026, 8, 10)), first_seen=MOMENT)
    store.insert_item(make_item("Elsewhere", date(2026, 8, 9)), first_seen=MOMENT)
    assert [item.title for item in store.items_for_date(date(2026, 8, 10))] == ["Alpha", "Beta"]
    assert store.items_for_date(date(2026, 1, 1)) == []


def test_items_can_be_read_by_feed(store):
    store.insert_item(make_item("Here", date(2026, 8, 10), feed="one"), first_seen=MOMENT)
    store.insert_item(make_item("There", date(2026, 8, 10), feed="two"), first_seen=MOMENT)
    assert [item.title for item in store.items_for_feed("two")] == ["There"]


def test_items_since_a_moment_are_the_new_ones(store):
    store.insert_item(make_item("Old", date(2026, 8, 10)), first_seen=MOMENT)
    later = datetime(2026, 8, 13, 9, 0, 0)
    store.insert_item(make_item("New", date(2026, 8, 11)), first_seen=later)
    assert [item.title for item in store.items_since(MOMENT)] == ["New"]
    assert len(store.items_since(datetime(2020, 1, 1))) == 2


def test_the_days_with_items_come_back_newest_first(store):
    for title, day in [("A", date(2026, 8, 9)), ("B", date(2026, 8, 11)), ("C", date(2026, 8, 9))]:
        store.insert_item(make_item(title, day), first_seen=MOMENT)
    assert store.dates() == [date(2026, 8, 11), date(2026, 8, 9)]


def test_counts_report_the_whole_store(store):
    store.record_feed("one", "fixtures/one.xml", MOMENT)
    store.insert_item(make_item("A", date(2026, 8, 9)), first_seen=MOMENT)
    store.insert_item(make_item("B", date(2026, 8, 10)), first_seen=MOMENT)
    counts = store.counts()
    assert (counts.feeds, counts.items, counts.days) == (1, 2, 2)


def test_an_empty_store_counts_nothing(store):
    counts = store.counts()
    assert (counts.feeds, counts.items, counts.days) == (0, 0, 0)
    assert store.all_items() == [] and store.dates() == []
