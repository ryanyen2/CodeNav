"""Shared fixtures: a throwaway copy of the sample workspace for each test."""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path

import pytest

from ember.config import load_config

SAMPLE_ROOT = Path(__file__).resolve().parent.parent
SAMPLE_ITEMS = 36
SAMPLE_FEEDS = 5
SAMPLE_DAYS = 14
NOW = datetime(2026, 8, 12, 9, 0, 0)


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """A writable copy of the bundled sample workspace."""
    root = tmp_path / "workspace"
    root.mkdir()
    for name in ("ember.toml", "feeds.toml"):
        shutil.copy(SAMPLE_ROOT / name, root / name)
    shutil.copytree(SAMPLE_ROOT / "fixtures", root / "fixtures")
    shutil.copytree(SAMPLE_ROOT / "templates", root / "templates")
    return root


@pytest.fixture
def config(workspace: Path):
    return load_config(workspace)


@pytest.fixture
def bare(tmp_path: Path) -> Path:
    """A workspace with one small feed and nothing read yet."""
    root = tmp_path / "bare"
    (root / "fixtures" / "feeds").mkdir(parents=True)
    shutil.copytree(SAMPLE_ROOT / "templates", root / "templates")
    (root / "ember.toml").write_text(
        '[digest]\ntitle = "Bare"\ndigest_items_max = 4\n', encoding="utf-8"
    )
    (root / "feeds.toml").write_text(
        '[[feed]]\nname = "only"\nurl = "fixtures/feeds/only.xml"\n', encoding="utf-8"
    )
    write_feed(root, "only", rss_document([rss_item("First", "only-1", "Mon, 10 Aug 2026")]))
    return root


def rss_item(
    title: str,
    guid: str,
    pub_date: str,
    summary: str = "Something happened.",
    link: str = "",
) -> str:
    """One <item>, with the fields a test cares about."""
    href = link or f"https://feed.test/{guid}"
    return (
        "    <item>\n"
        f"      <title>{title}</title>\n"
        f"      <link>{href}</link>\n"
        f'      <guid isPermaLink="false">{guid}</guid>\n'
        f"      <pubDate>{pub_date} 09:00:00 +0000</pubDate>\n"
        f"      <description>{summary}</description>\n"
        "    </item>\n"
    )


def rss_document(items: list[str], title: str = "Test Feed") -> str:
    """A whole RSS 2.0 document around *items*."""
    return (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<rss version="2.0">\n  <channel>\n'
        f"    <title>{title}</title>\n"
        "    <link>https://feed.test/</link>\n"
        "    <description>A feed for tests.</description>\n"
        f"{''.join(items)}"
        "  </channel>\n</rss>\n"
    )


def write_feed(root: Path, name: str, text: str) -> Path:
    """Put a feed document where a spec named *name* would look for it."""
    path = root / "fixtures" / "feeds" / f"{name}.xml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


def add_rss_item(root: Path, feed: str, **fields) -> Path:
    """Put a new entry at the top of one of the sample RSS feeds."""
    path = root / "fixtures" / "feeds" / f"{feed}.xml"
    text = path.read_text(encoding="utf-8")
    at = text.index("    <item>")
    path.write_text(text[:at] + rss_item(**fields) + "\n" + text[at:], encoding="utf-8")
    return path


def add_atom_entry(
    root: Path,
    feed: str,
    *,
    title: str,
    guid: str,
    published: str,
    summary: str = "Something happened.",
) -> Path:
    """Put a new entry at the top of one of the sample Atom feeds."""
    path = root / "fixtures" / "feeds" / f"{feed}.xml"
    text = path.read_text(encoding="utf-8")
    entry = (
        "  <entry>\n"
        f"    <title>{title}</title>\n"
        f'    <link rel="alternate" type="text/html" href="https://feed.test/{guid}"/>\n'
        f"    <id>{guid}</id>\n"
        f"    <published>{published}</published>\n"
        f"    <updated>{published}</updated>\n"
        f"    <summary>{summary}</summary>\n"
        "  </entry>\n\n"
    )
    at = text.index("  <entry>")
    path.write_text(text[:at] + entry + text[at:], encoding="utf-8")
    return path


def edit(path: Path, old: str, new: str) -> None:
    """Replace *old* with *new* in a file, insisting it was there."""
    text = path.read_text(encoding="utf-8")
    assert old in text, f"{old!r} is not in {path}"
    path.write_text(text.replace(old, new), encoding="utf-8")


def read_output(root: Path, rel: str) -> str:
    return (root / "_digest" / rel).read_text(encoding="utf-8")


def output_exists(root: Path, rel: str) -> bool:
    return (root / "_digest" / rel).is_file()
