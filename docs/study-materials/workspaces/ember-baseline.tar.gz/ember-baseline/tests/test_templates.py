from dataclasses import dataclass
from datetime import date
from pathlib import Path

import pytest

from ember.templates import Environment, TemplateError, render


@dataclass
class Thing:
    title: str
    published: date


def env_with(tmp_path: Path, page: str, others: dict[str, str] | None = None) -> Environment:
    """An environment holding *page* under the name ``page``, plus *others*."""
    for name, text in {"page": page, **(others or {})}.items():
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    return Environment(tmp_path, globals={"site": {"title": "Ember"}})


def test_a_value_is_substituted(tmp_path):
    env = env_with(tmp_path, page="<h1>{{ title }}</h1>")
    assert env.render("page", {"title": "Monday"}) == "<h1>Monday</h1>"


def test_values_are_escaped_on_the_way_out(tmp_path):
    env = env_with(tmp_path, page="<p>{{ title }}</p>")
    rendered = env.render("page", {"title": 'Beans & "garlic" <b>'})
    assert rendered == "<p>Beans &amp; &quot;garlic&quot; &lt;b&gt;</p>"


def test_globals_reach_every_template_and_can_be_overridden(tmp_path):
    env = env_with(tmp_path, page="{{ site.title }}")
    assert env.render("page", {}) == "Ember"
    assert env.render("page", {"site": {"title": "Other"}}) == "Other"


def test_lookups_walk_dicts_and_objects(tmp_path):
    env = env_with(tmp_path, page="{{ thing.title }} {{ mapping.key }}")
    ctx = {"thing": Thing("A title", date(2026, 8, 10)), "mapping": {"key": "value"}}
    assert env.render("page", ctx) == "A title value"


def test_a_name_that_is_not_there_is_an_error(tmp_path):
    env = env_with(tmp_path, page="{{ absent }}")
    with pytest.raises(TemplateError, match="'absent' is not defined"):
        env.render("page", {})


def test_a_loop_repeats_its_body(tmp_path):
    env = env_with(tmp_path, page="{% for item in items %}[{{ item }}]{% endfor %}")
    assert env.render("page", {"items": ["a", "b"]}) == "[a][b]"


def test_a_loop_over_nothing_writes_nothing(tmp_path):
    env = env_with(tmp_path, page="{% for item in items %}[{{ item }}]{% endfor %}")
    assert env.render("page", {"items": []}) == ""


def test_a_loop_over_a_string_is_a_mistake(tmp_path):
    env = env_with(tmp_path, page="{% for item in items %}x{% endfor %}")
    with pytest.raises(TemplateError, match="is not a list"):
        env.render("page", {"items": "abc"})


def test_a_conditional_takes_one_side(tmp_path):
    env = env_with(tmp_path, page="{% if items %}some{% else %}none{% endif %}")
    assert env.render("page", {"items": [1]}) == "some"
    assert env.render("page", {"items": []}) == "none"
    assert env.render("page", {"items": 0}) == "none"


def test_not_reverses_a_test(tmp_path):
    env = env_with(tmp_path, page="{% if not items %}empty{% endif %}")
    assert env.render("page", {"items": []}) == "empty"


def test_a_conditional_on_a_name_that_is_not_there_is_false(tmp_path):
    env = env_with(tmp_path, page="{% if absent %}yes{% endif %}no")
    assert env.render("page", {}) == "no"


def test_an_include_brings_in_another_template(tmp_path):
    env = env_with(
        tmp_path,
        page='<body>{% include "partials/head.html" %}</body>',
        others={"partials/head.html": "<title>{{ title }}</title>"},
    )
    assert env.render("page", {"title": "Day"}) == "<body><title>Day</title></body>"


def test_an_include_that_is_not_there_says_so(tmp_path):
    env = env_with(tmp_path, page='{% include "absent.html" %}')
    with pytest.raises(TemplateError, match="no such template"):
        env.render("page", {})


def test_the_date_filter_takes_a_format(tmp_path):
    env = env_with(tmp_path, page='{{ day | date("%d %b %Y") }}|{{ day | date }}')
    assert env.render("page", {"day": date(2026, 8, 10)}) == "10 Aug 2026|2026-08-10"


def test_the_date_filter_refuses_something_that_is_not_a_date(tmp_path):
    env = env_with(tmp_path, page="{{ day | date }}")
    with pytest.raises(TemplateError, match="rejected its input"):
        env.render("page", {"day": "Monday"})


def test_the_length_and_upper_filters(tmp_path):
    env = env_with(tmp_path, page="{{ items | length }} {{ word | upper }}")
    assert env.render("page", {"items": [1, 2, 3], "word": "quiet"}) == "3 QUIET"


def test_filters_chain(tmp_path):
    env = env_with(tmp_path, page='{{ day | date("%b") | upper }}')
    assert env.render("page", {"day": date(2026, 8, 10)}) == "AUG"


def test_an_unknown_filter_is_an_error(tmp_path):
    env = env_with(tmp_path, page="{{ word | shout }}")
    with pytest.raises(TemplateError, match="unknown filter 'shout'"):
        env.render("page", {"word": "hello"})


def test_an_unknown_tag_is_an_error(tmp_path):
    env = env_with(tmp_path, page="{% while true %}{% endwhile %}")
    with pytest.raises(TemplateError, match="unknown tag"):
        env.render("page", {})


def test_a_loop_that_is_never_closed_is_an_error(tmp_path):
    env = env_with(tmp_path, page="{% for item in items %}x")
    with pytest.raises(TemplateError, match=r"missing \{% endfor %\}"):
        env.render("page", {})


def test_a_stray_end_tag_is_an_error(tmp_path):
    env = env_with(tmp_path, page="text{% endif %}")
    with pytest.raises(TemplateError, match="unexpected"):
        env.render("page", {})


def test_an_error_carries_the_template_and_the_line(tmp_path):
    env = env_with(tmp_path, page="one\ntwo\n{{ absent }}\n")
    with pytest.raises(TemplateError) as caught:
        env.render("page", {})
    assert caught.value.template == "page"
    assert caught.value.line == 3


def test_a_tag_on_its_own_line_does_not_leave_a_blank_one(tmp_path):
    env = env_with(tmp_path, page="<ul>\n  {% for item in items %}\n  <li>{{ item }}</li>\n  {% endfor %}\n</ul>\n")
    assert render("page", {"items": ["a", "b"]}, env) == "<ul>\n  <li>a</li>\n  <li>b</li>\n</ul>\n"


def test_the_bundled_templates_all_parse(workspace):
    env = Environment(workspace / "templates")
    for path in sorted((workspace / "templates").rglob("*.html")):
        name = path.relative_to(workspace / "templates").as_posix()
        assert env.nodes(name)
