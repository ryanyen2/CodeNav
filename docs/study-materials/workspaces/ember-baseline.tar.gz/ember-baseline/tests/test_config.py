from pathlib import Path

import pytest

from ember.config import ConfigError, EmberConfig, load_config


def write_config(root: Path, body: str) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    path = root / "ember.toml"
    path.write_text(body, encoding="utf-8")
    return path


def test_defaults_are_the_documented_ones():
    config = EmberConfig()
    assert config.data_dir == ".ember"
    assert config.output_dir == "_digest"
    assert config.template_dir == "templates"
    assert config.digest_items_max == 20


def test_the_sample_workspace_loads(workspace):
    config = load_config(workspace)
    assert config.title == "Ember Daily"
    assert config.digest_items_max == 12
    assert config.output_path(workspace) == workspace / "_digest"
    assert config.data_path(workspace) == workspace / ".ember"
    assert config.template_path(workspace) == workspace / "templates"


def test_a_missing_file_is_an_error(tmp_path):
    with pytest.raises(ConfigError, match="no ember.toml"):
        load_config(tmp_path)


def test_keys_may_sit_at_the_top_level(tmp_path):
    write_config(tmp_path, 'title = "Loose"\n')
    assert load_config(tmp_path).title == "Loose"


def test_bad_toml_is_reported_as_such(tmp_path):
    write_config(tmp_path, "[digest\n")
    with pytest.raises(ConfigError, match="not valid TOML"):
        load_config(tmp_path)


def test_an_unknown_key_names_the_ones_that_are_known(tmp_path):
    write_config(tmp_path, "[digest]\nitems_max = 4\n")
    with pytest.raises(ConfigError, match="unknown key.*items_max"):
        load_config(tmp_path)


def test_a_wrong_type_is_refused(tmp_path):
    write_config(tmp_path, '[digest]\ndigest_items_max = "twelve"\n')
    with pytest.raises(ConfigError, match="must be an integer"):
        load_config(tmp_path)


def test_true_is_not_an_integer(tmp_path):
    write_config(tmp_path, "[digest]\ndigest_items_max = true\n")
    with pytest.raises(ConfigError, match="must be an integer"):
        load_config(tmp_path)


def test_a_digest_of_no_items_makes_no_sense(tmp_path):
    write_config(tmp_path, "[digest]\ndigest_items_max = 0\n")
    with pytest.raises(ConfigError, match="at least 1"):
        load_config(tmp_path)


def test_an_empty_title_is_refused(tmp_path):
    write_config(tmp_path, '[digest]\ntitle = "  "\n')
    with pytest.raises(ConfigError, match="title must not be empty"):
        load_config(tmp_path)


@pytest.mark.parametrize("value", ["/tmp/out", "../out"])
def test_directories_stay_inside_the_workspace(tmp_path, value):
    write_config(tmp_path, f'[digest]\noutput_dir = "{value}"\n')
    with pytest.raises(ConfigError, match="relative path inside the workspace"):
        load_config(tmp_path)
