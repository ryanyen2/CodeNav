from datetime import datetime

import pytest

from ember.feeds import FeedSpec
from ember.fetch import FetchError, fetch, refresh, resolve_source
from ember.store import open_store

from tests.conftest import SAMPLE_FEEDS, SAMPLE_ITEMS, edit, rss_document, rss_item, write_feed


def spec(url: str, name: str = "one", max_items: int = 20) -> FeedSpec:
    return FeedSpec(name=name, url=url, max_items=max_items)


def test_a_relative_path_is_taken_from_the_workspace(workspace):
    path = resolve_source(spec("fixtures/feeds/north-light.xml"), workspace)
    assert path == workspace / "fixtures" / "feeds" / "north-light.xml"


def test_an_absolute_path_is_used_as_it_is(workspace):
    target = workspace / "fixtures" / "feeds" / "north-light.xml"
    assert resolve_source(spec(str(target)), workspace) == target


def test_a_file_url_is_understood(workspace):
    target = workspace / "fixtures" / "feeds" / "north-light.xml"
    assert resolve_source(spec(f"file://{target}"), workspace) == target


def test_a_file_url_with_an_escaped_space(tmp_path):
    target = write_feed(tmp_path, "with space", rss_document([]))
    assert resolve_source(spec(f"file://{target.parent}/with%20space.xml"), tmp_path) == target


def test_a_file_url_on_another_host_is_refused(workspace):
    with pytest.raises(FetchError, match="must be local"):
        resolve_source(spec("file://elsewhere/feed.xml"), workspace)


@pytest.mark.parametrize("url", ["http://feed.test/rss", "https://feed.test/rss"])
def test_the_network_is_stubbed_in_this_build(workspace, url):
    with pytest.raises(FetchError, match="network fetching is stubbed in this build"):
        resolve_source(spec(url), workspace)


def test_another_scheme_is_refused_by_name(workspace):
    with pytest.raises(FetchError, match="ftp:// urls are not supported"):
        resolve_source(spec("ftp://feed.test/rss"), workspace)


def test_a_source_that_is_not_there_says_where_it_looked(workspace):
    with pytest.raises(FetchError, match="no feed file at"):
        resolve_source(spec("fixtures/feeds/absent.xml"), workspace)


def test_fetch_returns_the_bytes_and_when_it_read_them(workspace):
    before = datetime.now().replace(microsecond=0)
    fetched = fetch(spec("fixtures/feeds/north-light.xml", name="north-light"), workspace)
    assert fetched.raw.startswith(b"<?xml")
    assert fetched.spec.name == "north-light"
    assert fetched.fetched_at >= before


def test_refresh_reads_every_feed(workspace):
    result = refresh(workspace)
    assert result.feeds == SAMPLE_FEEDS
    assert result.items.inserted == SAMPLE_ITEMS
    assert result.items.updated == 0
    assert f"{SAMPLE_ITEMS} items" in result.summary()


def test_refresh_stores_nothing_twice(workspace):
    refresh(workspace)
    result = refresh(workspace)
    assert result.items.inserted == 0
    assert result.items.unchanged == SAMPLE_ITEMS


def test_max_items_limits_what_one_run_takes(bare):
    items = [rss_item(f"Item {number}", f"only-{number}", "Mon, 10 Aug 2026") for number in range(5)]
    write_feed(bare, "only", rss_document(items))
    edit(bare / "feeds.toml", 'url = "fixtures/feeds/only.xml"', 'url = "fixtures/feeds/only.xml"\nmax_items = 2')

    assert refresh(bare).items.inserted == 2

    edit(bare / "feeds.toml", "max_items = 2", "max_items = 5")
    assert refresh(bare).items.inserted == 3


def test_refresh_records_when_each_feed_was_read(workspace, config):
    refresh(workspace)
    with open_store(config.data_path(workspace)) as store:
        feeds = store.feeds()
    assert len(feeds) == SAMPLE_FEEDS
    assert all(feed.last_fetched is not None for feed in feeds)
    assert feeds[0].url.startswith("fixtures/feeds/")
