import re

import pytest

from ember.cli import EXIT_ERROR, EXIT_OK, main

from tests.conftest import SAMPLE_DAYS, SAMPLE_ITEMS, output_exists, read_output


def run(*argv) -> int:
    return main(list(argv))


def test_refresh_then_digest_writes_a_readable_workspace(workspace, capsys):
    assert run("refresh", "--root", str(workspace)) == EXIT_OK
    assert run("digest", "--root", str(workspace)) == EXIT_OK

    lines = capsys.readouterr().out.splitlines()
    assert lines[0].startswith(f"5 feeds, {SAMPLE_ITEMS} items")
    assert lines[1] == f"{SAMPLE_DAYS} days, {SAMPLE_DAYS} digests written, latest 2026-08-11"
    assert lines[2].startswith("archive:")
    assert lines[3].endswith("logged to notifications.log")

    assert output_exists(workspace, "latest.html")
    assert output_exists(workspace, "archive/search.json")
    assert "Ember Daily" in read_output(workspace, "2026-08-11.html")


def test_a_second_digest_says_it_had_nothing_to_do(workspace, capsys):
    run("refresh", "--root", str(workspace))
    run("digest", "--root", str(workspace))
    capsys.readouterr()

    assert run("digest", "--root", str(workspace)) == EXIT_OK
    out = capsys.readouterr().out
    assert "nothing to write" in out
    assert "archive up to date" in out
    assert "nothing new to announce" in out


def test_a_single_day_can_be_asked_for(workspace, capsys):
    run("refresh", "--root", str(workspace))
    capsys.readouterr()

    assert run("digest", "--date", "2026-08-04", "--root", str(workspace)) == EXIT_OK
    assert "1 digest written" in capsys.readouterr().out
    assert output_exists(workspace, "2026-08-04.html")
    assert not output_exists(workspace, "2026-08-03.html")


def test_a_date_that_is_not_a_date_is_rejected(workspace, capsys):
    with pytest.raises(SystemExit) as caught:
        run("digest", "--date", "last tuesday", "--root", str(workspace))
    assert caught.value.code == 2
    assert "not a YYYY-MM-DD date" in capsys.readouterr().err


def test_archive_can_be_written_on_its_own(workspace, capsys):
    run("refresh", "--root", str(workspace))
    capsys.readouterr()

    assert run("archive", "--root", str(workspace)) == EXIT_OK
    assert "archive:" in capsys.readouterr().out
    assert output_exists(workspace, "archive/index.html")
    assert not output_exists(workspace, "latest.html")


def test_status_reports_the_feeds_before_anything_is_read(workspace, capsys):
    assert run("status", "--root", str(workspace)) == EXIT_OK
    out = capsys.readouterr().out
    assert "0 items from 0 feeds over 0 days" in out
    assert out.count("never read") == 5


def test_status_reports_what_was_read(workspace, capsys):
    run("refresh", "--root", str(workspace))
    capsys.readouterr()

    assert run("status", "--root", str(workspace)) == EXIT_OK
    out = capsys.readouterr().out
    assert f"{SAMPLE_ITEMS} items from 5 feeds over {SAMPLE_DAYS} days" in out
    assert re.search(r"saltbox-kitchen\s+8 items", out)
    assert "never read" not in out


def test_a_workspace_without_a_config_is_a_clean_failure(tmp_path, capsys):
    assert run("status", "--root", str(tmp_path)) == EXIT_ERROR
    assert capsys.readouterr().err.startswith("ember: no ember.toml")


def test_a_feed_that_is_not_there_is_a_clean_failure(workspace, capsys):
    (workspace / "fixtures" / "feeds" / "north-light.xml").unlink()
    assert run("refresh", "--root", str(workspace)) == EXIT_ERROR
    assert "north-light: no feed file at" in capsys.readouterr().err


def test_a_command_is_required(capsys):
    with pytest.raises(SystemExit):
        run()
    assert "command" in capsys.readouterr().err


def test_the_version_is_reported(capsys):
    with pytest.raises(SystemExit) as caught:
        run("--version")
    assert caught.value.code == EXIT_OK
    assert capsys.readouterr().out.startswith("ember ")
