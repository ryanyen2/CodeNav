from pathlib import Path

import pytest

from ember.feeds import DEFAULT_MAX_ITEMS, FeedsError, load_feeds


def write_feeds(root: Path, body: str) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    path = root / "feeds.toml"
    path.write_text(body, encoding="utf-8")
    return path


ONE = '[[feed]]\nname = "one"\nurl = "fixtures/feeds/one.xml"\n'


def test_the_sample_feeds_load_in_order(workspace):
    specs = load_feeds(workspace)
    assert [spec.name for spec in specs] == [
        "saltbox-kitchen",
        "ridgeline-notes",
        "plane-and-chisel",
        "slow-extraction",
        "north-light",
    ]
    assert specs[0].url == "fixtures/feeds/saltbox-kitchen.xml"
    assert specs[3].max_items == 8


def test_max_items_has_a_default(tmp_path):
    write_feeds(tmp_path, ONE)
    assert load_feeds(tmp_path)[0].max_items == DEFAULT_MAX_ITEMS


def test_a_missing_file_is_an_error(tmp_path):
    with pytest.raises(FeedsError, match="no feeds.toml"):
        load_feeds(tmp_path)


def test_bad_toml_is_reported_as_such(tmp_path):
    write_feeds(tmp_path, "[[feed]\n")
    with pytest.raises(FeedsError, match="not valid TOML"):
        load_feeds(tmp_path)


def test_a_file_with_no_feeds_says_so(tmp_path):
    write_feeds(tmp_path, "# nothing here yet\n")
    with pytest.raises(FeedsError, match="nothing to read"):
        load_feeds(tmp_path)


def test_feed_must_be_a_list_of_tables(tmp_path):
    write_feeds(tmp_path, 'feed = "one"\n')
    with pytest.raises(FeedsError, match="list of tables"):
        load_feeds(tmp_path)


@pytest.mark.parametrize("missing", ["name", "url"])
def test_name_and_url_are_both_required(tmp_path, missing):
    body = "\n".join(line for line in ONE.splitlines() if not line.startswith(missing))
    write_feeds(tmp_path, body + "\n")
    with pytest.raises(FeedsError, match=f"{missing} is required"):
        load_feeds(tmp_path)


def test_an_unknown_key_is_refused(tmp_path):
    write_feeds(tmp_path, ONE + 'colour = "red"\n')
    with pytest.raises(FeedsError, match="unknown key.*colour"):
        load_feeds(tmp_path)


def test_a_wrong_type_is_refused(tmp_path):
    write_feeds(tmp_path, ONE + 'max_items = "lots"\n')
    with pytest.raises(FeedsError, match="max_items must be an integer"):
        load_feeds(tmp_path)


def test_max_items_must_take_at_least_one(tmp_path):
    write_feeds(tmp_path, ONE + "max_items = 0\n")
    with pytest.raises(FeedsError, match="at least 1"):
        load_feeds(tmp_path)


@pytest.mark.parametrize("name", ["Big Name", "../escape", "-leading"])
def test_a_name_has_to_look_like_a_slug(tmp_path, name):
    write_feeds(tmp_path, f'[[feed]]\nname = "{name}"\nurl = "x.xml"\n')
    with pytest.raises(FeedsError, match="name must be lowercase"):
        load_feeds(tmp_path)


def test_two_feeds_cannot_share_a_name(tmp_path):
    write_feeds(tmp_path, ONE + "\n" + ONE)
    with pytest.raises(FeedsError, match="configured twice"):
        load_feeds(tmp_path)


def test_the_position_of_a_bad_feed_is_reported(tmp_path):
    write_feeds(tmp_path, ONE + '\n[[feed]]\nname = "two"\n')
    with pytest.raises(FeedsError, match="feed 2: url is required"):
        load_feeds(tmp_path)
