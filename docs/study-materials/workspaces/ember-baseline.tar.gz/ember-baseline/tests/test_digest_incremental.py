"""Second and later runs: what gets written again, and what does not."""

from datetime import date

from ember.archive import refresh_archive
from ember.digest import run_digest
from ember.fetch import refresh
from ember.notify import record

from tests.conftest import (
    SAMPLE_DAYS,
    add_rss_item,
    edit,
    output_exists,
    read_output,
)

NEW_DAY = date(2026, 8, 10)


def digest_pass(root):
    """One `ember digest`: the pages, the archive, then the log."""
    result = run_digest(root)
    archive = refresh_archive(root)
    notes = record(root, result.regenerated)
    return result, archive, notes


def days_written(result) -> list[str]:
    return [selection.day.isoformat() for selection in result.regenerated]


def test_the_first_pass_writes_every_day_and_the_latest(workspace):
    refresh(workspace)
    result, archive, notes = digest_pass(workspace)
    assert result.days == SAMPLE_DAYS
    assert len(result.regenerated) == SAMPLE_DAYS
    assert result.latest_day == date(2026, 8, 11)
    assert result.latest_written is True
    assert archive.regenerated is True
    assert notes.count == 36
    assert output_exists(workspace, "2026-08-11.html")
    assert read_output(workspace, "latest.html") == read_output(workspace, "2026-08-11.html")


def test_a_second_pass_writes_nothing(workspace):
    refresh(workspace)
    digest_pass(workspace)
    result, archive, notes = digest_pass(workspace)
    assert result.regenerated == []
    assert result.latest_written is False
    assert archive.regenerated is False
    assert notes.count == 0
    assert "nothing to write" in result.summary()


def test_a_refresh_that_brings_in_nothing_leaves_the_pass_idle(workspace):
    refresh(workspace)
    digest_pass(workspace)
    refresh(workspace)
    result, archive, notes = digest_pass(workspace)
    assert (result.regenerated, archive.regenerated, notes.count) == ([], False, 0)


def test_a_new_item_rebuilds_its_day_the_latest_and_one_notification(workspace):
    refresh(workspace)
    digest_pass(workspace)

    add_rss_item(
        workspace,
        "north-light",
        title="A late frame",
        guid="north-light-late",
        pub_date="Mon, 10 Aug 2026",
        summary="One more from the harbour wall.",
    )
    refresh(workspace)

    result, archive, notes = digest_pass(workspace)
    assert days_written(result) == ["2026-08-10"]
    assert archive.regenerated is True
    assert notes.count == 1
    assert notes.notifications[0].title == "A late frame"
    assert "A late frame" in read_output(workspace, "2026-08-10.html")
    assert "A late frame" not in read_output(workspace, "2026-08-11.html")


def test_the_same_item_is_not_announced_twice(workspace):
    refresh(workspace)
    digest_pass(workspace)
    add_rss_item(
        workspace,
        "north-light",
        title="A late frame",
        guid="north-light-late",
        pub_date="Mon, 10 Aug 2026",
    )
    refresh(workspace)
    digest_pass(workspace)

    _, _, notes = digest_pass(workspace)
    assert notes.count == 0
    log = read_output(workspace, "notifications.log")
    assert log.count("A late frame") == 1
    assert len(log.splitlines()) == 37


def test_an_item_on_the_newest_day_moves_the_latest_page(workspace):
    refresh(workspace)
    digest_pass(workspace)
    add_rss_item(
        workspace,
        "north-light",
        title="Rain again",
        guid="north-light-rain-again",
        pub_date="Tue, 11 Aug 2026",
    )
    refresh(workspace)

    result, _, _ = digest_pass(workspace)
    assert days_written(result) == ["2026-08-11"]
    assert result.latest_written is True
    assert "Rain again" in read_output(workspace, "latest.html")


def test_an_edited_entry_rebuilds_only_the_day_it_is_on(workspace):
    refresh(workspace)
    digest_pass(workspace)
    edit(
        workspace / "fixtures" / "feeds" / "saltbox-kitchen.xml",
        "<title>The stock pot as a weekly habit</title>",
        "<title>The stock pot, weekly</title>",
    )
    refresh(workspace)

    result, archive, notes = digest_pass(workspace)
    assert days_written(result) == ["2026-08-04"]
    assert archive.regenerated is True
    assert notes.count == 0
    assert "The stock pot, weekly" in read_output(workspace, "2026-08-04.html")


def test_a_feed_option_does_not_rebuild_the_digest(workspace):
    """feeds.toml is fetch configuration: the digest never reads it."""
    refresh(workspace)
    digest_pass(workspace)

    edit(
        workspace / "feeds.toml",
        'url = "fixtures/feeds/slow-extraction.xml"\nmax_items = 8',
        'url = "fixtures/feeds/slow-extraction.xml"\nmax_items = 4',
    )
    refresh(workspace)

    result, archive, notes = digest_pass(workspace)
    assert result.regenerated == []
    assert archive.regenerated is False
    assert notes.count == 0


def test_a_day_can_be_written_on_its_own(workspace):
    refresh(workspace)
    result = run_digest(workspace, day=NEW_DAY)
    assert days_written(result) == ["2026-08-10"]
    assert output_exists(workspace, "2026-08-10.html")
    assert not output_exists(workspace, "2026-08-09.html")
    assert output_exists(workspace, "latest.html")


def test_a_page_that_has_gone_missing_comes_back(workspace):
    refresh(workspace)
    digest_pass(workspace)
    (workspace / "_digest" / "2026-08-06.html").unlink()

    result, _, notes = digest_pass(workspace)
    assert days_written(result) == ["2026-08-06"]
    assert notes.count == 0
    assert output_exists(workspace, "2026-08-06.html")


def test_a_damaged_state_file_costs_one_pass(workspace):
    refresh(workspace)
    digest_pass(workspace)
    (workspace / ".ember" / "digest-state.json").write_text("{oh dear", encoding="utf-8")

    result, _, notes = digest_pass(workspace)
    assert len(result.regenerated) == SAMPLE_DAYS
    assert notes.count == 0
