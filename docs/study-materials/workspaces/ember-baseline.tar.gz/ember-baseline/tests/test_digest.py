from dataclasses import replace
from datetime import date, datetime

import pytest

from ember.config import EmberConfig
from ember.digest import (
    DigestSelection,
    assemble_digest,
    day_label,
    digest_rel,
    digest_signature,
    group_by_feed,
)
from ember.fetch import refresh
from ember.store import open_store

from tests.conftest import edit
from tests.test_store import make_item

DAY = date(2026, 8, 10)
MOMENT = datetime(2026, 8, 12, 9, 0, 0)


@pytest.fixture
def store(tmp_path):
    with open_store(tmp_path / ".ember") as opened:
        yield opened


def selection_of(items: list) -> DigestSelection:
    return DigestSelection(day=DAY, items=items, groups=group_by_feed(items))


def stock(store, titles, feed="one", day=DAY):
    for title in titles:
        store.insert_item(make_item(title, day, feed=feed), first_seen=MOMENT)


def test_a_day_takes_its_own_items(store):
    stock(store, ["Here"])
    stock(store, ["Elsewhere"], day=date(2026, 8, 9))
    selection = assemble_digest(store, EmberConfig(), DAY)
    assert [item.title for item in selection.items] == ["Here"]
    assert selection.day == DAY


def test_the_selection_is_capped_at_the_configured_maximum(store):
    stock(store, [f"Item {number}" for number in range(9)])
    selection = assemble_digest(store, EmberConfig(digest_items_max=4), DAY)
    assert selection.total == 4
    assert [item.title for item in selection.items] == ["Item 0", "Item 1", "Item 2", "Item 3"]


def test_items_are_grouped_by_feed(store):
    stock(store, ["Bread", "Stock"], feed="kitchen")
    stock(store, ["Chisels"], feed="workshop")
    selection = assemble_digest(store, EmberConfig(), DAY)
    assert selection.feeds == 2
    assert [(group.feed, group.count) for group in selection.groups] == [
        ("kitchen", 2),
        ("workshop", 1),
    ]
    assert [item.title for item in selection.groups[0].items] == ["Bread", "Stock"]


def test_a_group_keeps_the_order_the_items_arrived_in(store):
    stock(store, ["Alpha"], feed="second")
    stock(store, ["Beta"], feed="first")
    selection = assemble_digest(store, EmberConfig(), DAY)
    assert [group.feed for group in selection.groups] == ["second", "first"]


def test_a_day_with_nothing_on_it_is_an_empty_selection(store):
    selection = assemble_digest(store, EmberConfig(), DAY)
    assert selection.total == 0 and selection.groups == []


def test_the_signature_is_the_same_for_the_same_items(store):
    stock(store, ["Bread", "Stock"])
    first = digest_signature(assemble_digest(store, EmberConfig(), DAY))
    again = digest_signature(assemble_digest(store, EmberConfig(), DAY))
    assert first == again


def test_the_signature_moves_when_a_title_changes(store):
    stock(store, ["Bread"])
    before = assemble_digest(store, EmberConfig(), DAY)
    after = selection_of([replace(item, title="A better title") for item in before.items])
    assert digest_signature(after) != digest_signature(before)


def test_the_signature_moves_when_a_summary_changes(store):
    stock(store, ["Bread"])
    before = assemble_digest(store, EmberConfig(), DAY)
    after = selection_of([replace(item, summary="Rewritten.") for item in before.items])
    assert digest_signature(after) != digest_signature(before)


def test_the_signature_moves_when_an_item_joins_or_leaves(store):
    stock(store, ["Bread"])
    before = assemble_digest(store, EmberConfig(), DAY)
    joined = selection_of([*before.items, make_item("Stock", DAY)])
    assert digest_signature(joined) != digest_signature(before)
    assert digest_signature(selection_of([])) != digest_signature(before)


def test_the_signature_moves_when_the_order_changes(store):
    stock(store, ["Bread", "Stock"])
    before = assemble_digest(store, EmberConfig(), DAY)
    assert digest_signature(selection_of(before.items[::-1])) != digest_signature(before)


def test_a_link_or_author_edit_leaves_the_signature_alone(store):
    stock(store, ["Bread"])
    before = assemble_digest(store, EmberConfig(), DAY)
    after = selection_of(
        [replace(item, link="https://moved.test/", author="Someone Else") for item in before.items]
    )
    assert digest_signature(after) == digest_signature(before)


def test_a_feed_option_does_not_move_the_signature(workspace, config):
    """feeds.toml configures the fetch; the digest is gated on its selection."""
    refresh(workspace)
    with open_store(config.data_path(workspace)) as store:
        before = digest_signature(assemble_digest(store, config, date(2026, 8, 10)))

    edit(
        workspace / "feeds.toml",
        'url = "fixtures/feeds/north-light.xml"\nmax_items = 12',
        'url = "fixtures/feeds/north-light.xml"\nmax_items = 3',
    )
    refresh(workspace)

    with open_store(config.data_path(workspace)) as store:
        after = digest_signature(assemble_digest(store, config, date(2026, 8, 10)))
    assert after == before


def test_where_a_day_and_its_heading_go():
    assert digest_rel(DAY) == "2026-08-10.html"
    assert day_label(DAY) == "Monday 10 August 2026"
