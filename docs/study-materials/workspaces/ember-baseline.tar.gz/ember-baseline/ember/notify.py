"""The log of what arrived, and the line a run prints about it.

One line per item ember had not seen before, appended to
``_digest/notifications.log``. The log is written from the digests that were
regenerated, so a run that had nothing to write has nothing to announce, and
an item is announced once however often its day's page is rebuilt afterwards.

What "had not seen before" means is kept in ``.ember/notify-state.json``: the
newest ``first_seen`` already logged, plus the ids logged at that exact
second, since a refresh can bring in several items with the same stamp.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .config import load_config
from .normalize import Item
from .render import append_lines

LOG_REL = "notifications.log"
STATE_NAME = "notify-state.json"
STATE_VERSION = 1


@dataclass(frozen=True)
class Notification:
    """One item's line in the log."""

    at: datetime
    feed: str
    title: str
    link: str

    def line(self) -> str:
        stamp = self.at.isoformat(timespec="seconds")
        tail = f"  {self.link}" if self.link else ""
        return f"{stamp}  [{self.feed}]  {self.title}{tail}"


@dataclass(frozen=True)
class NotifyResult:
    """What one run logged."""

    notifications: list[Notification]
    log_rel: str = LOG_REL

    @property
    def count(self) -> int:
        return len(self.notifications)

    def summary(self) -> str:
        if not self.notifications:
            return "nothing new to announce"
        feeds = len({note.feed for note in self.notifications})
        return (
            f"{self.count} new item{'' if self.count == 1 else 's'} from {feeds} "
            f"feed{'' if feeds == 1 else 's'} logged to {self.log_rel}"
        )


class NotifyState:
    """How far through the arrivals the log has got."""

    def __init__(self, path: Path, through: datetime | None = None, edge: list[str] | None = None):
        self.path = path
        self.through = through
        self.edge = set(edge or [])

    @classmethod
    def load(cls, data_dir: Path | str) -> "NotifyState":
        path = Path(data_dir) / STATE_NAME
        state = cls(path)
        if not path.is_file():
            return state
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, OSError):
            return state
        if not isinstance(data, dict) or data.get("version") != STATE_VERSION:
            return state
        state.through = _to_datetime(data.get("through"))
        edge = data.get("edge")
        if isinstance(edge, list):
            state.edge = {item for item in edge if isinstance(item, str)}
        return state

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": STATE_VERSION,
            "through": self.through.isoformat(timespec="seconds") if self.through else None,
            "edge": sorted(self.edge),
        }
        self.path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )

    def is_new(self, item: Item) -> bool:
        """True when *item* arrived after everything already logged."""
        if item.first_seen is None:
            return False
        if self.through is None or item.first_seen > self.through:
            return True
        return item.first_seen == self.through and item.id not in self.edge

    def advance(self, items: list[Item]) -> None:
        """Move the mark past *items*."""
        newest = max(item.first_seen for item in items if item.first_seen)
        if newest != self.through:
            self.through = newest
            self.edge = set()
        self.edge |= {item.id for item in items if item.first_seen == newest}


def pending(selections: list, state: NotifyState) -> list[Item]:
    """The items in *selections* that have not been logged yet, oldest first."""
    found: dict[str, Item] = {}
    for selection in selections:
        for item in selection.items:
            if item.id not in found and state.is_new(item):
                found[item.id] = item
    return sorted(found.values(), key=lambda item: (item.first_seen, item.feed, item.title))


def record(root: Path | str, selections: list) -> NotifyResult:
    """Log the new items in *selections* and remember how far the log has got."""
    root = Path(root)
    config = load_config(root)
    state = NotifyState.load(config.data_path(root))

    items = pending(selections, state)
    if not items:
        return NotifyResult([])

    notifications = [
        Notification(at=item.first_seen, feed=item.feed, title=item.title, link=item.link)
        for item in items
    ]
    append_lines(config.output_path(root), LOG_REL, [note.line() for note in notifications])
    state.advance(items)
    state.save()
    return NotifyResult(notifications)


def _to_datetime(value) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None
