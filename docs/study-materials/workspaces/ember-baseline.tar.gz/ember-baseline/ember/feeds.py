"""Reading ``feeds.toml``: what to read, and how much of it to take.

The file is a list of tables, one per feed::

    [[feed]]
    name = "saltbox-kitchen"
    url = "fixtures/feeds/saltbox-kitchen.xml"
    max_items = 12

``name`` is the identity a feed keeps in the store and the directory its
archive page lives in, so it is required to look like a slug. ``url`` may be
a ``file://`` url or a path relative to the workspace root.
"""

from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass
from pathlib import Path

FEEDS_NAME = "feeds.toml"
DEFAULT_MAX_ITEMS = 20

_NAME = re.compile(r"[a-z0-9][a-z0-9._-]*")


class FeedsError(Exception):
    """Raised when feeds.toml is missing, unparseable, or has bad values."""


@dataclass(frozen=True)
class FeedSpec:
    """One feed, as configured.

    ``max_items`` is how many entries a refresh takes from the front of the
    document. Entries past it are left for a later run, when the feed has
    scrolled them into reach or the cap has been raised.
    """

    name: str
    url: str
    max_items: int = DEFAULT_MAX_ITEMS


# key -> (expected type, human name)
_SCHEMA: dict[str, tuple[type, str]] = {
    "name": (str, "a string"),
    "url": (str, "a string"),
    "max_items": (int, "an integer"),
}


def load_feeds(root: Path | str) -> list[FeedSpec]:
    """Load every feed configured in *root*, in the order they are written."""
    path = Path(root) / FEEDS_NAME
    if not path.is_file():
        raise FeedsError(f"no {FEEDS_NAME} found in {root}")

    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise FeedsError(f"{FEEDS_NAME} is not valid TOML: {exc}") from exc
    except UnicodeDecodeError as exc:
        raise FeedsError(f"{FEEDS_NAME} is not valid UTF-8: {exc}") from exc

    tables = raw.get("feed", [])
    if not isinstance(tables, list) or not all(isinstance(item, dict) for item in tables):
        raise FeedsError(f"{FEEDS_NAME}: [[feed]] must be a list of tables")
    if not tables:
        raise FeedsError(f"{FEEDS_NAME}: no [[feed]] tables, so there is nothing to read")

    specs = [_build(table, position) for position, table in enumerate(tables, start=1)]
    _reject_repeats(specs)
    return specs


def _build(table: dict, position: int) -> FeedSpec:
    where = f"{FEEDS_NAME}: feed {position}"
    unknown = sorted(set(table) - set(_SCHEMA))
    if unknown:
        known = ", ".join(sorted(_SCHEMA))
        raise FeedsError(f"{where}: unknown key(s) {', '.join(unknown)}; known keys are {known}")

    for key in ("name", "url"):
        if key not in table:
            raise FeedsError(f"{where}: {key} is required")

    kwargs: dict[str, object] = {}
    for key, value in table.items():
        expected, described = _SCHEMA[key]
        if not isinstance(value, expected) or (expected is int and isinstance(value, bool)):
            raise FeedsError(f"{where}: {key} must be {described}, got {value!r}")
        kwargs[key] = value

    spec = FeedSpec(**kwargs)  # type: ignore[arg-type]
    if not _NAME.fullmatch(spec.name):
        raise FeedsError(
            f"{where}: name must be lowercase letters, digits, dot, dash or underscore, "
            f"got {spec.name!r}"
        )
    if not spec.url.strip():
        raise FeedsError(f"{where}: url must not be empty")
    if spec.max_items < 1:
        raise FeedsError(f"{where}: max_items must be at least 1, got {spec.max_items}")
    return spec


def _reject_repeats(specs: list[FeedSpec]) -> None:
    """A repeated name would give two feeds one identity in the store."""
    seen: set[str] = set()
    for spec in specs:
        if spec.name in seen:
            raise FeedsError(f"{FEEDS_NAME}: {spec.name!r} is configured twice")
        seen.add(spec.name)
