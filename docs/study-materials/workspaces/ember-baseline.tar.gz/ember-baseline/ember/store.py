"""The sqlite store: the feeds ember has read and the items it has kept.

Two tables. ``feeds`` records what was read and when; ``items`` holds every
entry ever seen, keyed by the identity ``normalize`` derives, with the times
ember first saw a row and last saw it change.

The schema is created when the database is opened and its version is kept in
``PRAGMA user_version``. A database from a future version is refused rather
than guessed at.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import date, datetime
from pathlib import Path
from typing import Iterator

from .normalize import Item

DB_NAME = "ember.db"
SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE feeds (
    name         TEXT PRIMARY KEY,
    url          TEXT NOT NULL,
    last_fetched TEXT
);
CREATE TABLE items (
    id           TEXT PRIMARY KEY,
    feed         TEXT NOT NULL,
    title        TEXT NOT NULL,
    link         TEXT NOT NULL,
    published    TEXT NOT NULL,
    summary      TEXT NOT NULL,
    author       TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    first_seen   TEXT NOT NULL,
    revised_at   TEXT
);
CREATE INDEX items_by_date ON items (published);
CREATE INDEX items_by_feed ON items (feed);
"""

# Newest first, then by title so a day's items come out in a fixed order.
_ORDER = "ORDER BY published DESC, title ASC, id ASC"
_COLUMNS = (
    "id, feed, title, link, published, summary, author, content_hash, first_seen, revised_at"
)


class StoreError(Exception):
    """Raised when the database cannot be opened or is of an unknown version."""


@dataclass(frozen=True)
class FeedRecord:
    """What the store knows about a feed it has read."""

    name: str
    url: str
    last_fetched: datetime | None


@dataclass(frozen=True)
class Counts:
    """How much the store holds."""

    feeds: int
    items: int
    days: int


class Store:
    """Typed access to the database. Use it as a context manager."""

    def __init__(self, connection: sqlite3.Connection):
        self._connection = connection

    @classmethod
    def open(cls, data_dir: Path | str) -> "Store":
        """Open (creating if needed) the database under *data_dir*."""
        directory = Path(data_dir)
        directory.mkdir(parents=True, exist_ok=True)
        try:
            connection = sqlite3.connect(directory / DB_NAME)
        except sqlite3.Error as exc:
            raise StoreError(f"cannot open {directory / DB_NAME}: {exc}") from exc
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        _prepare(connection, directory / DB_NAME)
        return cls(connection)

    def close(self) -> None:
        self._connection.close()

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def record_feed(self, name: str, url: str, fetched_at: datetime) -> None:
        """Note that *name* was read at *fetched_at*."""
        with self._connection:
            self._connection.execute(
                "INSERT INTO feeds (name, url, last_fetched) VALUES (?, ?, ?) "
                "ON CONFLICT(name) DO UPDATE SET url=excluded.url, "
                "last_fetched=excluded.last_fetched",
                (name, url, fetched_at.isoformat(timespec="seconds")),
            )

    def feeds(self) -> list[FeedRecord]:
        """Every feed the store has read, by name."""
        rows = self._connection.execute(
            "SELECT name, url, last_fetched FROM feeds ORDER BY name"
        ).fetchall()
        return [
            FeedRecord(row["name"], row["url"], _to_datetime(row["last_fetched"]))
            for row in rows
        ]

    def insert_item(self, item: Item, first_seen: datetime) -> Item:
        """Store an item ember has not seen before."""
        stored = replace(item, first_seen=first_seen, revised_at=None)
        with self._connection:
            self._connection.execute(
                f"INSERT INTO items ({_COLUMNS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                _to_row(stored),
            )
        return stored

    def update_item(self, item: Item, revised_at: datetime) -> Item:
        """Replace a stored item's content, keeping the day ember first saw it."""
        existing = self.get_item(item.id)
        first_seen = existing.first_seen if existing else revised_at
        stored = replace(item, first_seen=first_seen, revised_at=revised_at)
        with self._connection:
            self._connection.execute(
                "UPDATE items SET feed=?, title=?, link=?, published=?, summary=?, "
                "author=?, content_hash=?, first_seen=?, revised_at=? WHERE id=?",
                (*_to_row(stored)[1:], stored.id),
            )
        return stored

    def get_item(self, item_id: str) -> Item | None:
        row = self._connection.execute(
            f"SELECT {_COLUMNS} FROM items WHERE id=?", (item_id,)
        ).fetchone()
        return _to_item(row) if row else None

    def all_items(self) -> list[Item]:
        """Every stored item, newest first."""
        return self._select("")

    def items_for_date(self, day: date) -> list[Item]:
        """The items published on *day*, newest first."""
        return self._select("WHERE published=?", (day.isoformat(),))

    def items_for_feed(self, feed: str) -> list[Item]:
        """Everything a feed has ever brought in, newest first."""
        return self._select("WHERE feed=?", (feed,))

    def items_since(self, moment: datetime) -> list[Item]:
        """The items first seen after *moment*, newest first."""
        return self._select("WHERE first_seen > ?", (moment.isoformat(timespec="seconds"),))

    def dates(self) -> list[date]:
        """Every day that has items, newest first."""
        rows = self._connection.execute(
            "SELECT DISTINCT published FROM items ORDER BY published DESC"
        ).fetchall()
        return [date.fromisoformat(row["published"]) for row in rows]

    def counts(self) -> Counts:
        row = self._connection.execute(
            "SELECT (SELECT COUNT(*) FROM feeds) AS feeds, "
            "(SELECT COUNT(*) FROM items) AS items, "
            "(SELECT COUNT(DISTINCT published) FROM items) AS days"
        ).fetchone()
        return Counts(feeds=row["feeds"], items=row["items"], days=row["days"])

    def _select(self, where: str, parameters: tuple = ()) -> list[Item]:
        rows = self._connection.execute(
            f"SELECT {_COLUMNS} FROM items {where} {_ORDER}", parameters
        ).fetchall()
        return [_to_item(row) for row in rows]


@contextmanager
def open_store(data_dir: Path | str) -> Iterator[Store]:
    """Open the store under *data_dir* and close it when the caller is done."""
    store = Store.open(data_dir)
    try:
        yield store
    finally:
        store.close()


def _prepare(connection: sqlite3.Connection, path: Path) -> None:
    version = connection.execute("PRAGMA user_version").fetchone()[0]
    if version == SCHEMA_VERSION:
        return
    if version == 0:
        with connection:
            connection.executescript(_SCHEMA)
            connection.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
        return
    raise StoreError(
        f"{path} was written by schema version {version}, this ember speaks "
        f"version {SCHEMA_VERSION}"
    )


def _to_row(item: Item) -> tuple:
    return (
        item.id,
        item.feed,
        item.title,
        item.link,
        item.published.isoformat(),
        item.summary,
        item.author,
        item.content_hash,
        _from_datetime(item.first_seen),
        _from_datetime(item.revised_at),
    )


def _to_item(row: sqlite3.Row) -> Item:
    return Item(
        id=row["id"],
        feed=row["feed"],
        title=row["title"],
        link=row["link"],
        published=date.fromisoformat(row["published"]),
        summary=row["summary"],
        author=row["author"],
        content_hash=row["content_hash"],
        first_seen=_to_datetime(row["first_seen"]),
        revised_at=_to_datetime(row["revised_at"]),
    )


def _to_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _from_datetime(value: datetime | None) -> str | None:
    return value.isoformat(timespec="seconds") if value else None
