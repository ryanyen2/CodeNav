"""Where generated files go, and how they get there.

Every page ember writes is a ``Doc``: a path relative to the output directory
and the text that belongs at it. Writes go to a neighbouring temporary file
first and are then moved into place, so a reader never sees half a page, and
an interrupted run leaves the previous one intact.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

TEMP_SUFFIX = ".writing"


@dataclass(frozen=True)
class Doc:
    """A generated file: where it goes, and what goes in it."""

    output_rel: str
    text: str


def write_doc(output_root: Path | str, doc: Doc) -> str:
    """Write one doc and return the path it was written to."""
    return write_text(output_root, doc.output_rel, doc.text)


def write_docs(output_root: Path | str, docs: list[Doc]) -> list[str]:
    """Write several docs and return their paths."""
    return [write_doc(output_root, doc) for doc in docs]


def write_text(output_root: Path | str, rel: str, text: str) -> str:
    """Write *text* to *rel* under the output directory, creating the way to it."""
    target = resolve(output_root, rel)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + TEMP_SUFFIX)
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, target)
    return rel


def append_lines(output_root: Path | str, rel: str, lines: list[str]) -> str:
    """Add *lines* to the end of *rel*, starting the file if it is not there."""
    target = resolve(output_root, rel)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        for line in lines:
            handle.write(line + "\n")
    return rel


def replace_outputs(output_root: Path | str, previous: list[str], docs: list[Doc]) -> list[str]:
    """Write *docs* and take away whatever *previous* wrote that they do not.

    A generated set that has shrunk since last time would otherwise leave the
    pages it no longer produces sitting in the output directory, looking as
    current as the rest.
    """
    fresh = [doc.output_rel for doc in docs]
    for stale in sorted(set(previous) - set(fresh)):
        remove(output_root, stale)
    write_docs(output_root, docs)
    return fresh


def remove(output_root: Path | str, rel: str) -> None:
    """Delete a generated file and any directory it leaves empty."""
    target = resolve(output_root, rel)
    if target.is_file():
        target.unlink()
    prune(output_root, target.parent)


def prune(output_root: Path | str, directory: Path) -> None:
    """Walk up from *directory*, removing empty directories inside the output."""
    root = Path(output_root)
    while directory != root and directory.is_relative_to(root):
        if not directory.is_dir() or any(directory.iterdir()):
            return
        directory.rmdir()
        directory = directory.parent


def resolve(output_root: Path | str, rel: str) -> Path:
    """The absolute path of *rel*, which has to stay inside the output."""
    root = Path(output_root)
    target = (root / rel).resolve()
    if not target.is_relative_to(root.resolve()):
        raise ValueError(f"{rel!r} is outside the output directory")
    return target


def exists(output_root: Path | str, rel: str) -> bool:
    return resolve(output_root, rel).is_file()
