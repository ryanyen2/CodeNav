"""Reading feed sources, and the refresh pass over every configured feed.

Network fetching is stubbed in this build: a feed's url is either a ``file://``
url or a path relative to the workspace root, and an ``http(s)`` url is
refused rather than quietly returning nothing.

The refresh pass is the only part of ember that reads ``feeds.toml``. It walks
the configured feeds, reads each source, and puts what it finds through parse,
normalize and upsert into the store.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote, urlparse

from .config import load_config
from .dedupe import UpsertResult, upsert_items
from .feeds import FeedSpec, load_feeds
from .normalize import normalize_entries
from .parse import parse_feed
from .store import open_store

LOCAL_SCHEMES = ("", "file")


class FetchError(Exception):
    """Raised when a feed's source cannot be read."""


@dataclass(frozen=True)
class Fetched:
    """One read of a feed source."""

    spec: FeedSpec
    raw: bytes
    fetched_at: datetime


@dataclass(frozen=True)
class RefreshResult:
    """What one refresh brought in."""

    feeds: int
    items: UpsertResult
    duration: float

    def summary(self) -> str:
        return (
            f"{self.feeds} feeds, {self.items.total} items: "
            f"{self.items.summary()}, took {self.duration:.2f}s"
        )


def fetch(spec: FeedSpec, root: Path | str) -> Fetched:
    """Read the source *spec* points at, relative to *root* if it is a path."""
    path = resolve_source(spec, root)
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise FetchError(f"{spec.name}: cannot read {path}: {exc}") from exc
    return Fetched(spec=spec, raw=raw, fetched_at=datetime.now().replace(microsecond=0))


def resolve_source(spec: FeedSpec, root: Path | str) -> Path:
    """Work out which file a feed's url names.

    Accepts ``file:///absolute/path``, an absolute path and a path relative to
    the workspace root. Anything reachable only over the network is refused.
    """
    url = spec.url.strip()
    parsed = urlparse(url)
    if parsed.scheme in ("http", "https"):
        raise FetchError(
            f"{spec.name}: network fetching is stubbed in this build; "
            f"point the feed at a local feed file instead of {url}"
        )
    if parsed.scheme not in LOCAL_SCHEMES:
        raise FetchError(f"{spec.name}: {parsed.scheme}:// urls are not supported ({url})")
    if parsed.scheme == "file":
        if parsed.netloc not in ("", "localhost"):
            raise FetchError(f"{spec.name}: file urls must be local, got {url}")
        url = unquote(parsed.path)

    path = Path(url)
    if not path.is_absolute():
        path = Path(root) / path
    if not path.is_file():
        raise FetchError(f"{spec.name}: no feed file at {path}")
    return path


def refresh(root: Path | str) -> RefreshResult:
    """Read every configured feed and put what it holds into the store."""
    started = time.perf_counter()
    root = Path(root)
    config = load_config(root)
    specs = load_feeds(root)

    totals = UpsertResult()
    with open_store(config.data_path(root)) as store:
        for spec in specs:
            totals += _refresh_one(store, spec, root)

    return RefreshResult(
        feeds=len(specs),
        items=totals,
        duration=time.perf_counter() - started,
    )


def _refresh_one(store, spec: FeedSpec, root: Path) -> UpsertResult:
    """Read one feed, take its first ``max_items`` entries, and store them."""
    fetched = fetch(spec, root)
    parsed = parse_feed(fetched.raw, spec.name)
    entries = parsed.entries[: spec.max_items]
    items = normalize_entries(entries, spec.name, fetched.fetched_at)
    result = upsert_items(store, items, fetched.fetched_at)
    store.record_feed(spec.name, spec.url, fetched.fetched_at)
    return result
