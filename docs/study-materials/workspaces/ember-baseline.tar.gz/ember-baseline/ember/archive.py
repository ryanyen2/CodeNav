"""The archive: every day, every feed, and the corpus a search box would read.

Three things are generated here. ``archive/index.html`` lists the days that
have items and the feeds behind them, ``archive/<feed>/index.html`` lists
everything one feed has ever brought in, and ``archive/search.json`` is the
same items as data.

The archive has a signature of its own, over every stored item rather than
over one day's selection, so it is rewritten when the collection as a whole
moves and not when a single day's page does.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from .config import EmberConfig, load_config
from .normalize import Item
from .render import Doc, replace_outputs
from .store import open_store
from .templates import Environment

STATE_NAME = "archive-state.json"
STATE_VERSION = 1
INDEX_REL = "archive/index.html"
SEARCH_REL = "archive/search.json"
ARCHIVE_TEMPLATE = "archive.html"
FEED_TEMPLATE = "feed-archive.html"


@dataclass(frozen=True)
class ArchiveResult:
    """What one pass over the archive did."""

    regenerated: bool
    days: int
    feeds: int
    items: int
    written: list[str]

    def summary(self) -> str:
        if not self.regenerated:
            return "archive up to date"
        return (
            f"archive: {self.items} items, {self.feeds} feeds, {self.days} days, "
            f"{len(self.written)} files written"
        )


def archive_signature(items: list[Item]) -> str:
    """sha256 over everything the archive pages and the corpus show."""
    canonical = json.dumps(
        [[item.id, item.feed, item.title, item.published.isoformat(), item.link] for item in items],
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def feed_rel(feed: str) -> str:
    """Where a feed's archive page goes, relative to the output directory."""
    return f"archive/{feed}/index.html"


def days_of(items: list[Item]) -> list[dict]:
    """One entry per day that has items, newest first."""
    counts: dict[date, list[Item]] = {}
    for item in items:
        counts.setdefault(item.published, []).append(item)
    return [
        {
            "date": day,
            "iso": day.isoformat(),
            "url": f"../{day.isoformat()}.html",
            "count": len(day_items),
            "feeds": len({item.feed for item in day_items}),
        }
        for day, day_items in sorted(counts.items(), reverse=True)
    ]


def feeds_of(items: list[Item]) -> list[dict]:
    """One entry per feed with items, by name."""
    gathered: dict[str, list[Item]] = {}
    for item in items:
        gathered.setdefault(item.feed, []).append(item)
    return [
        {
            "name": feed,
            "url": f"{feed}/index.html",
            "count": len(feed_items),
            "newest": max(item.published for item in feed_items),
        }
        for feed, feed_items in sorted(gathered.items())
    ]


def build_index(items: list[Item], config: EmberConfig, env: Environment) -> Doc:
    """Render the archive's front page."""
    ctx = {
        "page_title": f"{config.title}: archive",
        "days": days_of(items),
        "feeds": feeds_of(items),
        "total": len(items),
        "latest_url": "../latest.html",
    }
    return Doc(INDEX_REL, env.render(ARCHIVE_TEMPLATE, ctx))


def build_feed_pages(items: list[Item], config: EmberConfig, env: Environment) -> list[Doc]:
    """Render one page per feed, holding everything that feed has brought in."""
    docs: list[Doc] = []
    for feed in feeds_of(items):
        name = feed["name"]
        ctx = {
            "page_title": f"{config.title}: {name}",
            "feed": feed,
            "items": [item for item in items if item.feed == name],
            "index_url": "../index.html",
            "latest_url": "../../latest.html",
        }
        docs.append(Doc(feed_rel(name), env.render(FEED_TEMPLATE, ctx)))
    return docs


def build_search(items: list[Item]) -> Doc:
    """Write every item out as data, for a search box to read."""
    corpus = [
        {
            "title": item.title,
            "feed": item.feed,
            "date": item.published.isoformat(),
            "url": item.link,
        }
        for item in items
    ]
    return Doc(SEARCH_REL, json.dumps(corpus, indent=2, ensure_ascii=False) + "\n")


def refresh_archive(root: Path | str) -> ArchiveResult:
    """Write the archive pages when the collection behind them has changed."""
    root = Path(root)
    config = load_config(root)
    output_root = config.output_path(root)
    state = _State.load(config.data_path(root))

    with open_store(config.data_path(root)) as store:
        items = store.all_items()

    signature = archive_signature(items)
    days = days_of(items)
    feeds = feeds_of(items)
    if signature == state.signature and _all_present(output_root, state.outputs):
        return ArchiveResult(False, len(days), len(feeds), len(items), [])

    env = Environment(config.template_path(root), globals={"ember": {"title": config.title}})
    docs = [build_index(items, config, env), build_search(items)]
    docs.extend(build_feed_pages(items, config, env))
    written = replace_outputs(output_root, state.outputs, docs)

    state.signature = signature
    state.outputs = written
    state.save()
    return ArchiveResult(True, len(days), len(feeds), len(items), written)


class _State:
    """The signature the archive was last written from, and what it wrote."""

    def __init__(self, path: Path, signature: str = "", outputs: list[str] | None = None):
        self.path = path
        self.signature = signature
        self.outputs = list(outputs or [])

    @classmethod
    def load(cls, data_dir: Path | str) -> "_State":
        path = Path(data_dir) / STATE_NAME
        state = cls(path)
        if not path.is_file():
            return state
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, OSError):
            return state
        if not isinstance(data, dict) or data.get("version") != STATE_VERSION:
            return state
        state.signature = str(data.get("signature", ""))
        outputs = data.get("outputs")
        if isinstance(outputs, list):
            state.outputs = [rel for rel in outputs if isinstance(rel, str)]
        return state

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": STATE_VERSION,
            "signature": self.signature,
            "outputs": sorted(self.outputs),
        }
        self.path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )


def _all_present(output_root: Path, outputs: list[str]) -> bool:
    return bool(outputs) and all((output_root / rel).is_file() for rel in outputs)
