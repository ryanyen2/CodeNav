"""A very small template engine.

Templates are HTML with four constructs: ``{{ expression }}`` substitution,
``{% for x in xs %}``/``{% endfor %}`` loops, ``{% if x %}``/``{% else %}``/
``{% endif %}`` conditionals and ``{% include "partial.html" %}``.

An expression is a literal or a dotted lookup into the context, optionally
piped through filters: ``{{ item.published | date("%b %d") }}``. Lookups walk
dictionary keys and object attributes alike, so a stored item can be handed to
a template as it is.

Substituted values are HTML-escaped. Nothing ember renders is markup -- feed
titles and summaries have had their tags taken out by then -- so escaping on
the way out is always what is wanted, and a template never has to remember.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

_TOKEN = re.compile(r"\{\{(?P<out>.*?)\}\}|\{%(?P<tag>.*?)%\}", re.DOTALL)
_FOR = re.compile(r"^for\s+([A-Za-z_]\w*)\s+in\s+(\S.*)$")
_IF = re.compile(r"^if\s+(\S.*)$")
_INCLUDE = re.compile(r'^include\s+"([^"]+)"$')
_FILTER = re.compile(r"^(\w+)(?:\((?P<args>.*)\))?$")
_LOOKUP = re.compile(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*")
_INDENT_BEFORE_TAG = re.compile(r"\n[ \t]+\Z")
_CLOSING = ("else", "endif", "endfor")

MISSING = object()


class TemplateError(Exception):
    """Raised for a syntax or lookup failure, tagged with template and line."""

    def __init__(self, message: str, template: str, line: int):
        super().__init__(f"{template}:{line}: {message}")
        self.template = template
        self.line = line


@dataclass
class _Token:
    kind: str
    body: str
    line: int


@dataclass
class _Text:
    text: str

    def emit(self, scope: dict, env: "Environment") -> str:
        return self.text


@dataclass
class _Output:
    expr: str
    where: tuple[str, int]

    def emit(self, scope: dict, env: "Environment") -> str:
        value = _evaluate(self.expr, scope, self.where)
        if value is MISSING:
            raise TemplateError(f"{self.expr!r} is not defined", *self.where)
        return html.escape(_as_text(value))


@dataclass
class _Loop:
    name: str
    expr: str
    where: tuple[str, int]
    body: list = field(default_factory=list)

    def emit(self, scope: dict, env: "Environment") -> str:
        values = _evaluate(self.expr, scope, self.where)
        if values is MISSING or values is None:
            return ""
        if isinstance(values, (str, bytes, dict)) or not hasattr(values, "__iter__"):
            raise TemplateError(f"{self.expr!r} is not a list", *self.where)
        inner = dict(scope)
        parts = []
        for value in values:
            inner[self.name] = value
            parts.append(_emit_all(self.body, inner, env))
        return "".join(parts)


@dataclass
class _Branch:
    expr: str
    where: tuple[str, int]
    body: list = field(default_factory=list)
    otherwise: list = field(default_factory=list)

    def emit(self, scope: dict, env: "Environment") -> str:
        taken = self.body if _truthy(_evaluate(self.expr, scope, self.where)) else self.otherwise
        return _emit_all(taken, scope, env)


@dataclass
class _Include:
    name: str
    where: tuple[str, int]

    def emit(self, scope: dict, env: "Environment") -> str:
        return _emit_all(env.nodes(self.name), scope, env)


class Environment:
    """Loads, parses and caches the templates in a directory.

    Names in *globals* reach every template, and are overridden by
    anything of the same name in a render context.
    """

    def __init__(self, directory: Path | str, globals: dict | None = None):
        self.directory = Path(directory)
        self.globals: dict = dict(globals or {})
        self._parsed: dict[str, list] = {}

    def source(self, name: str) -> str:
        path = self.directory / name
        if not path.is_file():
            raise TemplateError(f"no such template {name!r}", name, 0)
        return path.read_text(encoding="utf-8")

    def nodes(self, name: str) -> list:
        if name not in self._parsed:
            self._parsed[name] = _parse(self.source(name), name)
        return self._parsed[name]

    def render(self, name: str, ctx: dict) -> str:
        """Render the template *name* with the mapping *ctx*."""
        return _emit_all(self.nodes(name), {**self.globals, **ctx}, self)


def render(name: str, ctx: dict, env: Environment) -> str:
    """Render the template *name* from *env* with the mapping *ctx*."""
    return env.render(name, ctx)


def _emit_all(nodes: list, scope: dict, env: Environment) -> str:
    return "".join(node.emit(scope, env) for node in nodes)


def _parse(source: str, template: str) -> list:
    nodes, _ = _parse_until(_tokenize(source, template), 0, template, ())
    return nodes


def _tokenize(source: str, template: str) -> list[_Token]:
    """Split the source into text, ``{{ }}`` and ``{% %}`` tokens.

    A tag on a line of its own takes the indentation before it and the
    newline after it with it, so a loop over a list does not leave a stack of
    blank lines in the page.
    """
    tokens: list[_Token] = []
    line = 1
    cursor = 0
    for match in _TOKEN.finditer(source):
        is_tag = match.group("tag") is not None
        text = source[cursor : match.start()]
        if is_tag:
            text = _INDENT_BEFORE_TAG.sub("\n", text)
        if text:
            tokens.append(_Token("text", text, line))
        line += source.count("\n", cursor, match.start())
        body = (match.group("tag") if is_tag else match.group("out")).strip()
        if not body:
            raise TemplateError("empty tag", template, line)
        tokens.append(_Token("tag" if is_tag else "out", body, line))
        line += match.group(0).count("\n")
        cursor = match.end()
        if is_tag and source[cursor : cursor + 1] == "\n":
            cursor += 1
            line += 1
    if source[cursor:]:
        tokens.append(_Token("text", source[cursor:], line))
    return tokens


def _parse_until(tokens: list[_Token], index: int, template: str, stop: tuple[str, ...]):
    """Read nodes until one of the *stop* tags, which is left for the caller."""
    nodes: list = []
    while index < len(tokens):
        token = tokens[index]
        where = (template, token.line)
        if token.kind == "text":
            nodes.append(_Text(token.body))
        elif token.kind == "out":
            nodes.append(_Output(token.body, where))
        elif token.body.split()[0] in stop:
            return nodes, index
        else:
            node, index = _parse_tag(tokens, index, template, where)
            nodes.append(node)
            continue
        index += 1
    return nodes, index


def _parse_tag(tokens: list[_Token], index: int, template: str, where: tuple[str, int]):
    body = tokens[index].body
    index += 1
    if body in _CLOSING:
        raise TemplateError(f"unexpected {{% {body} %}}", *where)
    if match := _FOR.match(body):
        node = _Loop(match.group(1), match.group(2).strip(), where)
        node.body, index = _parse_until(tokens, index, template, ("endfor",))
        return node, _expect(tokens, index, "endfor", where)
    if match := _IF.match(body):
        node = _Branch(match.group(1).strip(), where)
        node.body, index = _parse_until(tokens, index, template, ("else", "endif"))
        if index < len(tokens) and tokens[index].body == "else":
            node.otherwise, index = _parse_until(tokens, index + 1, template, ("endif",))
        return node, _expect(tokens, index, "endif", where)
    if match := _INCLUDE.match(body):
        return _Include(match.group(1), where), index
    raise TemplateError(f"unknown tag {{% {body} %}}", *where)


def _expect(tokens: list[_Token], index: int, word: str, where: tuple[str, int]) -> int:
    if index >= len(tokens) or tokens[index].body != word:
        raise TemplateError(f"missing {{% {word} %}}", *where)
    return index + 1


def _evaluate(expr: str, scope: dict, where: tuple[str, int]):
    steps = _split(expr, "|", where)
    value = _resolve(steps[0], scope, where)
    for step in steps[1:]:
        value = _filter(step, value, where)
    return value


def _resolve(expr: str, scope: dict, where: tuple[str, int]):
    if expr.startswith("not "):
        return not _truthy(_resolve(expr[4:].strip(), scope, where))
    literal = _literal(expr)
    if literal is not MISSING:
        return literal
    if not _LOOKUP.fullmatch(expr):
        raise TemplateError(f"cannot read {expr!r}", *where)
    head, *rest = expr.split(".")
    if head not in scope:
        return MISSING
    value = scope[head]
    for part in rest:
        if isinstance(value, dict):
            if part not in value:
                return MISSING
            value = value[part]
        elif hasattr(value, part):
            value = getattr(value, part)
        else:
            return MISSING
    return value


def _literal(expr: str):
    if len(expr) >= 2 and expr[0] == expr[-1] and expr[0] in "\"'":
        return expr[1:-1]
    if re.fullmatch(r"[+-]?\d+", expr):
        return int(expr)
    return {"true": True, "false": False, "none": None}.get(expr, MISSING)


def _filter(step: str, value, where: tuple[str, int]):
    match = _FILTER.match(step)
    if not match:
        raise TemplateError(f"cannot read filter {step!r}", *where)
    name = match.group(1)
    if name not in _FILTERS:
        raise TemplateError(f"unknown filter {name!r}", *where)
    args = [_argument(piece, where) for piece in _split(match.group("args") or "", ",", where)]
    try:
        return _FILTERS[name](value, *[arg for arg in args if arg is not MISSING])
    except TypeError as exc:
        raise TemplateError(f"filter {name!r} rejected its input: {exc}", *where) from exc


def _argument(piece: str, where: tuple[str, int]):
    piece = piece.strip()
    if not piece:
        return MISSING
    literal = _literal(piece)
    if literal is MISSING:
        raise TemplateError(f"filter argument {piece!r} is not a literal", *where)
    return literal


def _split(expr: str, separator: str, where: tuple[str, int]) -> list[str]:
    """Split on *separator*, leaving quoted text and parentheses alone."""
    parts: list[str] = []
    current: list[str] = []
    quote = ""
    depth = 0
    for char in expr:
        if quote:
            quote = "" if char == quote else quote
        elif char in "\"'":
            quote = char
        elif char in "()":
            depth += 1 if char == "(" else -1
        elif char == separator and depth == 0:
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(char)
    if quote or depth:
        raise TemplateError(f"unbalanced expression {expr!r}", *where)
    parts.append("".join(current).strip())
    if separator == "|" and any(not part for part in parts):
        raise TemplateError(f"empty step in expression {expr!r}", *where)
    return parts


def _date(value, fmt: str = "%Y-%m-%d") -> str:
    if value is None or value is MISSING:
        return ""
    if not isinstance(value, (date, datetime)):
        raise TypeError(f"{value!r} is not a date")
    return value.strftime(fmt)


def _length(value) -> int:
    if value is None or value is MISSING:
        return 0
    return len(value)


def _upper(value) -> str:
    return _as_text(value).upper()


_FILTERS = {"date": _date, "length": _length, "upper": _upper}


def _truthy(value) -> bool:
    if value is MISSING or value is None or value is False:
        return False
    if hasattr(value, "__len__"):
        return len(value) > 0
    if isinstance(value, int):
        return value != 0
    return True


def _as_text(value) -> str:
    if value is None or value is MISSING:
        return ""
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)
