"""Turning parsed entries into the items the store keeps.

Feeds are written by hand and by a dozen different generators, so everything
that arrives here is treated as approximate: markup is taken out of summaries,
runs of whitespace collapse, long summaries are cut back to a readable length,
and a date is worked out from whatever the entry offered.

The identity ember gives an item is a sha256 of the feed name and the entry's
own key. It has to stay the same across runs, which is why it is derived from
the entry's guid or link rather than from anything ember computes itself.
"""

from __future__ import annotations

import hashlib
import html
import re
from dataclasses import dataclass
from datetime import date, datetime

from .parse import RawEntry

SUMMARY_LIMIT = 280
UNTITLED = "(untitled)"

_TAG = re.compile(r"<[^>]*>")
_WHITESPACE = re.compile(r"\s+")
_AUTHOR_NAME = re.compile(r"\S+@\S+\s*\((.+)\)")
_AUTHOR_EMAIL = re.compile(r"\S+@\S+")
_ISO = re.compile(
    r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"
    r"(?:[T ](?P<hour>\d{2}):(?P<minute>\d{2})(?::\d{2}(?:\.\d+)?)?)?"
)
_RFC822 = re.compile(
    r"(?:[A-Za-z]{3},\s*)?(?P<day>\d{1,2})\s+(?P<month>[A-Za-z]{3,})\s+(?P<year>\d{2,4})"
)
_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


@dataclass(frozen=True)
class Item:
    """One entry, as ember stores and shows it.

    ``first_seen`` and ``revised_at`` are the store's to set: a freshly
    normalized item carries None for both until it has been through an upsert.
    """

    id: str
    feed: str
    title: str
    link: str
    published: date
    summary: str
    author: str
    content_hash: str
    first_seen: datetime | None = None
    revised_at: datetime | None = None


def normalize_entry(entry: RawEntry, feed: str, fetched_at: datetime) -> Item | None:
    """Turn one parsed entry into an item, or None if it cannot be keyed.

    An entry with no guid, link or title has nothing stable to identify it
    across runs, and every later fetch would store it again as new.
    """
    key = entry.guid.strip() or entry.link.strip() or clean_text(entry.title)
    if not key:
        return None

    title = clean_text(entry.title) or UNTITLED
    link = entry.link.strip()
    summary = truncate(clean_text(entry.summary))
    author = person(clean_text(entry.author))
    published = resolve_date(entry.published, fetched_at.date())
    return Item(
        id=item_identity(feed, key),
        feed=feed,
        title=title,
        link=link,
        published=published,
        summary=summary,
        author=author,
        content_hash=content_hash(title, link, published, summary, author),
    )


def normalize_entries(entries: list[RawEntry], feed: str, fetched_at: datetime) -> list[Item]:
    """Normalize a document's entries, keeping the first of any repeated id.

    A feed that lists the same guid twice is describing one item, and the
    copy nearer the top is the one it means.
    """
    items: list[Item] = []
    seen: set[str] = set()
    for entry in entries:
        item = normalize_entry(entry, feed, fetched_at)
        if item is None or item.id in seen:
            continue
        seen.add(item.id)
        items.append(item)
    return items


def item_identity(feed: str, key: str) -> str:
    """The stable id of an entry: sha256 over the feed name and the entry key."""
    digest = hashlib.sha256()
    digest.update(feed.encode("utf-8"))
    digest.update(b"\x00")
    digest.update(key.encode("utf-8"))
    return digest.hexdigest()


def content_hash(title: str, link: str, published: date, summary: str, author: str) -> str:
    """sha256 over the fields an edit to an entry would change."""
    digest = hashlib.sha256()
    for field in (title, link, published.isoformat(), summary, author):
        digest.update(field.encode("utf-8"))
        digest.update(b"\x00")
    return digest.hexdigest()


def clean_text(value: str) -> str:
    """Take the markup out of *value* and give it single spaces."""
    if not value:
        return ""
    text = _TAG.sub(" ", value)
    text = html.unescape(text)
    return _WHITESPACE.sub(" ", text).strip()


def person(author: str) -> str:
    """The name out of an author field.

    RSS says an author is an email address, and generators write it as
    ``someone@example.com (Their Name)``. Atom gives a name on its own. Both
    should come out as something a byline can show.
    """
    match = _AUTHOR_NAME.fullmatch(author)
    if match:
        return match.group(1).strip()
    return author.partition("@")[0].strip() if _AUTHOR_EMAIL.fullmatch(author) else author


def truncate(text: str, limit: int = SUMMARY_LIMIT) -> str:
    """Cut *text* to *limit* characters on a word boundary.

    The ellipsis counts towards the limit, so the result is never longer than
    asked for. A single word longer than the limit is cut mid-word, since
    there is no boundary to use.
    """
    if len(text) <= limit:
        return text
    head = text[: limit - 1]
    boundary = head.rfind(" ")
    if boundary > 0:
        head = head[:boundary]
    return head.rstrip(" ,;:.-") + "…"


def resolve_date(raw: str, fallback: date) -> date:
    """Read the calendar date out of *raw*, falling back to *fallback*.

    ISO 8601 and RFC 822 are both understood, which between them covers Atom
    and RSS. Any zone offset in the string is left alone: ember keeps naive
    dates, and the date an entry claims is the date it is digested under. An
    entry that gave no usable date is treated as having arrived on *fallback*.
    """
    text = (raw or "").strip()
    if not text:
        return fallback
    return _iso_date(text) or _rfc822_date(text) or fallback


def _iso_date(text: str) -> date | None:
    match = _ISO.match(text)
    if not match:
        return None
    return _build_date(int(match["year"]), int(match["month"]), int(match["day"]))


def _rfc822_date(text: str) -> date | None:
    match = _RFC822.match(text)
    if not match:
        return None
    month = _MONTHS.get(match["month"][:3].lower())
    if month is None:
        return None
    return _build_date(_full_year(int(match["year"])), month, int(match["day"]))


def _full_year(year: int) -> int:
    """RFC 822 allowed two digit years; the epoch splits at 1970."""
    if year >= 100:
        return year
    return 1900 + year if year >= 70 else 2000 + year


def _build_date(year: int, month: int, day: int) -> date | None:
    try:
        return date(year, month, day)
    except ValueError:
        return None
