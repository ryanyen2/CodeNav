"""Command line interface for ember."""

from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

from . import __version__
from .archive import refresh_archive
from .config import ConfigError, load_config
from .digest import run_digest
from .feeds import FeedsError, load_feeds
from .fetch import FetchError, refresh
from .notify import record
from .parse import ParseError
from .store import StoreError, open_store
from .templates import TemplateError

EXIT_OK = 0
EXIT_ERROR = 1

# Anything a badly configured workspace or a bad feed can raise. A stack trace
# helps nobody fix their feeds.toml.
WORKSPACE_ERRORS = (
    ConfigError,
    FeedsError,
    FetchError,
    ParseError,
    StoreError,
    TemplateError,
    OSError,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ember", description="Read feeds, write a digest.")
    parser.add_argument("--version", action="version", version=f"ember {__version__}")
    commands = parser.add_subparsers(dest="command", required=True, metavar="command")

    refresher = commands.add_parser("refresh", help="read every feed and store what it holds")
    _add_root(refresher)
    refresher.set_defaults(handler=_refresh)

    digester = commands.add_parser(
        "digest", help="write the digest pages, the archive and the notifications"
    )
    _add_root(digester)
    digester.add_argument(
        "--date",
        type=_day,
        metavar="YYYY-MM-DD",
        help="write just this day's digest (default: every day with items)",
    )
    digester.set_defaults(handler=_digest)

    archiver = commands.add_parser("archive", help="write the archive pages and the search corpus")
    _add_root(archiver)
    archiver.set_defaults(handler=_archive)

    reporter = commands.add_parser("status", help="say what has been read and what is stored")
    _add_root(reporter)
    reporter.set_defaults(handler=_status)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Run one command. Returns the process exit code."""
    args = build_parser().parse_args(argv)
    try:
        return args.handler(args)
    except WORKSPACE_ERRORS as exc:
        print(f"ember: {exc}", file=sys.stderr)
        return EXIT_ERROR
    except KeyboardInterrupt:
        return EXIT_OK


def _add_root(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--root",
        type=Path,
        default=Path.cwd(),
        metavar="PATH",
        help="workspace directory holding ember.toml (default: the working directory)",
    )


def _day(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{value!r} is not a YYYY-MM-DD date") from None


def _refresh(args) -> int:
    print(refresh(args.root).summary())
    return EXIT_OK


def _digest(args) -> int:
    result = run_digest(args.root, day=args.date)
    print(result.summary())
    print(refresh_archive(args.root).summary())
    print(record(args.root, result.regenerated).summary())
    return EXIT_OK


def _archive(args) -> int:
    print(refresh_archive(args.root).summary())
    return EXIT_OK


def _status(args) -> int:
    """Report the configured feeds, what each has brought in, and when."""
    root = Path(args.root)
    config = load_config(root)
    specs = load_feeds(root)
    with open_store(config.data_path(root)) as store:
        counts = store.counts()
        read = {feed.name: feed for feed in store.feeds()}
        stored = {spec.name: len(store.items_for_feed(spec.name)) for spec in specs}

    print(f"root: {root}")
    print(f"{counts.items} items from {counts.feeds} feeds over {counts.days} days")
    print(f"output: {config.output_path(root)}")
    width = max((len(spec.name) for spec in specs), default=0)
    for spec in specs:
        print(f"  {spec.name:<{width}}  {stored.get(spec.name, 0):>4} items   {_when(read, spec)}")
    return EXIT_OK


def _when(read: dict, spec) -> str:
    feed = read.get(spec.name)
    if feed is None or feed.last_fetched is None:
        return "never read"
    return feed.last_fetched.isoformat(sep=" ", timespec="minutes")
