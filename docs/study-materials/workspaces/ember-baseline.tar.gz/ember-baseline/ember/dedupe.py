"""What a fetched item does to the row already in the store.

A feed hands ember the same entries over and over, so most of what arrives on
a refresh is something it already has. Three outcomes, decided by the item's
identity and its content hash: an identity that is not in the store is
inserted, an identity whose content hash still matches is left alone, and an
identity whose content changed is written over with the time it changed.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from .normalize import Item
from .store import Store

INSERTED = "inserted"
UPDATED = "updated"
UNCHANGED = "unchanged"


@dataclass(frozen=True)
class UpsertResult:
    """How a run of items landed."""

    inserted: int = 0
    updated: int = 0
    unchanged: int = 0

    @property
    def total(self) -> int:
        return self.inserted + self.updated + self.unchanged

    def __add__(self, other: "UpsertResult") -> "UpsertResult":
        return UpsertResult(
            inserted=self.inserted + other.inserted,
            updated=self.updated + other.updated,
            unchanged=self.unchanged + other.unchanged,
        )

    def summary(self) -> str:
        return (
            f"{self.inserted} new, {self.updated} updated, {self.unchanged} unchanged"
        )


def upsert_item(store: Store, item: Item, seen_at: datetime) -> str:
    """Put one item in the store and say what that did."""
    existing = store.get_item(item.id)
    if existing is None:
        store.insert_item(item, first_seen=seen_at)
        return INSERTED
    if existing.content_hash == item.content_hash:
        return UNCHANGED
    store.update_item(item, revised_at=seen_at)
    return UPDATED


def upsert_items(store: Store, items: list[Item], seen_at: datetime) -> UpsertResult:
    """Put a document's worth of items in the store and tally the outcomes."""
    tally = {INSERTED: 0, UPDATED: 0, UNCHANGED: 0}
    for item in items:
        tally[upsert_item(store, item, seen_at)] += 1
    return UpsertResult(
        inserted=tally[INSERTED],
        updated=tally[UPDATED],
        unchanged=tally[UNCHANGED],
    )
