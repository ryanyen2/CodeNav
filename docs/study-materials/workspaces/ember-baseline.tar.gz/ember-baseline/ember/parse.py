"""Turning a feed document into entries.

Both RSS 2.0 and Atom are read here, into the same ``RawEntry``. Elements are
matched on their local name, so a document that puts RSS in a namespace, or
uses one of the several Atom namespaces in the wild, still parses.

Nothing is cleaned up at this stage: text comes out as the document wrote it,
including its markup and its own idea of a date. ``normalize`` is what turns
that into a stored item.
"""

from __future__ import annotations

from dataclasses import dataclass
from xml.etree import ElementTree

# Elements to read a summary out of, best first.
_RSS_SUMMARY = ("description", "encoded", "summary")
_ATOM_SUMMARY = ("summary", "content")


class ParseError(Exception):
    """Raised when a document is not well-formed XML or is not a feed."""


@dataclass(frozen=True)
class RawEntry:
    """One entry, exactly as the document gave it."""

    title: str = ""
    link: str = ""
    guid: str = ""
    published: str = ""
    summary: str = ""
    author: str = ""


@dataclass(frozen=True)
class ParsedFeed:
    """A parsed document: what the feed calls itself, and what is in it."""

    title: str
    format: str
    entries: list[RawEntry]


def parse_feed(raw: bytes | str, source: str = "feed") -> ParsedFeed:
    """Parse *raw* as RSS or Atom. *source* names the feed in error messages."""
    try:
        root = ElementTree.fromstring(raw)
    except ElementTree.ParseError as exc:
        raise ParseError(f"{source}: not well-formed XML: {exc}") from exc

    name = _local(root.tag)
    if name in ("rss", "rdf"):
        return _parse_rss(root, source)
    if name == "feed":
        return _parse_atom(root)
    raise ParseError(f"{source}: root element is <{name}>, which is neither RSS nor Atom")


def _parse_rss(root: ElementTree.Element, source: str) -> ParsedFeed:
    """Read an RSS 2.0 (or RSS 1.0) document.

    RSS 2.0 keeps its items inside <channel>; RSS 1.0 puts them beside it.
    Both are accepted, and both are read for the same fields.
    """
    channel = _child(root, "channel")
    if channel is None:
        raise ParseError(f"{source}: RSS document has no <channel>")
    items = _children(channel, "item") or _children(root, "item")
    return ParsedFeed(
        title=_text(channel, "title"),
        format="rss",
        entries=[_rss_entry(item) for item in items],
    )


def _rss_entry(item: ElementTree.Element) -> RawEntry:
    link = _text(item, "link")
    guid = _text(item, "guid")
    return RawEntry(
        title=_text(item, "title"),
        link=link or _guid_as_link(item, guid),
        guid=guid,
        published=_text(item, "pubDate") or _text(item, "date"),
        summary=_first_text(item, _RSS_SUMMARY),
        author=_text(item, "author") or _text(item, "creator"),
    )


def _guid_as_link(item: ElementTree.Element, guid: str) -> str:
    """A guid marked ``isPermaLink`` stands in for a missing <link>."""
    element = _child(item, "guid")
    if element is None or not guid.startswith(("http://", "https://")):
        return ""
    return "" if element.get("isPermaLink") == "false" else guid


def _parse_atom(root: ElementTree.Element) -> ParsedFeed:
    """Read an Atom document."""
    return ParsedFeed(
        title=_text(root, "title"),
        format="atom",
        entries=[_atom_entry(entry) for entry in _children(root, "entry")],
    )


def _atom_entry(entry: ElementTree.Element) -> RawEntry:
    author = _child(entry, "author")
    return RawEntry(
        title=_text(entry, "title"),
        link=_atom_link(entry),
        guid=_text(entry, "id"),
        published=_text(entry, "published") or _text(entry, "updated"),
        summary=_first_text(entry, _ATOM_SUMMARY),
        author=_text(author, "name") if author is not None else "",
    )


def _atom_link(entry: ElementTree.Element) -> str:
    """The entry's own page: the alternate link, else the first one with an href."""
    candidates = _children(entry, "link")
    for link in candidates:
        if link.get("rel", "alternate") == "alternate" and link.get("href"):
            return link.get("href", "").strip()
    for link in candidates:
        if link.get("href"):
            return link.get("href", "").strip()
    return ""


def _local(tag: str) -> str:
    """An element's name without its namespace, lowercased."""
    if not isinstance(tag, str):
        return ""
    return tag.rpartition("}")[2].lower()


def _children(parent: ElementTree.Element, name: str) -> list[ElementTree.Element]:
    """Every direct child of *parent* whose local name is *name*."""
    wanted = name.lower()
    return [child for child in parent if _local(child.tag) == wanted]


def _child(parent: ElementTree.Element, name: str) -> ElementTree.Element | None:
    children = _children(parent, name)
    return children[0] if children else None


def _text(parent: ElementTree.Element, name: str) -> str:
    """The text of the first *name* child, with any nested markup flattened.

    Atom text constructs may hold escaped HTML or inline XHTML; taking every
    descendant's text covers both without the caller having to care which.
    """
    element = _child(parent, name)
    if element is None:
        return ""
    return "".join(element.itertext()).strip()


def _first_text(parent: ElementTree.Element, names: tuple[str, ...]) -> str:
    for name in names:
        text = _text(parent, name)
        if text:
            return text
    return ""
