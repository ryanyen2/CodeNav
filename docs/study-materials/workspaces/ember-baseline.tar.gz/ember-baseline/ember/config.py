"""Reading and validating ``ember.toml``."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

CONFIG_NAME = "ember.toml"


class ConfigError(Exception):
    """Raised when ember.toml is missing, unparseable, or has bad values."""


@dataclass(frozen=True)
class EmberConfig:
    """Everything the digest needs to know about a workspace.

    Directory fields are names relative to the workspace root. Times are
    handled as naive local values throughout: ember records the date a feed
    put on an entry and never attaches a zone of its own.
    """

    title: str = "An ember digest"
    data_dir: str = ".ember"
    output_dir: str = "_digest"
    template_dir: str = "templates"
    digest_items_max: int = 20

    def data_path(self, root: Path) -> Path:
        return Path(root) / self.data_dir

    def output_path(self, root: Path) -> Path:
        return Path(root) / self.output_dir

    def template_path(self, root: Path) -> Path:
        return Path(root) / self.template_dir


# field name -> (expected type, human name)
_SCHEMA: dict[str, tuple[type, str]] = {
    "title": (str, "a string"),
    "data_dir": (str, "a string"),
    "output_dir": (str, "a string"),
    "template_dir": (str, "a string"),
    "digest_items_max": (int, "an integer"),
}


def load_config(root: Path | str) -> EmberConfig:
    """Load ``ember.toml`` from *root*.

    Raises ConfigError if the file is absent, is not valid TOML, contains a
    key ember does not know, or gives a key the wrong type.
    """
    root = Path(root)
    path = root / CONFIG_NAME
    if not path.is_file():
        raise ConfigError(f"no {CONFIG_NAME} found in {root}")

    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"{CONFIG_NAME} is not valid TOML: {exc}") from exc
    except UnicodeDecodeError as exc:
        raise ConfigError(f"{CONFIG_NAME} is not valid UTF-8: {exc}") from exc

    values = raw.get("digest", raw)
    if not isinstance(values, dict):
        raise ConfigError(f"{CONFIG_NAME}: [digest] must be a table")

    return _build(values)


def _build(values: dict) -> EmberConfig:
    unknown = sorted(set(values) - set(_SCHEMA))
    if unknown:
        known = ", ".join(sorted(_SCHEMA))
        raise ConfigError(
            f"{CONFIG_NAME}: unknown key(s) {', '.join(unknown)}; known keys are {known}"
        )

    kwargs: dict[str, object] = {}
    for key, value in values.items():
        expected, described = _SCHEMA[key]
        # bool is a subclass of int, so an integer key must reject `true`.
        if not isinstance(value, expected) or (expected is int and isinstance(value, bool)):
            raise ConfigError(f"{CONFIG_NAME}: {key} must be {described}, got {value!r}")
        kwargs[key] = value

    config = EmberConfig(**kwargs)  # type: ignore[arg-type]
    _validate(config)
    return config


def _validate(config: EmberConfig) -> None:
    if not config.title.strip():
        raise ConfigError(f"{CONFIG_NAME}: title must not be empty")
    if config.digest_items_max < 1:
        raise ConfigError(
            f"{CONFIG_NAME}: digest_items_max must be at least 1, "
            f"got {config.digest_items_max}"
        )
    for key in ("data_dir", "output_dir", "template_dir"):
        value = getattr(config, key)
        if not value.strip():
            raise ConfigError(f"{CONFIG_NAME}: {key} must not be empty")
        if Path(value).is_absolute() or ".." in Path(value).parts:
            raise ConfigError(
                f"{CONFIG_NAME}: {key} must be a relative path inside the workspace, "
                f"got {value!r}"
            )
