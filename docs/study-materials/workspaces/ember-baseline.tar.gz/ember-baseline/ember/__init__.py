"""ember: a feed reader that writes a daily digest.

Reads RSS and Atom feeds into a local sqlite store, then generates one HTML
page per day of arrivals, a browsable archive with a search corpus, and a log
of what came in. Python 3.11 or later, standard library only.
"""

__version__ = "0.4.0"

__all__ = ["__version__"]
