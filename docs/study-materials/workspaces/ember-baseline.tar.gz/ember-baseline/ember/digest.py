"""The daily digest: what a day's page holds, and when it is worth writing again.

A digest is one HTML page per day of arrivals, plus ``latest.html`` mirroring
the newest of them. Assembling one takes the items published on that day,
newest first, keeps at most ``digest_items_max`` of them and groups what is
left by feed.

Whether a page is written is decided by its signature: a sha256 over the
items the selection actually holds. The signature is computed from the
assembled selection, so the page is rewritten when, and only when, what it
shows would come out different.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

from .config import EmberConfig, load_config
from .normalize import Item
from .render import Doc, exists, write_doc
from .store import Store, open_store
from .templates import Environment

STATE_NAME = "digest-state.json"
STATE_VERSION = 1
LATEST_REL = "latest.html"
DIGEST_TEMPLATE = "digest.html"


@dataclass(frozen=True)
class FeedGroup:
    """One feed's part of a day."""

    feed: str
    items: list[Item]

    @property
    def count(self) -> int:
        return len(self.items)


@dataclass(frozen=True)
class DigestSelection:
    """The items one day's digest is made of."""

    day: date
    items: list[Item]
    groups: list[FeedGroup] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.items)

    @property
    def feeds(self) -> int:
        return len(self.groups)


@dataclass(frozen=True)
class DigestResult:
    """What one pass over the days did."""

    days: int
    regenerated: list[DigestSelection]
    latest_day: date | None
    latest_written: bool

    def summary(self) -> str:
        written = len(self.regenerated)
        latest = self.latest_day.isoformat() if self.latest_day else "nothing yet"
        wrote = f"{written} digest{'' if written == 1 else 's'} written"
        return f"{self.days} days, {wrote if written else 'nothing to write'}, latest {latest}"


def assemble_digest(store: Store, config: EmberConfig, day: date) -> DigestSelection:
    """Choose and group the items for *day*'s digest."""
    items = store.items_for_date(day)[: config.digest_items_max]
    return DigestSelection(day=day, items=items, groups=group_by_feed(items))


def group_by_feed(items: list[Item]) -> list[FeedGroup]:
    """Gather items under their feed, the feed with the newest item first."""
    order: list[str] = []
    gathered: dict[str, list[Item]] = {}
    for item in items:
        if item.feed not in gathered:
            gathered[item.feed] = []
            order.append(item.feed)
        gathered[item.feed].append(item)
    return [FeedGroup(feed=feed, items=gathered[feed]) for feed in order]


def digest_signature(selection: DigestSelection) -> str:
    """sha256 over the items a digest selected, in the order it selected them."""
    canonical = json.dumps(
        [
            [item.id, item.feed, item.title, item.published.isoformat(), item.summary]
            for item in selection.items
        ],
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def digest_rel(day: date) -> str:
    """Where a day's page goes, relative to the output directory."""
    return f"{day.isoformat()}.html"


def render_digest(selection: DigestSelection, config: EmberConfig, env: Environment) -> Doc:
    """Render one day's page."""
    day = selection.day
    ctx = {
        "page_title": f"{config.title}: {day.isoformat()}",
        "day": day,
        "day_label": day_label(day),
        "total": selection.total,
        "feed_count": selection.feeds,
        "groups": selection.groups,
        "archive_url": "archive/index.html",
    }
    return Doc(digest_rel(day), env.render(DIGEST_TEMPLATE, ctx))


def day_label(day: date) -> str:
    """A day written out, as a heading wants it."""
    return f"{day.strftime('%A')} {day.day} {day.strftime('%B %Y')}"


class DigestState:
    """The signature each day's page was last written from.

    Kept in ``.ember/digest-state.json``. A state file from another version,
    or one that has been damaged, is dropped rather than repaired: the worst
    that costs is one pass that writes every page again.
    """

    def __init__(self, path: Path, signatures: dict[str, str] | None = None, latest: str = ""):
        self.path = path
        self.signatures: dict[str, str] = dict(signatures or {})
        self.latest = latest

    @classmethod
    def load(cls, data_dir: Path | str) -> "DigestState":
        path = Path(data_dir) / STATE_NAME
        state = cls(path)
        if not path.is_file():
            return state
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, OSError):
            return state
        if not isinstance(data, dict) or data.get("version") != STATE_VERSION:
            return state
        signatures = data.get("signatures")
        if isinstance(signatures, dict):
            state.signatures = {
                str(day): value for day, value in signatures.items() if isinstance(value, str)
            }
        state.latest = str(data.get("latest", ""))
        return state

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": STATE_VERSION,
            "latest": self.latest,
            "signatures": self.signatures,
        }
        self.path.write_text(
            json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )

    def signature_for(self, day: date) -> str:
        return self.signatures.get(day.isoformat(), "")

    def record(self, day: date, signature: str) -> None:
        self.signatures[day.isoformat()] = signature


def run_digest(root: Path | str, day: date | None = None) -> DigestResult:
    """Write the digest pages that are out of date, and mirror the newest one."""
    root = Path(root)
    config = load_config(root)
    output_root = config.output_path(root)
    env = Environment(config.template_path(root), globals={"ember": {"title": config.title}})
    state = DigestState.load(config.data_path(root))

    with open_store(config.data_path(root)) as store:
        known = store.dates()
        days = [day] if day is not None else known
        regenerated: list[DigestSelection] = []
        for each in days:
            selection = assemble_digest(store, config, each)
            signature = digest_signature(selection)
            # the digest consumes the selected items; skip regenerating it when
            # nothing it consumes changed.
            if signature == state.signature_for(each) and exists(output_root, digest_rel(each)):
                continue
            write_doc(output_root, render_digest(selection, config, env))
            state.record(each, signature)
            regenerated.append(selection)

        latest_day = known[0] if known else None
        latest_written = _mirror_latest(store, config, env, output_root, state, latest_day)

    state.save()
    return DigestResult(
        days=len(known),
        regenerated=regenerated,
        latest_day=latest_day,
        latest_written=latest_written,
    )


def _mirror_latest(
    store: Store,
    config: EmberConfig,
    env: Environment,
    output_root: Path,
    state: DigestState,
    latest_day: date | None,
) -> bool:
    """Copy the newest day's page to ``latest.html`` when that page has moved on."""
    if latest_day is None:
        return False
    stamp = f"{latest_day.isoformat()}:{state.signature_for(latest_day)}"
    if stamp == state.latest and exists(output_root, LATEST_REL):
        return False
    doc = render_digest(assemble_digest(store, config, latest_day), config, env)
    write_doc(output_root, Doc(LATEST_REL, doc.text))
    state.latest = stamp
    return True
