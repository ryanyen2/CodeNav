# CLAUDE.md

此文件在本仓库中工作时，为 Claude Code（claude.ai/code）提供指导。

## Commands

没有检查入库的 `.venv`。在使用 console script 之前先创建一个：

```bash
python3 -m venv .venv && .venv/bin/pip install -e '.[dev]'
```

```bash
.venv/bin/tally summarise fixtures/current.csv   # writes current.md beside the input
.venv/bin/tally summarise fixtures/current.csv - # writes to stdout instead
.venv/bin/tally check fixtures/                  # summarise every *.csv, write nothing
python3 -m tally.cli summarise fixtures/current.csv -   # same, without installing
```

Tests（仅 stdlib 包，因此系统 `pytest` 也可以）：

```bash
python3 -m pytest tests/ -q
python3 -m pytest tests/test_rules.py -q                          # one file
python3 -m pytest tests/test_rules.py::test_the_first_matching_rule_wins -q   # one test
python3 -m pytest tests/ -q -k transfer                           # by name
```

没有配置 linter 或 formatter。

## Architecture

一个 pipeline，`summarise(raw: str) -> Summary` 在 `tally/summary.py` 中。其余
部分要么是 parser，要么是它调用的单一 policy module。

**`rows.py` 负责解析，从不作决定。** 它将银行的 header 松散地与
`COLUMNS` 匹配，强制转换日期和金额，并输出 `Row` objects。下游的每个 rule
都读取 `Row`，从不读取银行的原始文本。无法读取的 rows 会被跳过，
而不是去猜测；没有 amount 或 transaction-date column 的文件会被当作零 rows 读取，而不是抛出异常。如果你发现自己要在这里做判断，
那应该放在 policy module 里。

**这些 policy modules 各自拥有一个决策**，并且每个 docstring 都说明了
被拒绝的替代方案以及原因。新增 rules 时请保持这个约定——
这样权衡才便于审查。

| module | policy |
| --- | --- |
| `money.py` | rounding（只在总计处一次）和 sign convention |
| `dedupe.py` | 什么算 duplicate，什么算 own-account transfer |
| `categories.py` | merchant description 到 category |
| `months.py` | 一行属于哪个 month，refund 如何净额结算 |
| `recurring.py` | 哪些 payments 是固定承诺 |

### The step order in `summarise()` is load-bearing

四个 coupling constraints，都很容易因重新排序而破坏：

1. `money.sign_convention` 最先运行，并且 **就地 mutates rows**——如果 >80% 的 amounts 为正，它会翻转
   所有 sign。下面的每个 rule 都会读取 signs，所以在它之前不能运行任何东西。
2. `dedupe.drop_duplicates` 在 transfers 被过滤掉之前运行，并在内部免除 transfers。own-account transfer 的两边
   具有相同的 date、amount 和 description——这正是 duplicate 的精确形状。去掉其中一边，money 看起来就像去了一个其实并没去的地方。
3. transfers 在 recurring 和 categorisation 之前从 `spending` 中移除，所以搬动 savings 永远不会被读作 spending。
4. categories 在 `months.net` 汇总它们之前被分配，因为 refund 会与其来源 category 抵消净额。

### First-match-wins ordering

两个有序列表，具体条目必须放在一般条目之上：

- `rows.COLUMNS` — `"transaction date"` 在 `"date"` 之前，否则同时导出两者的 bank 会得到 posting date 并使每个 month-end transaction 发生偏移。
- `categories.RULES` — `shell energy` 在 `shell` 之前，否则 electricity bill 会落入 fuel。

向任一列表添加条目时，意味着要决定它在顺序中的位置，而不是直接追加。

### Deliberate behaviours that look like bugs

- Refunds 只在 **同一个 month 内** 净额结算。January 保留其 spend，而 February 的 refund 显示为 February income。由
  `test_a_refund_nets_within_its_own_month_and_not_across_months` 覆盖。
- `sign_convention` 根据 data 进行猜测，而不是询问。这是一个
  single-user tool；错误的猜测会立刻可见。
- 任何未匹配项都会落入 `categories.UNCATEGORISED`，并在 summary line 中计数，
  而不是中止运行。
- `months.is_refund` 已定义，但目前在 pipeline 中未使用。

## Fixtures

这三个文件中的每一个都在测试其他文件无法测试的内容，而 end-to-end
tests 会对它们断言精确 totals。编辑 fixture 会破坏这些
assertions。

- `current.csv` — duplicates、same-day transfer pair、cross-month refund、
  recurring payments、一个 uncategorised merchant
- `other-bank.csv` — 不同的 column names，spending 以正数导出
- `boundary.csv` — 在一个 month 中生成，在下一个 month 中 posting

测试套件的划分：`tests/test_rules.py` 逐个 isolated 测试每个 policy（底部另有一个
coupled-pair test），`tests/test_statements.py` 将这些 fixtures end to end 运行。
