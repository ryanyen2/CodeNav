# Codebase feature guide

## 读取银行对账单

每家银行导出的交易都不同：列名不同，而且对于流出资金是否为负数也没有统一约定。这些特性会读取原始导出内容，并把它转成一种统一形状，这样此后每条规则都只需要写一次，而不是每家银行写一次。

### 银行导出行读取器

读取 CSV，并把它的列映射到一条通用行上。

列名会按别名的有序列表匹配，最具体的优先，所以同时有 `transaction date` 和 `date` 的文件会使用那个真正表示其含义的列。无法读取的行会被跳过，而不是去猜——先解析，后判断。

Code: `tally/rows.py::COLUMNS`, `tally/rows.py::DATE_FORMATS`, `tally/rows.py::Row`, `tally/rows.py::Row.is_money_out`, `tally/rows.py::__module__`, `tally/rows.py::_pick`, `tally/rows.py::parse_amount`, `tally/rows.py::parse_date`, `tally/rows.py::read`

### 资金处理策略

关于资金的两个决定，后续所有流程都依赖它们：哪个方向为负，以及何时四舍五入。

Code: `tally/money.py::__module__`

#### 汇总四舍五入

只在汇总时四舍五入一次，不对每笔交易都四舍五入。

两百笔交易逐笔四舍五入会累积出几便士的偏差；最后只四舍五入一次就不会。代价是总额不再逐行与打印收据一致，而如果你是在和收据对账，这正是你想要的。

Code: `tally/money.py::PENNY`, `tally/money.py::round_total`

#### 交易符号规范化

无论银行怎么记，都把支出变成负数，把收入变成正数。

有的银行把 12 英镑咖啡记成 `-12.00`；另一些记成 `12.00`，并把方向放在单独一列。如果文件里几乎所有金额都是正数，就把它当作第二种约定，并把所有符号翻转。这是一个猜测，是在没有询问的情况下做出的，这样之后的每条规则看到的都是同一种约定。

Code: `tally/money.py::sign_convention`

## 应用交易策略

在行已经统一成一种形状之后，这些规则决定什么才真正算支出：它落在哪个月，什么才是真正的重复项，什么是转账而不是购买，以及它属于哪个类别。

### 交易月份归属

把交易计入它发生的月份，而不是银行入账的月份。

一笔在 31 日刷卡、2 日入账的支付，应该归到你记得自己花钱的那个月份。另一种做法——按入账日期——会让汇总改为与银行对账单一致，而那是另一回事。

Code: `tally/months.py::__module__`, `tally/months.py::month_of`

### 转账感知去重

丢弃重复行，避免它们抬高总额。

相同的发生日期、相同的金额、相同的描述（忽略大小写）算作一条。行里没有任何内容能说明它是被发送了两次还是被购买了两次，所以同一天买两杯相同的咖啡只算一次——这是为了不把其他所有情况都重复计算的代价。转账是例外：从活期转到储蓄的 500 英镑会显示为两行，看起来完全像重复项，而丢掉其中一行会留下一个从未发生过的 500 英镑支付。转账也不计入支出，因为这笔钱仍然是你的。

Code: `tally/dedupe.py::TRANSFER_WORDS`, `tally/dedupe.py::__module__`, `tally/dedupe.py::drop_duplicates`, `tally/dedupe.py::is_transfer`, `tally/dedupe.py::key`

### 商户分类分配

通过将交易描述与按顺序排列的模式列表匹配，把每笔交易放入一个类别。

第一个匹配的模式获胜，所以更具体的规则要放在更宽泛的规则前面——某家咖啡店的规则必须排在通用的 `cafe` 规则之前，否则它永远不会触发。任何未匹配的内容都会进入未分类桶，这样汇总仍然能对上，缺口也会显眼地暴露出来，而不是悄无声息。

Code: `tally/categories.py::COMPILED`, `tally/categories.py::RULES`, `tally/categories.py::UNCATEGORISED`, `tally/categories.py::__module__`, `tally/categories.py::categorise`

### 退款净额政策

把退回来的钱从它原本花掉的类别里扣掉。

一件 100 英镑外套退回 40 英镑后，留下的是 60 英镑的服装支出，而不是 100 英镑的服装支出和 40 英镑的收入。退款通过其正号来识别，所以在这一步运行之前，收入必须先按类别排除，否则工资会看起来像某种退款。

Code: `tally/months.py::is_refund`, `tally/months.py::net`

### 循环支付检测

通过寻找至少三个不同月份里相同描述、相同金额的记录，找出固定承诺——房租、订阅。

描述和金额都必须匹配，否则每周一次的超市采购会看起来像订阅。要三个月而不是两个月，这样一次巧合不会变成一项承诺。

Code: `tally/recurring.py::MONTHS`, `tally/recurring.py::__module__`, `tally/recurring.py::find`

## 生成月度汇总

最终输出：按月按类别的总额，以及查询这些总额的方式。

### 月度支出汇总

把交易汇总成按月分类总额，并报告其余部分的处理结果：读取了多少行、丢弃了多少重复项、哪些被当作转账、哪些无法分类，以及哪些支付看起来是周期性的。

这些策略在加总之前运行，所以总额和下面的说明讲的是同一个故事。改变顺序会改变数字。

Code: `tally/summary.py::Month`, `tally/summary.py::Month.total`, `tally/summary.py::Summary`, `tally/summary.py::Summary.line`, `tally/summary.py::Summary.text`, `tally/summary.py::__module__`, `tally/summary.py::summarise`

### 命令行汇总接口

`tally summarise statement.csv` 会打印汇总；指向一个文件夹时，它会读取其中每个 CSV。还有一个检查模式，只读取并报告而不写入任何内容，这就是你在提交之前查看规则变更会带来什么影响的方式。

Code: `tally/cli.py::__module__`, `tally/cli.py::main`

## 检查对账单

这些特性验证对账单读取、交易策略和月度汇总在聚焦的规则案例以及完整的样例对账单中持续正确运行。

### 规则契约测试套件

保持每条交易规则的行为明确，包括一种策略会改变另一种策略结果的情况。该套件使用小型通用行，因此对解析、规范化、分类和汇总的改动会在规则边界处失败，而不是被更大的端到端示例掩盖。

Code: `tests/test_rules.py::__module__`, `tests/test_rules.py::row`

#### 导入交易契约

检查银行导出的值能否变成可用的交易，而在一行无法读取时不去猜测，并且在之后支出符号和日期具有预期含义。实际发生日期决定支出月份，即使入账发生得更晚；而当两种日期都导出时，交易日期优先，因此月末支出不会被移位。

Code: `tests/test_rules.py::test_a_transaction_belongs_to_the_month_it_was_made`, `tests/test_rules.py::test_a_transaction_date_beats_a_posting_date`, `tests/test_rules.py::test_an_export_with_spending_as_positive_is_flipped`, `tests/test_rules.py::test_an_ordinary_export_is_left_alone`, `tests/test_rules.py::test_an_unreadable_row_is_skipped_not_guessed_at`, `tests/test_rules.py::test_the_amount_formats_banks_use`, `tests/test_rules.py::test_the_date_formats_banks_use`

#### 转账安全契约

检查去重只会删除重复交易，同时保留不同的行以及自有账户转账的两端。转账对和重复项外形相同，但删掉其中一端会让钱看起来像是被花掉了。

Code: `tests/test_rules.py::test_a_transfer_is_recognised_by_its_wording`, `tests/test_rules.py::test_a_transfer_pair_is_not_a_duplicate`, `tests/test_rules.py::test_the_same_transaction_twice_is_dropped_once`, `tests/test_rules.py::test_two_transactions_that_differ_are_both_kept`

#### 分类退款契约

检查商户规则是否使用第一个匹配的模式，并把未匹配的支出保留在未分类桶中，而不是让汇总中断。然后退款会与该类别的支出相抵，所以在退款计算之前，类别分配必须仍然可用。

Code: `tests/test_rules.py::test_anything_unmatched_goes_to_a_bucket`, `tests/test_rules.py::test_refunds_net_against_the_category`, `tests/test_rules.py::test_the_first_matching_rule_wins`

#### 循环支付契约

检查一笔支付只有在同一商户和金额跨三个月出现时才会被称为循环支付，而金额变化或只有两个月都不符合条件。这样可以避免把普通的可变购物误判为固定承诺。

Code: `tests/test_rules.py::test_a_payment_in_three_months_at_one_amount_is_recurring`, `tests/test_rules.py::test_the_same_merchant_at_different_amounts_is_not`, `tests/test_rules.py::test_two_months_is_not_enough`

#### 汇总金额契约

检查货币总额是在金额加总之后只四舍五入一次。先对每一行分别四舍五入，可能会让几个小数分量加起来比真实总和多一便士。

Code: `tests/test_rules.py::test_rounding_happens_once_at_the_total`

### 端到端对账检查

保护从对账单到月度汇总的完整行为，覆盖示例银行，包括空输入、不同列、发生日期边界、符号转换、转账、重复项、退款、周期性支付、未分类交易和稳定输出。测试夹具把这些情况放在一起，因为每张对账单都会触及真实汇总流程的不同部分，所以在不保留其策略顺序或可见结果的情况下改动流水线，会在这里失败。

Code: `tests/test_statements.py::FIXTURES`, `tests/test_statements.py::__module__`, `tests/test_statements.py::run`, `tests/test_statements.py::test_a_refund_nets_within_its_own_month_and_not_across_months`, `tests/test_statements.py::test_a_transaction_made_on_the_31st_is_january`, `tests/test_statements.py::test_an_empty_file_is_not_an_error`, `tests/test_statements.py::test_an_unknown_merchant_is_visible_rather_than_hidden`, `tests/test_statements.py::test_and_the_ones_made_in_february_are_february`, `tests/test_statements.py::test_both_legs_of_every_transfer_survive`, `tests/test_statements.py::test_different_column_names_still_read`, `tests/test_statements.py::test_months_come_out_in_order`, `tests/test_statements.py::test_no_statement_ends_up_empty`, `tests/test_statements.py::test_spending_exported_as_positive_is_flipped`, `tests/test_statements.py::test_summarising_twice_gives_the_same_thing`, `tests/test_statements.py::test_the_fixed_commitments_are_found`, `tests/test_statements.py::test_the_repeated_shop_is_counted_once`, `tests/test_statements.py::test_transfers_are_left_out_of_the_spending`

## 包身份元数据

标识 Tally 包并记录其当前版本，以便工具和用户能够识别已安装的发布版。该模块还说明 Tally 会把银行导出内容转换为月度汇总。

Code: `tally/__init__.py::__module__`
